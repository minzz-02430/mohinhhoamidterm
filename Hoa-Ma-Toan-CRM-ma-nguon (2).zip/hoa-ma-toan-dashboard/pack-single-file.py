# Gộp dist/ thành một file HTML duy nhất, mở được bằng cách bấm đúp (không cần cài gì).
# Chạy: npm run build  rồi  python pack-single-file.py <file-html-đích>
import re, sys, pathlib

dist = pathlib.Path(__file__).parent / 'dist'
html = (dist / 'index.html').read_text(encoding='utf-8')
BS = chr(92)

def inline_css(match):
    return '<style>' + (dist / match.group(1).lstrip('/')).read_text(encoding='utf-8') + '</style>'

def inline_js(match):
    code = (dist / match.group(1).lstrip('/')).read_text(encoding='utf-8')
    # Chuỗi "</script" nằm trong mã sẽ đóng thẻ sớm, nên phải thoát ký tự.
    return '<script type="module">' + code.replace('</script', '<' + BS + '/script') + '</script>'

html, css_count = re.subn(r'<link rel="stylesheet"[^>]*href="([^"]+)"[^>]*>', inline_css, html)
html, js_count = re.subn(r'<script type="module"[^>]*src="([^"]+)"[^>]*></script>', inline_js, html)
html = re.sub(r'<link rel="modulepreload"[^>]*>', '', html)
assert css_count >= 1 and js_count == 1, (css_count, js_count)
assert 'src="/assets' not in html and 'href="/assets' not in html, 'còn file ngoài chưa gộp'

target = pathlib.Path(sys.argv[1])
target.write_text(html, encoding='utf-8')
print(target.name, round(target.stat().st_size / 1024), 'KB')
