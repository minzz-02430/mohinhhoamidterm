import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  // Nhúng ảnh vào thẳng JS/CSS để bản đóng gói một file HTML mở được bằng cách bấm đúp.
  build: { assetsInlineLimit: 100_000_000 },
  plugins: [
    react(),
    tailwindcss(),
  ],
})