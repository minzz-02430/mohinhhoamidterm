import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { ready } from './modules/store'

// Chờ băm xong mật khẩu của dữ liệu mẫu rồi mới dựng giao diện.
ready.then(() => {
  createRoot(document.getElementById('root')).render(
    <StrictMode>
      <App />
    </StrictMode>,
  )
})
