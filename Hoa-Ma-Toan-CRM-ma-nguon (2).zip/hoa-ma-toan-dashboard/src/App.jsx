import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react'
import '@fortawesome/fontawesome-free/css/fontawesome.min.css'
import '@fortawesome/fontawesome-free/css/solid.min.css'
import './components/Dashboard.css'
import './styles/tokens.css'
import './modules/modules.css'
import './modules/shell.css'
import './modules/extras.css'
import logo from './assets/logo.png'
import { ROLE_LABELS, isUnread, setDenyHandler, setViewAs, threadsFor, useActor, useStore } from './modules/store'
import { Toasts, navigate, toast, useNavigation } from './modules/ui'
import Auth from './modules/Auth'
import Topbar from './modules/Topbar'
import ChatPanel from './modules/ChatPanel'
import DashboardModule from './modules/DashboardModule'
import CrmModule from './modules/CrmModule'
import EducationModule from './modules/EducationModule'
import HrModule from './modules/HrModule'
import FinanceModule from './modules/FinanceModule'
import SupportModule from './modules/SupportModule'
import ReportsModule from './modules/ReportsModule'
import SettingsModule from './modules/SettingsModule'
import MessagesModule from './modules/MessagesModule'
import TasksModule from './modules/TasksModule'
import TeacherModule from './modules/TeacherModule'
import ParentModule from './modules/ParentModule'

const NAV = {
  dashboard: ['Dashboard tổng quan', 'fa-table-columns'], crm: ['CRM', 'fa-address-book'], education: ['Học vụ & Đào tạo', 'fa-book-open'],
  hr: ['Quản lý nhân sự', 'fa-users'], finance: ['Tài chính & Kế toán', 'fa-wallet'], support: ['Chăm sóc khách hàng', 'fa-headset'],
  reports: ['Báo cáo', 'fa-chart-pie'], messages: ['Tin nhắn', 'fa-comments'], tasks: ['Công việc', 'fa-list-check'], settings: ['Cài đặt', 'fa-gear'],
  't-home': ['Tổng quan', 'fa-table-columns'], 't-classes': ['Lớp của tôi', 'fa-chalkboard'], 't-results': ['Điểm danh & nhận xét', 'fa-clipboard-check'],
  't-proposal': ['Đề xuất dạy bù/thay', 'fa-calendar-plus'],
  'p-children': ['Con của tôi', 'fa-children'], 'p-schedule': ['Lịch học', 'fa-calendar-days'], 'p-results': ['Kết quả', 'fa-chart-line'],
  'p-fees': ['Học phí', 'fa-receipt'], 'p-requests': ['Yêu cầu hỗ trợ', 'fa-headset'],
}
const STAFF_TABS = ['dashboard', 'crm', 'education', 'hr', 'finance', 'support', 'reports', 'messages', 'tasks', 'settings']
const TEACHER_TABS = ['t-home', 't-classes', 't-results', 't-proposal', 'messages', 'tasks']
// Menu theo vai trò lấy từ tài khoản: kế toán chỉ thấy tài chính, tư vấn viên chỉ thấy CRM và CSKH.
const ROLE_TABS = {
  admin: STAFF_TABS, manager: STAFF_TABS, accountant: ['finance', 'messages', 'tasks'], sales: ['crm', 'support', 'messages', 'tasks'],
  teacher: TEACHER_TABS, assistant: TEACHER_TABS, parent: ['p-children', 'p-schedule', 'p-results', 'p-fees', 'p-requests', 'messages'],
}

function Page({ tab, actor }) {
  const props = { role: actor.role, notify: toast }
  if (tab.startsWith('t-')) return <TeacherModule actor={actor} tab={tab} />
  if (tab.startsWith('p-')) return <ParentModule actor={actor} tab={tab} />
  switch (tab) {
    case 'dashboard': return <DashboardModule {...props} />
    case 'crm': return <CrmModule {...props} />
    case 'education': return <EducationModule {...props} />
    case 'hr': return <HrModule {...props} />
    case 'finance': return <FinanceModule {...props} />
    case 'support': return <SupportModule {...props} me={actor.name} />
    case 'reports': return <ReportsModule {...props} />
    case 'settings': return <SettingsModule {...props} me={actor.username} />
    case 'messages': return <MessagesModule actor={actor} />
    default: return <TasksModule actor={actor} />
  }
}

function Shell({ actor }) {
  const store = useStore()
  const tabs = ROLE_TABS[actor.role]
  const [tab, setTab] = useState(tabs[0])
  const active = tabs.includes(tab) ? tab : tabs[0]
  useNavigation(useCallback(next => { if (tabs.includes(next)) setTab(next) }, [tabs]))
  // Khung xương hiện rất ngắn khi đổi trang để chuyển cảnh không bị giật.
  const [loading, setLoading] = useState(true)
  useEffect(() => {
    setLoading(true)
    const timer = window.setTimeout(() => setLoading(false), 180)
    return () => window.clearTimeout(timer)
  }, [active])
  // Pill trắng trượt tới mục đang chọn trên thanh bên.
  const navRef = useRef(null)
  const [pill, setPill] = useState(null)
  useLayoutEffect(() => {
    const item = navRef.current?.querySelector('.nav-item.active')
    if (item) setPill({ top: item.offsetTop, height: item.offsetHeight })
  }, [active, tabs])
  const badges = {
    messages: threadsFor(actor, store).filter(thread => isUnread(thread, actor)).length,
    tasks: store.tasks.filter(task => task.assignee === actor.username && task.status === 'new').length,
  }
  return (
    <>
      <div className="app-layout">
        <aside className="sidebar">
          <a className="hm-side-logo" href="#" onClick={event => { event.preventDefault(); navigate(tabs[0]) }} aria-label="Hòa Ma Toán, về trang đầu">
            <img src={logo} width="360" height="117" alt="" />
          </a>
          <nav className="nav-list" aria-label="Điều hướng chính" ref={navRef}>
            {pill && <span className="hm-nav-pill" style={{ transform: `translateY(${pill.top}px)`, height: pill.height }} aria-hidden="true"></span>}
            {tabs.map(key => (
              <button key={key} type="button" className={`nav-item${key === active ? ' active' : ''}`} aria-current={key === active ? 'page' : undefined} onClick={() => setTab(key)}>
                <i className={`fa-solid ${NAV[key][1]}`} aria-hidden="true"></i>
                <span>{NAV[key][0]}</span>
                {badges[key] > 0 && <span className="hm-nav-badge">{badges[key]}</span>}
              </button>
            ))}
          </nav>
          <div className="sidebar-bottom">
            <strong>Năm học {store.settings.center.year}</strong><br />
            {actor.branch ? `Cơ sở ${actor.branch}` : 'Toàn hệ thống · 5 cơ sở'}
          </div>
        </aside>
        <div className="hm-main-column">
          <Topbar actor={actor} title={NAV[active][0]} tabs={tabs} />
          {actor.readOnly && (
            <div className="hm-banner" role="status">
              <i className="fa-solid fa-eye" aria-hidden="true"></i>
              Đang xem với tư cách {ROLE_LABELS[actor.role]} ({actor.name}), chế độ chỉ đọc.
              <button type="button" onClick={() => setViewAs(null)}>Thoát</button>
            </div>
          )}
          {/* key theo tab để mỗi lần chuyển trang có hiệu ứng mờ dần + trượt nhẹ */}
          <main className="main hm-page" key={active}>
            {loading
              ? <div className="hm-skeleton" aria-hidden="true"><i></i><div><i></i><i></i><i></i><i></i></div><i></i></div>
              : <Page tab={active} actor={actor} />}
          </main>
        </div>
      </div>
      <ChatPanel actor={actor} />
    </>
  )
}

export default function App() {
  const actor = useActor()
  useEffect(() => { setDenyHandler(toast) }, [])
  return (
    <div className="legacy-dashboard">
      {/* key theo tài khoản và vai trò đang xem để trạng thái màn hình không rò từ người này sang người khác */}
      {actor && !actor.mustChange ? <Shell key={`${actor.username}-${actor.readOnly}`} actor={actor} /> : <Auth mustChange={Boolean(actor?.mustChange)} />}
      <Toasts />
    </div>
  )
}
