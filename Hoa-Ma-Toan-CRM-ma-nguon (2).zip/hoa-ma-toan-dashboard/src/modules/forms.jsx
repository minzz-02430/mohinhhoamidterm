import { useState } from 'react'
import { BRANCHES, GRADE_GROUPS, addClass, addStaff, addStudent, addTransaction, myBranch, updateTransaction, useStore } from './store'
import { Field, Modal, toast } from './ui'

const PHONE = /^0\d{9}$/
const useFields = initial => {
  const [form, setForm] = useState(initial)
  return [form, key => event => setForm(current => ({ ...current, [key]: event.target.value }))]
}
const Actions = ({ onClose, label }) => (
  <div className="hm-form-actions">
    <button type="button" className="button" onClick={onClose}>Hủy</button>
    <button type="submit" className="button primary">{label}</button>
  </div>
)
const BranchField = ({ role, value, onChange }) => (
  <Field label="Cơ sở">
    {id => (
      <select id={id} value={value} onChange={onChange} disabled={role !== 'admin'}>
        {BRANCHES.map(item => <option key={item}>{item}</option>)}
      </select>
    )}
  </Field>
)

export function StudentForm({ role, onClose }) {
  const store = useStore()
  const [form, set] = useFields({ name: '', classId: '', parentName: '', phone: '', birth: '', branch: role === 'admin' ? BRANCHES[0] : myBranch() })
  const [error, setError] = useState('')
  const classes = store.classes.filter(item => item.branch === form.branch)
  const submit = event => {
    event.preventDefault()
    if (!PHONE.test(form.phone.replace(/\s/g, ''))) return setError('Số điện thoại cần 10 chữ số, bắt đầu bằng 0.')
    const full = classes.find(item => item.id === form.classId && item.size >= item.capacity)
    if (full) return setError(`Lớp ${full.name} đã đủ sĩ số (${full.size}/${full.capacity}).`)
    const record = addStudent({ ...form, birth: form.birth.split('-').reverse().join('/') })
    if (record) toast(`Đã thêm học viên ${record.name} (${record.id}).`)
    return onClose()
  }
  return (
    <Modal title="Thêm học viên" description="Học viên mới được cộng ngay vào số liệu Dashboard và Báo cáo." onClose={onClose}>
      <form className="hm-form" onSubmit={submit}>
        <Field label="Họ tên học viên">{id => <input id={id} required value={form.name} onChange={set('name')} />}</Field>
        <Field label="Ngày sinh">{id => <input id={id} type="date" required value={form.birth} onChange={set('birth')} />}</Field>
        <BranchField role={role} value={form.branch} onChange={set('branch')} />
        <Field label="Xếp lớp">
          {id => (
            <select id={id} value={form.classId} onChange={set('classId')}>
              <option value="">Chưa xếp lớp</option>
              {classes.map(item => <option key={item.id} value={item.id}>{item.name} ({item.size}/{item.capacity})</option>)}
            </select>
          )}
        </Field>
        <Field label="Phụ huynh">{id => <input id={id} required value={form.parentName} onChange={set('parentName')} />}</Field>
        <Field label="SĐT phụ huynh" error={error}>{id => <input id={id} required inputMode="tel" value={form.phone} onChange={set('phone')} placeholder="09xxxxxxxx" />}</Field>
        <Actions onClose={onClose} label="Lưu học viên" />
      </form>
    </Modal>
  )
}

export function ClassForm({ role, onClose }) {
  const store = useStore()
  const [form, set] = useFields({ name: '', group: GRADE_GROUPS[0], teacher: '', capacity: 18, branch: role === 'admin' ? BRANCHES[0] : myBranch() })
  const teachers = store.staff.filter(item => item.role.startsWith('Giáo viên') && item.branch === form.branch)
  const duplicate = store.classes.some(item => item.branch === form.branch && item.name.toLowerCase() === form.name.trim().toLowerCase())
  const submit = event => {
    event.preventDefault()
    if (duplicate) return
    const record = addClass({ ...form, teacher: form.teacher || teachers[0]?.name || 'Chưa phân công' })
    if (record) toast(`Đã tạo lớp ${record.name}. Vào Thời khóa biểu để xếp buổi học.`)
    onClose()
  }
  return (
    <Modal title="Tạo lớp học" onClose={onClose}>
      <form className="hm-form" onSubmit={submit}>
        <Field label="Tên lớp" error={duplicate && 'Cơ sở này đã có lớp trùng tên.'}>{id => <input id={id} required value={form.name} onChange={set('name')} placeholder="Toán 6 nâng cao" />}</Field>
        <Field label="Khối">{id => <select id={id} value={form.group} onChange={set('group')}>{GRADE_GROUPS.map(item => <option key={item}>{item}</option>)}</select>}</Field>
        <BranchField role={role} value={form.branch} onChange={set('branch')} />
        <Field label="Giáo viên">
          {id => (
            <select id={id} value={form.teacher} onChange={set('teacher')}>
              {teachers.map(item => <option key={item.id}>{item.name}</option>)}
              {!teachers.length && <option value="">Chưa có giáo viên tại cơ sở</option>}
            </select>
          )}
        </Field>
        <Field label="Sĩ số tối đa">{id => <input id={id} type="number" min="1" max="40" required value={form.capacity} onChange={set('capacity')} />}</Field>
        <Actions onClose={onClose} label="Tạo lớp" />
      </form>
    </Modal>
  )
}

export function StaffForm({ role, onClose }) {
  const [form, set] = useFields({ name: '', role: 'Giáo viên Toán', phone: '', contract: 'Toàn thời gian', salary: 12, joined: new Date().toLocaleDateString('vi-VN'), branch: role === 'admin' ? BRANCHES[0] : myBranch() })
  const [error, setError] = useState('')
  const submit = event => {
    event.preventDefault()
    if (!PHONE.test(form.phone.replace(/\s/g, ''))) return setError('Số điện thoại cần 10 chữ số, bắt đầu bằng 0.')
    const record = addStaff(form)
    if (record) toast(`Đã thêm nhân sự ${record.name} (${record.id}).`)
    return onClose()
  }
  return (
    <Modal title="Thêm nhân sự" description="Tài khoản đăng nhập do Ban giám đốc cấp riêng ở Cài đặt." onClose={onClose}>
      <form className="hm-form" onSubmit={submit}>
        <Field label="Họ tên">{id => <input id={id} required value={form.name} onChange={set('name')} />}</Field>
        <Field label="Vị trí">{id => <select id={id} value={form.role} onChange={set('role')}>{['Giáo viên Toán', 'Trợ giảng', 'Tư vấn viên', 'Kế toán', 'Hành chính'].map(item => <option key={item}>{item}</option>)}</select>}</Field>
        <BranchField role={role} value={form.branch} onChange={set('branch')} />
        <Field label="Loại hợp đồng">{id => <select id={id} value={form.contract} onChange={set('contract')}>{['Toàn thời gian', 'Bán thời gian', 'Thử việc'].map(item => <option key={item}>{item}</option>)}</select>}</Field>
        <Field label="Số điện thoại" error={error}>{id => <input id={id} required inputMode="tel" value={form.phone} onChange={set('phone')} placeholder="09xxxxxxxx" />}</Field>
        <Field label="Lương tháng (triệu đồng)">{id => <input id={id} type="number" min="1" step="0.1" required value={form.salary} onChange={set('salary')} />}</Field>
        <Actions onClose={onClose} label="Lưu nhân sự" />
      </form>
    </Modal>
  )
}

const CATEGORIES = { income: ['Học phí', 'Giáo trình, tài liệu', 'Thu khác'], expense: ['Lương & vận hành', 'Marketing', 'Cơ sở vật chất', 'Chi khác'] }

export function TransactionForm({ role, type, record, onClose }) {
  const [form, set] = useFields(record
    ? { category: record.category, amount: record.amount, note: record.note, branch: record.branch }
    : { category: CATEGORIES[type][0], amount: '', note: '', branch: role === 'admin' ? BRANCHES[0] : myBranch() })
  const label = type === 'income' ? 'phiếu thu' : 'phiếu chi'
  const submit = event => {
    event.preventDefault()
    if (record) {
      if (updateTransaction(record.id, form)) toast(`Đã sửa ${label} ${record.id}. Dòng tiền đã cập nhật.`)
    } else {
      const made = addTransaction({ ...form, type })
      if (made) toast(`Đã tạo ${label} ${made.id}. Dòng tiền và Dashboard đã cập nhật.`)
    }
    onClose()
  }
  return (
    <Modal title={record ? `Sửa ${label} ${record.id}` : `Tạo ${label}`} onClose={onClose}>
      <form className="hm-form" onSubmit={submit}>
        <Field label="Hạng mục">{id => <select id={id} value={form.category} onChange={set('category')}>{CATEGORIES[type].map(item => <option key={item}>{item}</option>)}</select>}</Field>
        <Field label="Số tiền (đồng)">{id => <input id={id} type="number" min="1000" step="1000" required value={form.amount} onChange={set('amount')} placeholder="2400000" />}</Field>
        <BranchField role={role} value={form.branch} onChange={set('branch')} />
        <Field label="Diễn giải">{id => <input id={id} required value={form.note} onChange={set('note')} />}</Field>
        <Actions onClose={onClose} label={`Lưu ${label}`} />
      </form>
    </Modal>
  )
}
