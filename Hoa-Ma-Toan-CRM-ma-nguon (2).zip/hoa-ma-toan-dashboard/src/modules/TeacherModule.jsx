import { useState } from 'react'
import { DAYS, ROOMS, addProposal, findConflicts, freeRooms, lessonSla, useStore } from './store'
import { formatDate, percent } from './format'
import { LessonForm, SlaBoard } from './EducationModule'
import { Badge, Empty, Field, Kpi, Modal, PageHead, Progress, navigate, toast } from './ui'

const STATUS = { pending: ['Chờ quản lý duyệt', 'amber'], approved: ['Đã duyệt', 'green'], rejected: ['Bị từ chối', 'red'] }
const GROUP_TONE = { 'Khối 1–5': 'green', 'Khối 6–9': 'blue', 'Khối 10–12': 'purple' }

function Home({ actor, classes, lessons, sessions, proposals, onOpen }) {
  const today = (new Date().getDay() + 6) % 7
  const todays = sessions.filter(item => item.day === today).sort((a, b) => a.start.localeCompare(b.start))
  const pending = lessons.filter(item => !item.done)
  const late = pending.filter(item => lessonSla(item).state === 'late').length
  const className = id => classes.find(item => item.id === id)?.name || id
  return (
    <>
      <div className="kpi-grid">
        <Kpi label="Lớp phụ trách" value={classes.length} icon="fa-chalkboard-user" note={`${classes.reduce((sum, item) => sum + item.size, 0)} học sinh`} />
        <Kpi label="Buổi dạy mỗi tuần" value={sessions.length} icon="fa-calendar-week" note={`${todays.length} buổi hôm nay`} />
        <Kpi label="Nhận xét cần gửi" value={pending.length} icon="fa-stopwatch" tone={late ? 'bad' : pending.length ? 'warn' : 'good'} note={late ? `${late} buổi đã quá hạn 24 giờ` : 'Trong hạn 24 giờ'} />
        <Kpi label="Đề xuất chờ duyệt" value={proposals.filter(item => item.status === 'pending').length} icon="fa-calendar-plus" note={`${proposals.length} đề xuất đã gửi`} />
      </div>
      <div className="grid-2">
        <article className="card hm-panel">
          <div className="hm-toolbar"><h2 className="card-title hm-flat">Buổi học cần điểm danh và nhận xét</h2><button type="button" className="button small" onClick={() => navigate('t-results')}>Xem tất cả</button></div>
          <SlaBoard lessons={pending} className={className} onOpen={onOpen} />
        </article>
        <article className="card">
          <h2 className="card-title">Lịch dạy hôm nay <span className="muted">{DAYS[today]}</span></h2>
          {!todays.length && <Empty icon="fa-mug-hot">Hôm nay {actor.name} không có buổi dạy.</Empty>}
          <ul className="hm-mini-list">
            {todays.map(item => <li key={item.id}><strong>{item.start}</strong><span>{className(item.classId)}<small>{item.room} · đến {item.end}</small></span>{item.makeup && <Badge tone="blue">{item.makeup}</Badge>}</li>)}
          </ul>
        </article>
      </div>
    </>
  )
}

function Classes({ classes, sessions, lessons, students, onOpen }) {
  const [roster, setRoster] = useState(null)
  const namesOf = klass => [...new Set([
    ...students.filter(item => item.classId === klass.id).map(item => item.name),
    ...lessons.filter(item => item.classId === klass.id).flatMap(item => item.students.map(entry => entry.name)),
  ])]
  if (!classes.length) return <article className="card"><Empty icon="fa-chalkboard">Bạn chưa được phân công lớp nào.</Empty></article>
  return (
    <>
      <div className="hm-class-grid">
        {classes.map(klass => {
          const slots = sessions.filter(item => item.classId === klass.id)
          const next = lessons.find(item => item.classId === klass.id && !item.done)
          const single = klass.capacity <= 1
          return (
            <article key={klass.id} className="card hm-class">
              <header><Badge tone={GROUP_TONE[klass.group] || 'slate'}>{klass.group}</Badge><Badge tone="slate">{single ? 'Lớp 1 kèm 1' : 'Lớp nhóm'}</Badge></header>
              <h2>{klass.name}</h2>
              <p>{slots.map(item => `${DAYS[item.day]} ${item.start}–${item.end} (${item.room})`).join(' · ') || 'Chưa xếp lịch'}</p>
              {/* Lớp 1 kèm 1 không có khái niệm lấp đầy nên không hiện thanh sĩ số. */}
              {!single && <div className="hm-cell-progress"><Progress value={percent(klass.size, klass.capacity)} label={`Sĩ số ${klass.name}`} /><span>{klass.size}/{klass.capacity} học sinh</span></div>}
              <footer>
                <button type="button" className="button small" onClick={() => setRoster(klass)}><i className="fa-solid fa-users" aria-hidden="true"></i>Học sinh</button>
                <button type="button" className="button small primary" disabled={!next} onClick={() => onOpen(next)}><i className="fa-solid fa-clipboard-check" aria-hidden="true"></i>{next ? 'Điểm danh' : 'Đã điểm danh hết'}</button>
              </footer>
            </article>
          )
        })}
      </div>
      {roster && (
        <Modal title={`Học sinh lớp ${roster.name}`} description={`${namesOf(roster).length} học sinh có trong sổ điểm danh`} onClose={() => setRoster(null)}>
          <ul className="hm-mini-list">
            {namesOf(roster).map(name => {
              const record = students.find(item => item.name === name)
              return <li key={name}><strong>{name}</strong><span><small>{record ? `${record.id} · PH ${record.parentName}` : 'Chưa có hồ sơ chi tiết'}</small></span>{record?.parent && <Badge tone="green" icon="fa-link">Phụ huynh có tài khoản</Badge>}</li>
            })}
          </ul>
        </Modal>
      )}
    </>
  )
}

function Proposal({ actor, classes, proposals, allSessions }) {
  const first = classes[0]
  const [form, setForm] = useState({ classId: first?.id || '', type: 'Dạy bù', day: 5, start: '14:00', end: '15:30', room: ROOMS[0], reason: '' })
  const set = key => event => setForm(current => ({ ...current, [key]: key === 'day' ? Number(event.target.value) : event.target.value }))
  if (!first) return <article className="card"><Empty icon="fa-chalkboard">Bạn chưa được phân công lớp nào nên chưa thể gửi đề xuất.</Empty></article>
  const klass = classes.find(item => item.id === form.classId)
  const candidate = { ...form, teacher: actor.name, branch: klass.branch }
  const valid = form.start < form.end
  const conflicts = valid ? findConflicts(candidate, allSessions) : []
  const rooms = freeRooms(candidate, allSessions)
  const className = id => classes.find(item => item.id === id)?.name || id
  const submit = event => {
    event.preventDefault()
    if (!valid || conflicts.length) return
    const record = addProposal(form)
    if (!record) return
    toast(`Đã gửi đề xuất ${record.id} cho quản lý cơ sở ${klass.branch}.`)
    setForm(current => ({ ...current, reason: '' }))
  }
  return (
    <div className="grid-2 reverse">
      <article className="card">
        <h2 className="card-title">Tạo đề xuất dạy bù / dạy thay</h2>
        <form className="hm-form" onSubmit={submit}>
          <Field label="Lớp">{id => <select id={id} value={form.classId} onChange={set('classId')}>{classes.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</select>}</Field>
          <Field label="Hình thức">{id => <select id={id} value={form.type} onChange={set('type')}><option>Dạy bù</option><option>Dạy thay</option></select>}</Field>
          <Field label="Thứ">{id => <select id={id} value={form.day} onChange={set('day')}>{DAYS.map((day, index) => <option key={day} value={index}>{day}</option>)}</select>}</Field>
          <Field label="Phòng mong muốn">{id => <select id={id} value={form.room} onChange={set('room')}>{ROOMS.map(room => <option key={room}>{room}</option>)}</select>}</Field>
          <Field label="Bắt đầu">{id => <input id={id} type="time" required value={form.start} onChange={set('start')} />}</Field>
          <Field label="Kết thúc" error={!valid && 'Giờ kết thúc phải sau giờ bắt đầu.'}>{id => <input id={id} type="time" required value={form.end} onChange={set('end')} />}</Field>
          <div className="hm-span-2"><Field label="Lý do">{id => <textarea id={id} rows={3} required value={form.reason} onChange={set('reason')} placeholder="Ví dụ: Bù cho buổi nghỉ lễ ngày 20/11." />}</Field></div>
          <div className={`hm-scan ${conflicts.length ? 'bad' : 'good'}`} role="status">
            <i className={`fa-solid ${conflicts.length ? 'fa-triangle-exclamation' : 'fa-shield-halved'}`} aria-hidden="true"></i>
            <div>
              <strong>{conflicts.length ? `Khung giờ này đang trùng ${conflicts.length} lịch` : 'Khung giờ và phòng đang trống'}</strong>
              {conflicts.map((item, index) => <p key={index}>{item.kind === 'room' ? `Phòng ${item.with.room} đã có lớp` : 'Bạn đang có buổi dạy'} lúc {item.with.start}–{item.with.end}</p>)}
              {conflicts.some(item => item.kind === 'room') && rooms.length > 0 && (
                <p className="hm-suggest">Phòng trống: {rooms.map(room => <button key={room} type="button" onClick={() => setForm(current => ({ ...current, room }))}>{room}</button>)}</p>
              )}
            </div>
          </div>
          <div className="hm-form-actions"><button type="submit" className="button primary" disabled={!valid || conflicts.length > 0}><i className="fa-solid fa-paper-plane" aria-hidden="true"></i>Gửi quản lý duyệt</button></div>
        </form>
      </article>
      <article className="card">
        <h2 className="card-title">Đề xuất đã gửi <Badge tone="orange">{proposals.length}</Badge></h2>
        {!proposals.length && <Empty icon="fa-calendar-plus">Chưa có đề xuất nào.</Empty>}
        <ul className="hm-ticket-list">
          {proposals.map(item => (
            <li key={item.id} className="hm-ticket">
              <div className="hm-ticket-head"><strong>{item.id}</strong><Badge tone="slate">{item.type}</Badge><Badge tone={STATUS[item.status][1]}>{STATUS[item.status][0]}</Badge></div>
              <p>{className(item.classId)} · {DAYS[item.day]} {item.start}–{item.end} · {item.room}</p>
              <div className="hm-ticket-foot"><span>{item.reason}</span><span>Gửi ngày {formatDate(item.at)}{item.decidedBy ? ` · ${item.decidedBy} xử lý` : ''}</span></div>
            </li>
          ))}
        </ul>
      </article>
    </div>
  )
}

const HEADS = {
  't-home': ['Tổng quan giảng dạy', 'Lịch dạy hôm nay và các buổi cần gửi nhận xét trong 24 giờ.'],
  't-classes': ['Lớp của tôi', 'Sĩ số, lịch học và điểm danh từng lớp được phân công.'],
  't-results': ['Điểm danh & nhận xét', 'Phụ huynh có tài khoản thấy ngay kết quả và nhận thông báo khi bạn gửi.'],
  't-proposal': ['Đề xuất dạy bù / dạy thay', 'Đề xuất được gửi tới quản lý cơ sở; khi duyệt, lịch tự cập nhật và phụ huynh được báo.'],
}

export default function TeacherModule({ actor, tab }) {
  const store = useStore()
  const [lesson, setLesson] = useState(null)
  const classes = store.classes.filter(item => item.teacher === actor.name)
  const ids = classes.map(item => item.id)
  const sessions = store.sessions.filter(item => item.teacher === actor.name)
  const lessons = store.lessons.filter(item => ids.includes(item.classId))
  const proposals = store.proposals.filter(item => item.teacherUser === actor.username)
  const className = id => store.classes.find(item => item.id === id)?.name || id
  const [title, description] = HEADS[tab]
  return (
    <>
      <PageHead title={title} description={description} />
      {tab === 't-home' && <Home actor={actor} classes={classes} lessons={lessons} sessions={sessions} proposals={proposals} onOpen={setLesson} />}
      {tab === 't-classes' && <Classes classes={classes} sessions={sessions} lessons={lessons} students={store.students} onOpen={setLesson} />}
      {tab === 't-results' && <article className="card hm-panel"><SlaBoard lessons={lessons} className={className} onOpen={setLesson} /></article>}
      {tab === 't-proposal' && <Proposal actor={actor} classes={classes} proposals={proposals} allSessions={store.sessions} />}
      {lesson && <LessonForm lesson={lesson} className={className} notify={toast} onClose={() => setLesson(null)} />}
    </>
  )
}
