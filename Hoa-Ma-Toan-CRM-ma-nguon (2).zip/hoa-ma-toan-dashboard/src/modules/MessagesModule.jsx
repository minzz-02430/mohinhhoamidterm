import { useEffect, useRef, useState } from 'react'
import { ROLE_LABELS, contactsFor, isUnread, markThreadSeen, openThread, sendMessage, threadsFor, useStore } from './store'
import { formatTime, timeAgo } from './format'
import { Avatar, Badge, Empty, PageHead } from './ui'

export default function MessagesModule({ actor }) {
  const store = useStore()
  const threads = threadsFor(actor, store)
  const [selected, setSelected] = useState(threads[0]?.id || null)
  const [text, setText] = useState('')
  const end = useRef(null)
  const contacts = contactsFor(actor, store)
  const nameOf = username => store.accounts.find(item => item.username === username)?.name || username
  const roleOf = username => ROLE_LABELS[store.accounts.find(item => item.username === username)?.role] || ''
  const thread = threads.find(item => item.id === selected)
  const messages = store.messages.filter(item => item.threadId === selected)
  const other = thread?.members.find(user => user !== actor.username)
  const last = messages.at(-1)

  // Đang mở hội thoại nào thì hội thoại đó được đánh dấu đã xem và cuộn xuống tin mới nhất.
  useEffect(() => {
    if (thread && isUnread(thread, actor)) markThreadSeen(thread.id)
    end.current?.scrollIntoView({ block: 'nearest' })
  }, [thread, actor, messages.length])

  const send = event => {
    event.preventDefault()
    if (sendMessage(selected, text)) setText('')
  }
  const start = username => {
    const id = openThread(username)
    if (id) setSelected(id)
  }

  return (
    <>
      <PageHead title="Tin nhắn" description="Trao đổi trực tiếp giữa phụ huynh, giáo viên, quản lý và Ban giám đốc. Mở hai cửa sổ để thấy tin đến tức thì.">
        <label className="hm-select">
          <span className="hm-sr">Bắt đầu trò chuyện với</span>
          <i className="fa-solid fa-pen-to-square" aria-hidden="true"></i>
          <select value="" onChange={event => start(event.target.value)} disabled={actor.readOnly}>
            <option value="">Cuộc trò chuyện mới…</option>
            {contacts.map(item => <option key={item.username} value={item.username}>{item.name} · {ROLE_LABELS[item.role]}</option>)}
          </select>
        </label>
      </PageHead>
      <article className="card hm-chat">
        <aside aria-label="Danh sách hội thoại">
          {!threads.length && <Empty icon="fa-comments">Chưa có hội thoại nào. Chọn “Cuộc trò chuyện mới”.</Empty>}
          {threads.map(item => {
            const partner = item.members.find(user => user !== actor.username)
            const preview = store.messages.filter(message => message.threadId === item.id).at(-1)
            return (
              <button key={item.id} type="button" className={`${item.id === selected ? 'active' : ''}${isUnread(item, actor) ? ' unread' : ''}`} onClick={() => setSelected(item.id)}>
                <Avatar name={nameOf(partner)} />
                <span>
                  <strong>{nameOf(partner)}</strong>
                  <small>{preview ? preview.text : item.title}</small>
                </span>
                <em>{timeAgo(item.lastAt)}</em>
              </button>
            )
          })}
        </aside>
        <section aria-label="Nội dung hội thoại">
          {!thread && <Empty icon="fa-envelope-open-text">Chọn một hội thoại để xem tin nhắn.</Empty>}
          {thread && (
            <>
              <header><Avatar name={nameOf(other)} /><div><strong>{nameOf(other)}</strong><small>{roleOf(other)} · {thread.title}</small></div></header>
              <div className="hm-bubbles" aria-live="polite">
                {messages.map(item => (
                  <div key={item.id} className={item.from === actor.username ? 'mine' : ''}>
                    <p>{item.text}</p>
                    <small>{formatTime(item.at)}</small>
                  </div>
                ))}
                {last?.from === actor.username && (thread.seen[other] || 0) >= last.at && <Badge tone="slate" icon="fa-check-double">Đã xem</Badge>}
                <span ref={end}></span>
              </div>
              <form onSubmit={send}>
                <label className="hm-sr" htmlFor="chat-input">Nội dung tin nhắn</label>
                <input id="chat-input" value={text} onChange={event => setText(event.target.value)} placeholder="Nhập tin nhắn, nhấn Enter để gửi" autoComplete="off" disabled={actor.readOnly} />
                <button type="submit" className="button primary" disabled={!text.trim() || actor.readOnly} aria-label="Gửi tin nhắn"><i className="fa-solid fa-paper-plane" aria-hidden="true"></i></button>
              </form>
            </>
          )}
        </section>
      </article>
    </>
  )
}
