import { useState } from 'react'
import { ROLE_LABELS, addTask, assigneesFor, patchTask, useStore } from './store'
import { formatDate } from './format'
import { Badge, Empty, Field, Modal, PageHead, Tabs, toast } from './ui'

const COLUMNS = [['new', 'Mới', 'slate'], ['doing', 'Đang làm', 'blue'], ['done', 'Hoàn thành', 'green']]
const PRIORITY = { high: ['Ưu tiên cao', 'red'], normal: ['Bình thường', 'slate'], low: ['Thấp', 'green'] }
const NEXT = { new: ['doing', 'Bắt đầu làm'], doing: ['done', 'Hoàn thành'] }

function TaskForm({ people, onClose }) {
  const [form, setForm] = useState({ title: '', description: '', assignee: people[0].username, priority: 'normal', due: new Date(Date.now() + 3 * 86400000).toISOString().slice(0, 10) })
  const set = key => event => setForm(current => ({ ...current, [key]: event.target.value }))
  const submit = event => {
    event.preventDefault()
    const record = addTask(form)
    if (record) toast(`Đã giao việc ${record.id}. Người nhận có thông báo ngay.`)
    onClose()
  }
  return (
    <Modal title="Giao việc" description="Ban giám đốc giao cho quản lý; quản lý giao cho giáo viên và nhân viên cùng cơ sở." onClose={onClose}>
      <form className="hm-form" onSubmit={submit}>
        <div className="hm-span-2"><Field label="Tên công việc">{id => <input id={id} required value={form.title} onChange={set('title')} />}</Field></div>
        <Field label="Người nhận">{id => <select id={id} value={form.assignee} onChange={set('assignee')}>{people.map(item => <option key={item.username} value={item.username}>{item.name} · {ROLE_LABELS[item.role]}</option>)}</select>}</Field>
        <Field label="Mức ưu tiên">{id => <select id={id} value={form.priority} onChange={set('priority')}>{Object.entries(PRIORITY).map(([key, [label]]) => <option key={key} value={key}>{label}</option>)}</select>}</Field>
        <Field label="Hạn hoàn thành">{id => <input id={id} type="date" required min={new Date().toISOString().slice(0, 10)} value={form.due} onChange={set('due')} />}</Field>
        <div className="hm-span-2"><Field label="Mô tả">{id => <textarea id={id} rows={3} value={form.description} onChange={set('description')} />}</Field></div>
        <div className="hm-form-actions">
          <button type="button" className="button" onClick={onClose}>Hủy</button>
          <button type="submit" className="button primary">Giao việc</button>
        </div>
      </form>
    </Modal>
  )
}

function TaskCard({ task, actor, nameOf }) {
  const [comment, setComment] = useState('')
  const mine = task.assignee === actor.username
  const late = task.status !== 'done' && task.due < Date.now()
  const next = NEXT[task.status]
  return (
    <article className={`hm-task${late ? ' late' : ''}`}>
      <header><strong>{task.title}</strong><Badge tone={PRIORITY[task.priority][1]}>{PRIORITY[task.priority][0]}</Badge></header>
      {task.description && <p>{task.description}</p>}
      <div className="hm-task-meta">
        <span><i className="fa-solid fa-user" aria-hidden="true"></i>{mine ? `Giao bởi ${nameOf(task.assigner)}` : `Giao cho ${nameOf(task.assignee)}`}</span>
        <Badge tone={late ? 'red' : 'slate'} icon="fa-calendar">{late ? 'Quá hạn ' : 'Hạn '}{formatDate(task.due)}</Badge>
      </div>
      {task.comments.length > 0 && (
        <ul className="hm-task-comments">
          {task.comments.map((item, index) => <li key={index}><strong>{item.from}:</strong> {item.text}</li>)}
        </ul>
      )}
      <form onSubmit={event => { event.preventDefault(); if (comment.trim() && patchTask(task.id, {}, comment.trim())) setComment('') }}>
        <label className="hm-sr" htmlFor={`comment-${task.id}`}>Bình luận công việc {task.id}</label>
        <input id={`comment-${task.id}`} value={comment} onChange={event => setComment(event.target.value)} placeholder="Viết bình luận…" />
        {mine && next && <button type="button" className="button small primary" onClick={() => { if (patchTask(task.id, { status: next[0] })) toast(`${task.id}: ${next[1].toLowerCase()}.`) }}>{next[1]}</button>}
      </form>
    </article>
  )
}

export default function TasksModule({ actor }) {
  const store = useStore()
  const [filter, setFilter] = useState('all')
  const [creating, setCreating] = useState(false)
  const people = assigneesFor(actor, store)
  const nameOf = username => store.accounts.find(item => item.username === username)?.name || username
  const received = store.tasks.filter(item => item.assignee === actor.username)
  const given = store.tasks.filter(item => item.assigner === actor.username)
  const tasks = filter === 'mine' ? received : filter === 'given' ? given : [...new Set([...received, ...given])]
  return (
    <>
      <PageHead title="Công việc" description="Giao việc có hạn và mức ưu tiên; người nhận cập nhật tiến độ, hai bên bình luận và nhận thông báo.">
        {people.length > 0 && <button type="button" className="button primary" disabled={actor.readOnly} onClick={() => setCreating(true)}><i className="fa-solid fa-plus" aria-hidden="true"></i>Giao việc</button>}
      </PageHead>
      <div className="hm-toolbar hm-loose">
        <Tabs label="Lọc công việc" value={filter} onChange={setFilter} tabs={[['all', 'Tất cả', new Set([...received, ...given]).size], ['mine', 'Của tôi', received.length], ['given', 'Tôi đã giao', given.length]]} />
      </div>
      <div className="hm-kanban">
        {COLUMNS.map(([status, label, tone]) => {
          const items = tasks.filter(item => item.status === status).sort((a, b) => a.due - b.due)
          return (
            <section key={status} className="hm-column" aria-label={label}>
              <header><span className={`hm-dot hm-${tone}`}></span><h3>{label}</h3><span className="hm-count">{items.length}</span></header>
              <div className="hm-column-body">
                {items.map(task => <TaskCard key={task.id} task={task} actor={actor} nameOf={nameOf} />)}
                {!items.length && <Empty icon="fa-list-check">Không có việc nào.</Empty>}
              </div>
            </section>
          )
        })}
      </div>
      {creating && <TaskForm people={people} onClose={() => setCreating(false)} />}
    </>
  )
}
