import { useEffect, useRef, useState } from 'react'
import { DEMO_MODE, ROLE_LABELS, changePassword, logout, markAllRead, markRead, notesFor, setViewAs, useStore } from './store'
import { timeAgo } from './format'
import { Avatar, Empty, Field, Modal, Tabs, navigate, toast } from './ui'

const NOTE_ICONS = {
  ticket: 'fa-headset', payroll: 'fa-money-check-dollar', invoice: 'fa-receipt', payment: 'fa-circle-check', lesson: 'fa-comment-dots',
  proposal: 'fa-calendar-plus', schedule: 'fa-calendar-days', task: 'fa-list-check', message: 'fa-envelope', account: 'fa-user-shield',
}

// Popover đóng khi bấm ra ngoài hoặc nhấn Esc.
function usePopover() {
  const [open, setOpen] = useState(false)
  const ref = useRef(null)
  useEffect(() => {
    if (!open) return undefined
    const close = event => { if (event.key === 'Escape' || (event.type === 'mousedown' && !ref.current?.contains(event.target))) setOpen(false) }
    document.addEventListener('mousedown', close)
    document.addEventListener('keydown', close)
    return () => {
      document.removeEventListener('mousedown', close)
      document.removeEventListener('keydown', close)
    }
  }, [open])
  return [open, setOpen, ref]
}

function searchIndex(store, actor) {
  const mine = item => actor.role === 'admin' || item.branch === actor.branch
  if (actor.role === 'parent') {
    return store.students.filter(item => item.parent === actor.username).map(item => ({ kind: 'Con của tôi', text: item.name, sub: item.id, tab: 'p-children' }))
  }
  if (['teacher', 'assistant'].includes(actor.role)) {
    const classes = store.classes.filter(item => item.teacher === actor.name)
    return [
      ...classes.map(item => ({ kind: 'Lớp', text: item.name, sub: `${item.size}/${item.capacity} học sinh`, tab: 't-classes' })),
      ...store.students.filter(item => classes.some(klass => klass.id === item.classId)).map(item => ({ kind: 'Học sinh', text: item.name, sub: item.id, tab: 't-classes' })),
    ]
  }
  return [
    ...store.students.filter(mine).map(item => ({ kind: 'Học viên', text: item.name, sub: `${item.id} · ${item.branch}`, tab: 'education' })),
    ...store.leads.filter(mine).map(item => ({ kind: 'Lead', text: item.parent, sub: `${item.student} · ${item.phone}`, tab: 'crm' })),
    ...store.classes.filter(mine).map(item => ({ kind: 'Lớp', text: item.name, sub: `GV ${item.teacher}`, tab: 'education' })),
    ...store.staff.filter(mine).map(item => ({ kind: 'Nhân sự', text: item.name, sub: `${item.role} · ${item.branch}`, tab: 'hr' })),
    ...store.tickets.filter(mine).map(item => ({ kind: 'Yêu cầu', text: `${item.id} · ${item.parent}`, sub: item.type, tab: 'support' })),
  ]
}

function GlobalSearch({ actor, tabs }) {
  const store = useStore()
  const [query, setQuery] = useState('')
  const [open, setOpen, ref] = usePopover()
  const input = useRef(null)
  useEffect(() => {
    const focus = event => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault()
        input.current?.focus()
      }
    }
    document.addEventListener('keydown', focus)
    return () => document.removeEventListener('keydown', focus)
  }, [])
  const text = query.trim().toLowerCase()
  const results = text
    ? searchIndex(store, actor).filter(item => tabs.includes(item.tab) && `${item.text} ${item.sub}`.toLowerCase().includes(text)).slice(0, 8)
    : []
  return (
    <div className="hm-search-box" ref={ref}>
      <label className="search">
        <i className="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
        <span className="hm-sr">Tìm kiếm toàn hệ thống</span>
        <input ref={input} type="search" value={query} placeholder="Tìm học viên, lead, lớp, nhân sự…" onChange={event => { setQuery(event.target.value); setOpen(true) }} onFocus={() => setOpen(true)} />
        <kbd>Ctrl K</kbd>
      </label>
      {open && text && (
        <div className="hm-popover hm-search-results" role="listbox">
          {!results.length && <Empty icon="fa-magnifying-glass">Không tìm thấy kết quả cho “{query}”.</Empty>}
          {results.map((item, index) => (
            <button key={index} type="button" role="option" aria-selected="false" onClick={() => { navigate(item.tab); setOpen(false); setQuery('') }}>
              <span className="hm-badge hm-orange">{item.kind}</span>
              <span><strong>{item.text}</strong><small>{item.sub}</small></span>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

function NotificationCenter({ actor }) {
  const store = useStore()
  const [open, setOpen, ref] = usePopover()
  const [filter, setFilter] = useState('all')
  const notes = notesFor(actor, store)
  const unread = notes.filter(note => !note.read)
  const shown = filter === 'unread' ? unread : notes
  const today = new Date().toDateString()
  const groups = [['Hôm nay', shown.filter(note => new Date(note.at).toDateString() === today)], ['Trước đó', shown.filter(note => new Date(note.at).toDateString() !== today)]]
  return (
    <div className="hm-bell" ref={ref}>
      {/* key theo số chưa đọc để chuông rung lại mỗi khi có thông báo mới */}
      <button key={unread.length} type="button" className={`icon-button${unread.length ? ' ringing' : ''}`} aria-label={`Thông báo, ${unread.length} chưa đọc`} aria-expanded={open} onClick={() => setOpen(!open)}>
        <i className="fa-solid fa-bell" aria-hidden="true"></i>
        {unread.length > 0 && <span className="hm-bell-badge">{unread.length > 99 ? '99+' : unread.length}</span>}
      </button>
      {open && (
        <div className="hm-popover hm-notes" role="dialog" aria-label="Trung tâm thông báo">
          <header>
            <strong>Thông báo</strong>
            <button type="button" className="hm-link" disabled={!unread.length} onClick={markAllRead}>Đọc tất cả</button>
          </header>
          <Tabs label="Lọc thông báo" value={filter} onChange={setFilter} tabs={[['all', 'Tất cả', notes.length], ['unread', 'Chưa đọc', unread.length]]} />
          <div className="hm-notes-list" aria-live="polite">
            {!shown.length && <Empty icon="fa-bell-slash">{filter === 'unread' ? 'Bạn đã đọc hết thông báo.' : 'Chưa có thông báo nào.'}</Empty>}
            {groups.map(([label, items]) => items.length > 0 && (
              <section key={label}>
                <h3>{label}</h3>
                {items.map(note => (
                  <button key={note.id} type="button" className={note.read ? '' : 'unread'} onClick={() => { markRead(note.id); navigate(note.tab); setOpen(false) }}>
                    <span className="hm-note-icon"><i className={`fa-solid ${NOTE_ICONS[note.type] || 'fa-bell'}`} aria-hidden="true"></i></span>
                    <span><strong>{note.title}</strong><small>{note.body}</small><em>{timeAgo(note.at)}</em></span>
                  </button>
                ))}
              </section>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

function PasswordModal({ onClose }) {
  const [form, setForm] = useState({ current: '', next: '', confirm: '' })
  const [error, setError] = useState('')
  const set = key => event => setForm(value => ({ ...value, [key]: event.target.value }))
  const submit = async event => {
    event.preventDefault()
    if (form.next !== form.confirm) return setError('Mật khẩu nhập lại chưa khớp.')
    const result = await changePassword(form.current, form.next)
    if (!result.ok) return setError(result.message)
    toast('Đã đổi mật khẩu.')
    return onClose()
  }
  return (
    <Modal title="Đổi mật khẩu" onClose={onClose}>
      <form className="hm-form" onSubmit={submit}>
        <div className="hm-span-2"><Field label="Mật khẩu hiện tại">{id => <input id={id} type="password" required value={form.current} onChange={set('current')} />}</Field></div>
        <Field label="Mật khẩu mới" hint="Ít nhất 8 ký tự, có chữ và số.">{id => <input id={id} type="password" required minLength={8} value={form.next} onChange={set('next')} />}</Field>
        <Field label="Nhập lại mật khẩu mới" error={error}>{id => <input id={id} type="password" required minLength={8} value={form.confirm} onChange={set('confirm')} />}</Field>
        <div className="hm-form-actions">
          <button type="button" className="button" onClick={onClose}>Hủy</button>
          <button type="submit" className="button primary">Lưu mật khẩu</button>
        </div>
      </form>
    </Modal>
  )
}

function AvatarMenu({ actor }) {
  const [open, setOpen, ref] = usePopover()
  const [dialog, setDialog] = useState('')
  const canViewAs = DEMO_MODE && actor.realRole === 'admin'
  return (
    <div className="hm-user" ref={ref}>
      <button type="button" className="hm-user-button" aria-haspopup="menu" aria-expanded={open} onClick={() => setOpen(!open)}>
        <Avatar name={actor.name} />
        <span className="user-meta"><strong>{actor.name}</strong><small>{ROLE_LABELS[actor.role]}{actor.branch ? ` · ${actor.branch}` : ''}</small></span>
        <i className="fa-solid fa-chevron-down" aria-hidden="true"></i>
      </button>
      {open && (
        <div className="hm-popover hm-menu" role="menu">
          <button type="button" role="menuitem" onClick={() => { setDialog('profile'); setOpen(false) }}><i className="fa-solid fa-id-badge" aria-hidden="true"></i>Hồ sơ của tôi</button>
          <button type="button" role="menuitem" disabled={actor.readOnly} onClick={() => { setDialog('password'); setOpen(false) }}><i className="fa-solid fa-key" aria-hidden="true"></i>Đổi mật khẩu</button>
          {canViewAs && (
            <label className="hm-menu-select">
              <span><i className="fa-solid fa-eye" aria-hidden="true"></i>Xem với tư cách</span>
              <select value={actor.readOnly ? actor.role : 'admin'} onChange={event => { setViewAs(event.target.value); setOpen(false) }}>
                {['admin', 'manager', 'teacher', 'accountant', 'parent'].map(role => <option key={role} value={role}>{ROLE_LABELS[role]}</option>)}
              </select>
            </label>
          )}
          <button type="button" role="menuitem" className="danger" onClick={logout}><i className="fa-solid fa-arrow-right-from-bracket" aria-hidden="true"></i>Đăng xuất</button>
        </div>
      )}
      {dialog === 'profile' && (
        <Modal title="Hồ sơ của tôi" onClose={() => setDialog('')}>
          <dl className="hm-facts">
            <div><dt>Họ tên</dt><dd>{actor.name}</dd></div>
            <div><dt>Tên đăng nhập</dt><dd>{actor.username}</dd></div>
            <div><dt>Vai trò</dt><dd>{ROLE_LABELS[actor.role]}</dd></div>
            <div><dt>Cơ sở</dt><dd>{actor.branch || 'Toàn hệ thống (5 cơ sở)'}</dd></div>
            <div><dt>Email</dt><dd>{actor.email}</dd></div>
            <div><dt>Số điện thoại</dt><dd>{actor.phone || 'Chưa cập nhật'}</dd></div>
          </dl>
        </Modal>
      )}
      {dialog === 'password' && <PasswordModal onClose={() => setDialog('')} />}
    </div>
  )
}

export default function Topbar({ actor, title, tabs }) {
  return (
    <header className="topbar hm-topbar">
      <h1 className="hm-topbar-title">{title}</h1>
      <GlobalSearch actor={actor} tabs={tabs} />
      <div className="hm-topbar-right">
        <NotificationCenter actor={actor} />
        <AvatarMenu actor={actor} />
      </div>
    </header>
  )
}
