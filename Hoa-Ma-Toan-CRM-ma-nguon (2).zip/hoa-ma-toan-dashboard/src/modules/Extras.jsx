import { useRef, useState } from 'react'
import {
  BRANCHES, DAYS, RENEWAL_STATUSES, SHIFTS,
  assignShift, importStaff, removeShift, setRenewal, shiftClashes, toggleAutomation,
} from './store'
import { parseCsv, percent } from './format'
import { Badge, Empty, Kpi, Modal, Switch, toast } from './ui'

// ---- Nhân sự: lịch trực tuần × ca ----
export function ShiftBoard({ staff, shifts, scope }) {
  const [picked, setPicked] = useState(BRANCHES[0])
  const branch = scope === 'all' ? picked : scope
  const people = staff.filter(item => item.branch === branch)
  const mine = shifts.filter(item => item.branch === branch)
  const clashes = shiftClashes(mine)
  const nameOf = id => staff.find(item => item.id === id)?.name || id
  return (
    <>
      <div className={`hm-scan ${clashes.length ? 'bad' : 'good'}`} role="status">
        <i className={`fa-solid ${clashes.length ? 'fa-triangle-exclamation' : 'fa-shield-halved'}`} aria-hidden="true"></i>
        <div>
          <strong>{clashes.length ? `${new Set(clashes.map(item => `${item.staffId}-${item.day}`)).size} trường hợp một người trực nhiều ca trong ngày` : `Lịch trực cơ sở ${branch}: không ai bị xếp trùng ca trong ngày`}</strong>
          {[...new Set(clashes.map(item => `${nameOf(item.staffId)} · ${DAYS[item.day]}`))].map(text => <p key={text}>{text}</p>)}
        </div>
        {scope === 'all' && (
          <label className="hm-inline-select">
            <span className="hm-sr">Cơ sở xem lịch trực</span>
            <select value={picked} onChange={event => setPicked(event.target.value)}>{BRANCHES.map(item => <option key={item}>{item}</option>)}</select>
          </label>
        )}
      </div>
      <div className="table-wrap">
        <table className="hm-shifts">
          <thead><tr><th>CA TRỰC</th>{DAYS.map(day => <th key={day}>{day.toUpperCase()}</th>)}</tr></thead>
          <tbody>
            {SHIFTS.map((label, shift) => (
              <tr key={label}>
                <th scope="row">{label}</th>
                {DAYS.map((day, index) => {
                  const cell = mine.filter(item => item.day === index && item.shift === shift)
                  const free = people.filter(person => !cell.some(item => item.staffId === person.id))
                  return (
                    <td key={day}>
                      {cell.map(item => (
                        <span key={item.id} className={`hm-chip${clashes.includes(item) ? ' bad' : ''}`}>
                          {nameOf(item.staffId)}
                          <button type="button" aria-label={`Bỏ ${nameOf(item.staffId)} khỏi ca ${label} ${day}`} onClick={() => removeShift(item.id)}><i className="fa-solid fa-xmark" aria-hidden="true"></i></button>
                        </span>
                      ))}
                      {free.length > 0 && (
                        <select className="hm-chip-add" aria-label={`Thêm người trực ca ${label} ${day}`} value="" onChange={event => assignShift(branch, index, shift, event.target.value)}>
                          <option value="">＋ Thêm</option>
                          {free.map(person => <option key={person.id} value={person.id}>{person.name}</option>)}
                        </select>
                      )}
                    </td>
                  )
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  )
}

// ---- Nhân sự: nhập danh sách từ file CSV ----
export function StaffImport({ branch }) {
  const input = useRef(null)
  const read = async event => {
    const file = event.target.files[0]
    event.target.value = ''
    if (!file) return
    const [head, ...rows] = parseCsv(await file.text())
    const column = name => head.findIndex(title => title.trim().toLowerCase().includes(name))
    const at = { name: column('họ tên'), role: column('vị trí'), phone: column('sđt'), contract: column('hợp đồng'), salary: column('lương') }
    if (at.name < 0 || at.phone < 0) {
      toast('File cần có ít nhất hai cột “Họ tên” và “SĐT”. Hãy dùng file xuất từ nút “Xuất danh sách” làm mẫu.')
      return
    }
    const result = importStaff(rows.map(row => Object.fromEntries(Object.entries(at).map(([key, index]) => [key, row[index] || '']))), branch)
    toast(`Đã nhập ${result.added} nhân sự vào cơ sở ${branch}${result.skipped ? `, bỏ qua ${result.skipped} dòng thiếu tên, sai hoặc trùng SĐT` : ''}.`)
  }
  return (
    <>
      <input ref={input} type="file" accept=".csv,text/csv" hidden onChange={read} />
      <button type="button" className="button" onClick={() => input.current.click()}><i className="fa-solid fa-file-import" aria-hidden="true"></i>Nhập danh sách</button>
    </>
  )
}

// ---- CSKH: kịch bản tự động ZNS/SMS ----
const SAMPLE = { phu_huynh: 'chị Lê Thị Mai', hoc_sinh: 'Lê Bảo Nam', thang: '11/2026', so_tien: '3.000.000 đ', han: '20/11/2026', lop: 'Luyện thi vào 10', gio: '19:15', phong: 'P.201' }
const fill = template => template.replace(/\{(\w+)\}/g, (match, key) => SAMPLE[key] || match)

export function Automations({ items }) {
  const [preview, setPreview] = useState(null)
  return (
    <>
      <div className="hm-auto-grid">
        {items.map(item => (
          <article key={item.id} className={`hm-auto${item.enabled ? '' : ' off'}`}>
            <header>
              <Badge tone={item.channel === 'ZNS' ? 'blue' : 'purple'} icon={item.channel === 'ZNS' ? 'fa-comment-dots' : 'fa-message'}>{item.channel}</Badge>
              <Switch label={`Bật kịch bản ${item.name}`} checked={item.enabled} onChange={() => { if (toggleAutomation(item.id)) toast(`${item.name}: ${item.enabled ? 'đã tắt' : 'đã bật'}.`) }} />
            </header>
            <h3>{item.name}</h3>
            <dl>
              <div><dt>Điều kiện gửi</dt><dd>{item.trigger}</dd></div>
              <div><dt>Giờ gửi</dt><dd>{item.schedule} hằng ngày</dd></div>
              <div><dt>Đã gửi tháng này</dt><dd>{item.sent.toLocaleString('vi-VN')} tin</dd></div>
            </dl>
            <button type="button" className="button small" onClick={() => setPreview(item)}><i className="fa-solid fa-eye" aria-hidden="true"></i>Xem trước tin nhắn</button>
          </article>
        ))}
      </div>
      <p className="hm-form-note">Bản demo mô phỏng lịch gửi; nối nhà cung cấp ZNS/SMS thật thuộc giai đoạn 2.</p>
      {preview && (
        <Modal title={`Xem trước: ${preview.name}`} description={`${preview.channel} · gửi lúc ${preview.schedule} · ${preview.trigger.toLowerCase()}`} onClose={() => setPreview(null)}>
          <div className="hm-phone"><p>{fill(preview.template)}</p><small>{fill(preview.template).length} ký tự · dữ liệu mẫu</small></div>
          <p className="hm-form-note">Mẫu gốc: {preview.template}</p>
        </Modal>
      )}
    </>
  )
}

// ---- CSKH: gia hạn khóa học ----
const RENEWAL_TONE = { 'Chưa liên hệ': 'amber', 'Đã liên hệ': 'blue', 'Đã tái đăng ký': 'green', 'Không tiếp tục': 'red' }

export function Renewals({ items }) {
  const renewed = items.filter(item => item.status === 'Đã tái đăng ký').length
  const decided = items.filter(item => ['Đã tái đăng ký', 'Không tiếp tục'].includes(item.status)).length
  const rows = [...items].sort((a, b) => a.endsInDays - b.endsInDays)
  return (
    <>
      <div className="kpi-grid three">
        <Kpi label="Sắp hết hạn khóa học" value={items.filter(item => item.status !== 'Đã tái đăng ký').length} icon="fa-hourglass-half" tone="warn" note={`${items.filter(item => item.endsInDays <= 7).length} học viên hết hạn trong 7 ngày`} />
        <Kpi label="Chưa liên hệ" value={items.filter(item => item.status === 'Chưa liên hệ').length} icon="fa-phone-slash" tone={items.some(item => item.status === 'Chưa liên hệ') ? 'bad' : 'good'} note="Cần gọi trước khi khóa kết thúc" />
        <Kpi label="Tỷ lệ tái đăng ký" value={percent(renewed, decided)} unit="%" icon="fa-rotate" note={`${renewed}/${decided} học viên đã có quyết định`} />
      </div>
      {!rows.length && <Empty icon="fa-rotate">Chưa có học viên nào sắp hết hạn.</Empty>}
      <div className="table-wrap">
        <table>
          <thead><tr><th>HỌC VIÊN</th><th>KHÓA HỌC</th><th>PHỤ HUYNH</th><th>SĐT</th><th>CƠ SỞ</th><th>CÒN LẠI</th><th>TRẠNG THÁI LIÊN HỆ</th></tr></thead>
          <tbody>
            {rows.map(item => (
              <tr key={item.id}>
                <td><strong>{item.student}</strong></td><td>{item.classLabel}</td><td>{item.parent}</td><td>{item.phone}</td><td>{item.branch}</td>
                <td><Badge tone={item.endsInDays <= 7 ? 'red' : 'slate'} icon="fa-clock">{item.endsInDays} ngày</Badge></td>
                <td>
                  <label className={`hm-inline-select hm-${RENEWAL_TONE[item.status]}`}>
                    <span className="hm-sr">Trạng thái liên hệ của {item.student}</span>
                    <select value={item.status} onChange={event => { if (setRenewal(item.id, event.target.value)) toast(`${item.student}: ${event.target.value.toLowerCase()}.`) }}>
                      {RENEWAL_STATUSES.map(status => <option key={status}>{status}</option>)}
                    </select>
                  </label>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  )
}
