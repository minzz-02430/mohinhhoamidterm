import { useEffect, useState } from 'react'
import QRCode from 'qrcode'
import { BANKS, DAYS, addTicket, invoiceState, invoiceTotal, payInvoice, ticketSla, transferNote, useStore } from './store'
import { buildVietQrPayload, buildVietQrUrl } from './vietqr'
import { formatDate, formatMoney, percent } from './format'
import { Avatar, Badge, Empty, Field, Kpi, Modal, PageHead, Progress, toast } from './ui'

const STATE = { pending: ['Chờ thanh toán', 'amber'], overdue: ['Quá hạn', 'red'], awaiting: ['Chờ trung tâm xác nhận', 'blue'], paid: ['Đã thanh toán', 'green'] }
const ATTENDANCE = { present: ['Có mặt', 'green'], late: ['Đi muộn', 'amber'], absent: ['Vắng', 'red'] }
const TICKET_STATUS = { new: ['Đã tiếp nhận', 'amber'], processing: ['Đang xử lý', 'blue'], done: ['Hoàn thành', 'green'] }

function CopyRow({ label, value }) {
  return (
    <div>
      <dt>{label}</dt>
      <dd>
        <strong>{value}</strong>
        <button type="button" className="hm-icon-btn" aria-label={`Sao chép ${label}`} onClick={() => navigator.clipboard?.writeText(String(value)).then(() => toast(`Đã sao chép ${label.toLowerCase()}.`))}>
          <i className="fa-solid fa-copy" aria-hidden="true"></i>
        </button>
      </dd>
    </div>
  )
}

// Thanh toán VietQR: số tiền và nội dung do hệ thống tính, phụ huynh không sửa được. Mã QR sinh ngay trên máy.
function PaymentModal({ invoice, bank, onClose }) {
  const [qr, setQr] = useState('')
  const [error, setError] = useState('')
  const [left, setLeft] = useState(15 * 60)
  const [sent, setSent] = useState(false)
  const total = invoiceTotal(invoice)
  const note = transferNote(invoice)

  // Có mạng: dùng ảnh Quick Link của VietQR. Mất mạng hoặc ảnh lỗi: tự sinh mã chuẩn EMVCo ngay trên máy.
  const [offline, setOffline] = useState(!navigator.onLine)
  useEffect(() => {
    try {
      if (!offline) {
        setQr(buildVietQrUrl({ bankId: BANKS[bank.bankId], accountNo: bank.accountNo, amount: total, addInfo: note, accountName: bank.accountName }))
        return
      }
      QRCode.toDataURL(buildVietQrPayload({ bin: BANKS[bank.bankId], accountNo: bank.accountNo, amount: total, addInfo: note }), { margin: 1, width: 240, errorCorrectionLevel: 'M' })
        .then(setQr, () => setError('Không tạo được mã QR. Vui lòng chuyển khoản theo thông tin bên cạnh.'))
    } catch (problem) {
      setError(problem.message)
    }
  }, [bank, total, note, offline])
  useEffect(() => {
    const timer = window.setInterval(() => setLeft(value => Math.max(0, value - 1)), 1000)
    return () => window.clearInterval(timer)
  }, [])

  const confirm = () => {
    if (!payInvoice(invoice.id)) return
    setSent(true)
    toast('Đã báo trung tâm. Hóa đơn chuyển sang “Chờ trung tâm xác nhận”.')
  }

  return (
    <Modal wide title="Thanh toán học phí bằng VietQR" description={`Hóa đơn ${invoice.id} · ${invoice.student} · tháng ${invoice.month}`} onClose={onClose}>
      {sent ? (
        <div className="hm-success">
          <div className="hm-confetti" aria-hidden="true">{Array.from({ length: 18 }, (_, index) => <i key={index} style={{ '--i': index }}></i>)}</div>
          <svg viewBox="0 0 52 52" aria-hidden="true"><circle cx="26" cy="26" r="24" /><path d="M15 27l8 8 15-17" /></svg>
          <strong>Đã ghi nhận chuyển khoản {formatMoney(total)}</strong>
          <p>Kế toán sẽ đối soát và xác nhận. Bạn nhận thông báo ngay khi hóa đơn chuyển sang “Đã thanh toán”.</p>
          <button type="button" className="button primary" onClick={onClose}>Đóng</button>
        </div>
      ) : (
        <div className="hm-pay">
          <div className="hm-qr">
            {qr ? <img src={qr} alt={`Mã VietQR thanh toán ${formatMoney(total)}`} width="240" onError={() => { setQr(''); setOffline(true) }} /> : <div className="hm-qr-wait" role="status">{error || 'Đang tạo mã QR…'}</div>}
            <Badge tone={left ? 'amber' : 'red'} icon="fa-clock">{left ? `Mã còn hiệu lực ${String(Math.floor(left / 60)).padStart(2, '0')}:${String(left % 60).padStart(2, '0')}` : 'Mã đã hết hạn, hãy mở lại'}</Badge>
            {offline && <Badge tone="slate" icon="fa-plane">Chế độ ngoại tuyến: mã tạo ngay trên máy</Badge>}
            <small>Mở ứng dụng ngân hàng, chọn quét mã QR để thanh toán.</small>
          </div>
          <div>
            <dl className="hm-facts hm-copy">
              <CopyRow label="Số tiền" value={formatMoney(total)} />
              <CopyRow label="Ngân hàng" value={bank.bankId} />
              <CopyRow label="Số tài khoản" value={bank.accountNo} />
              <CopyRow label="Người thụ hưởng" value={bank.accountName} />
              <CopyRow label="Nội dung chuyển khoản" value={note} />
            </dl>
            <p className="hm-form-note">Số tiền và nội dung do hệ thống tính từ hóa đơn, không sửa được.</p>
            <div className="hm-form-actions">
              <button type="button" className="button" onClick={onClose}>Để sau</button>
              <button type="button" className="button primary" disabled={!left} onClick={confirm}><i className="fa-solid fa-check" aria-hidden="true"></i>Tôi đã chuyển khoản</button>
            </div>
          </div>
        </div>
      )}
    </Modal>
  )
}

function Children({ kids: children, store }) {
  return (
    <div className="hm-child-grid">
      {children.map(child => {
        const klass = store.classes.find(item => item.id === child.classId)
        return (
          <article key={child.id} className="card hm-child">
            <Avatar name={child.name} />
            <div>
              <h2>{child.name}</h2>
              <p>{child.id} · {child.grade} · sinh {child.birth}</p>
              <dl className="hm-facts">
                <div><dt>Lớp đang học</dt><dd>{klass?.name || 'Chưa xếp lớp'}</dd></div>
                <div><dt>Giáo viên</dt><dd>{klass?.teacher || '—'}</dd></div>
                <div><dt>Cơ sở</dt><dd>{child.branch}</dd></div>
                <div><dt>Buổi mỗi tuần</dt><dd>{store.sessions.filter(item => item.classId === child.classId).length} buổi</dd></div>
              </dl>
            </div>
          </article>
        )
      })}
    </div>
  )
}

function Schedule({ kids: children, store }) {
  return children.map(child => {
    const sessions = store.sessions.filter(item => item.classId === child.classId).sort((a, b) => a.day - b.day || a.start.localeCompare(b.start))
    return (
      <article key={child.id} className="card">
        <h2 className="card-title">{child.name} <span className="muted">{store.classes.find(item => item.id === child.classId)?.name}</span></h2>
        {!sessions.length && <Empty icon="fa-calendar-xmark">Chưa có lịch học.</Empty>}
        <div className="hm-week compact">
          {DAYS.map((day, index) => {
            const items = sessions.filter(item => item.day === index)
            return (
              <section key={day} className="hm-day" aria-label={day}>
                <h3>{day}</h3>
                {items.map(item => (
                  <div key={item.id} className="hm-slot">
                    <span className="hm-slot-time">{item.start}–{item.end}</span>
                    <strong>{item.room}</strong>
                    <small>GV {item.teacher}</small>
                    {item.makeup && <Badge tone="blue">{item.makeup}</Badge>}
                  </div>
                ))}
                {!items.length && <p className="hm-day-empty">Nghỉ</p>}
              </section>
            )
          })}
        </div>
      </article>
    )
  })
}

function Results({ kids: children, store }) {
  return children.map(child => {
    const rows = store.lessons.filter(lesson => lesson.done).flatMap(lesson => lesson.students.filter(item => item.name === child.name).map(item => ({ lesson, item })))
    const attended = rows.filter(row => row.item.status !== 'absent').length
    const scores = rows.map(row => Number(row.item.score)).filter(Boolean)
    const average = scores.length ? scores.reduce((sum, value) => sum + value, 0) / scores.length : 0
    return (
      <article key={child.id} className="card hm-panel">
        <div className="hm-toolbar">
          <h2 className="card-title hm-flat">{child.name}</h2>
          <div className="hm-result-stats">
            <span>Chuyên cần <strong>{percent(attended, rows.length)}%</strong></span>
            <Progress value={percent(attended, rows.length)} tone="green" label={`Chuyên cần của ${child.name}`} />
            <span>Điểm trung bình <strong>{average ? average.toFixed(1) : '—'}</strong></span>
          </div>
        </div>
        {!rows.length && <Empty icon="fa-comment-dots">Chưa có nhận xét nào. Giáo viên gửi nhận xét trong 24 giờ sau mỗi buổi học.</Empty>}
        {rows.length > 0 && (
          <div className="table-wrap">
            <table>
              <thead><tr><th>BUỔI HỌC</th><th>NỘI DUNG</th><th>ĐIỂM DANH</th><th>ĐIỂM BTVN</th><th>NHẬN XÉT CỦA GIÁO VIÊN</th></tr></thead>
              <tbody>
                {rows.map(({ lesson, item }) => (
                  <tr key={lesson.id}>
                    <td><strong>{lesson.id}</strong><br /><small>GV {lesson.teacher}</small></td>
                    <td>{lesson.topic}</td>
                    <td><Badge tone={ATTENDANCE[item.status][1]}>{ATTENDANCE[item.status][0]}</Badge></td>
                    <td><strong>{item.score || '—'}</strong></td>
                    <td className="hm-wrap">{item.comment || (item.status === 'absent' ? 'Con vắng buổi này.' : '—')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </article>
    )
  })
}

function Fees({ invoices, bank }) {
  const [paying, setPaying] = useState(null)
  const now = Date.now()
  const open = invoices.filter(item => item.status !== 'paid')
  const paid = invoices.filter(item => item.status === 'paid').sort((a, b) => b.paidAt - a.paidAt)
  const due = open.filter(item => item.status === 'pending')
  return (
    <>
      <div className="kpi-grid three">
        <Kpi label="Cần thanh toán" value={due.reduce((sum, item) => sum + invoiceTotal(item), 0)} format={value => formatMoney(value)} icon="fa-file-invoice-dollar" tone={due.length ? 'warn' : 'good'} note={due.length ? `${due.length} hóa đơn chưa thanh toán` : 'Không còn khoản nào'} />
        <Kpi label="Chờ trung tâm xác nhận" value={open.length - due.length} icon="fa-hourglass-half" note="Đã chuyển khoản, chờ đối soát" />
        <Kpi label="Đã thanh toán" value={paid.reduce((sum, item) => sum + invoiceTotal(item), 0)} format={value => formatMoney(value)} icon="fa-circle-check" note={`${paid.length} hóa đơn`} />
      </div>
      {!open.length && <article className="card"><Empty icon="fa-circle-check">Bạn đã thanh toán hết học phí. Cảm ơn bạn!</Empty></article>}
      <div className="hm-invoice-grid">
        {open.map(item => {
          const [label, tone] = STATE[invoiceState(item, now)]
          return (
            <article key={item.id} className="card hm-invoice">
              <header><div><strong>{item.student}</strong><small>{item.classLabel} · hóa đơn {item.id} · tháng {item.month}</small></div><Badge tone={tone}>{label}</Badge></header>
              <dl>
                <div><dt>{item.sessions} buổi × {formatMoney(item.unitPrice)}</dt><dd>{formatMoney(item.sessions * item.unitPrice)}</dd></div>
                <div><dt>Khấu trừ buổi nghỉ có phép</dt><dd>−{formatMoney(item.deduction)}</dd></div>
                <div><dt>Phụ phí tài liệu</dt><dd>+{formatMoney(item.extra)}</dd></div>
                <div className="total"><dt>Tổng cộng</dt><dd>{formatMoney(invoiceTotal(item))}</dd></div>
              </dl>
              <footer>
                <span>Hạn thanh toán: <strong>{formatDate(item.dueDate)}</strong></span>
                {item.status === 'pending'
                  ? <button type="button" className="button primary" onClick={() => setPaying(item)}><i className="fa-solid fa-qrcode" aria-hidden="true"></i>Thanh toán VietQR</button>
                  : <span className="hm-form-note">Đã báo chuyển khoản, đang chờ kế toán xác nhận.</span>}
              </footer>
            </article>
          )
        })}
      </div>
      <article className="card hm-panel">
        <div className="hm-toolbar"><h2 className="card-title hm-flat">Lịch sử thanh toán</h2></div>
        {!paid.length && <Empty icon="fa-receipt">Chưa có khoản thanh toán nào.</Empty>}
        {paid.length > 0 && (
          <div className="table-wrap">
            <table>
              <thead><tr><th>HÓA ĐƠN</th><th>HỌC VIÊN</th><th>KỲ</th><th>SỐ TIỀN</th><th>NGÀY THANH TOÁN</th><th>TRẠNG THÁI</th></tr></thead>
              <tbody>
                {paid.map(item => (
                  <tr key={item.id}><td><strong>{item.id}</strong></td><td>{item.student}</td><td>{item.month}</td><td>{formatMoney(invoiceTotal(item))}</td><td>{formatDate(item.paidAt)}</td><td><Badge tone="green">Đã thanh toán</Badge></td></tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </article>
      {paying && <PaymentModal invoice={paying} bank={bank} onClose={() => setPaying(null)} />}
    </>
  )
}

function Requests({ actor, kids: children, tickets }) {
  const [form, setForm] = useState({ type: 'Xin nghỉ', student: children[0]?.name || '', content: '' })
  const set = key => event => setForm(current => ({ ...current, [key]: event.target.value }))
  const submit = event => {
    event.preventDefault()
    const ticket = addTicket({ ...form, parent: actor.name, parentUser: actor.username, phone: actor.phone, channel: 'Cổng phụ huynh', branch: actor.branch })
    toast(`Đã gửi yêu cầu ${ticket.id}. Quản lý cơ sở phản hồi trong 24 giờ.`)
    setForm(current => ({ ...current, content: '' }))
  }
  return (
    <div className="grid-2 reverse">
      <article className="card">
        <h2 className="card-title">Gửi yêu cầu mới</h2>
        <form className="hm-form" onSubmit={submit}>
          <Field label="Loại yêu cầu">{id => <select id={id} value={form.type} onChange={set('type')}>{['Xin nghỉ', 'Đổi lớp', 'Học phí', 'Khiếu nại', 'Phản hồi'].map(item => <option key={item}>{item}</option>)}</select>}</Field>
          <Field label="Học sinh">{id => <select id={id} value={form.student} onChange={set('student')}>{children.map(item => <option key={item.id}>{item.name}</option>)}</select>}</Field>
          <div className="hm-span-2"><Field label="Nội dung">{id => <textarea id={id} rows={4} required value={form.content} onChange={set('content')} placeholder="Ví dụ: Con xin nghỉ buổi Thứ 5 do có lịch khám." />}</Field></div>
          <div className="hm-form-actions"><button type="submit" className="button primary"><i className="fa-solid fa-paper-plane" aria-hidden="true"></i>Gửi yêu cầu</button></div>
        </form>
      </article>
      <article className="card">
        <h2 className="card-title">Yêu cầu của tôi <Badge tone="orange">{tickets.length}</Badge></h2>
        {!tickets.length && <Empty>Bạn chưa gửi yêu cầu nào.</Empty>}
        <ul className="hm-ticket-list">
          {tickets.map(item => (
            <li key={item.id} className="hm-ticket">
              <div className="hm-ticket-head"><strong>{item.id}</strong><Badge tone="slate">{item.type}</Badge><Badge tone={TICKET_STATUS[item.status][1]}>{TICKET_STATUS[item.status][0]}</Badge>{item.status !== 'done' && <Badge tone="slate" icon="fa-stopwatch">{ticketSla(item).label}</Badge>}</div>
              <p>{item.content}</p>
              {item.reply && <p className="hm-reply"><i className="fa-solid fa-reply" aria-hidden="true"></i><span><strong>Trung tâm phản hồi:</strong> {item.reply}</span></p>}
            </li>
          ))}
        </ul>
      </article>
    </div>
  )
}

const HEADS = {
  'p-children': ['Con đang theo học', 'Thông tin lớp, giáo viên và cơ sở của từng con.'],
  'p-schedule': ['Lịch học của con', 'Lịch cố định trong tuần, gồm cả buổi dạy bù đã được duyệt.'],
  'p-results': ['Kết quả học tập', 'Điểm danh, điểm bài tập và nhận xét giáo viên gửi sau mỗi buổi học.'],
  'p-fees': ['Học phí', 'Hóa đơn = số buổi × đơn giá − khấu trừ + phụ phí. Thanh toán bằng mã VietQR.'],
  'p-requests': ['Yêu cầu hỗ trợ', 'Xin nghỉ, đổi lớp, hỏi học phí hoặc gửi phản ánh tới cơ sở.'],
}

export default function ParentModule({ actor, tab }) {
  const store = useStore()
  const children = store.students.filter(item => item.parent === actor.username)
  const [title, description] = HEADS[tab]
  return (
    <>
      <PageHead title={title} description={description} />
      {!children.length && <article className="card"><Empty icon="fa-link-slash">Tài khoản chưa được liên kết với học viên nào. Vui lòng liên hệ trung tâm.</Empty></article>}
      {tab === 'p-children' && <Children kids={children} store={store} />}
      {tab === 'p-schedule' && <Schedule kids={children} store={store} />}
      {tab === 'p-results' && <Results kids={children} store={store} />}
      {tab === 'p-fees' && <Fees invoices={store.invoices.filter(item => item.parentUser === actor.username)} bank={store.settings.bank} />}
      {tab === 'p-requests' && <Requests actor={actor} kids={children} tickets={store.tickets.filter(item => item.parentUser === actor.username)} />}
    </>
  )
}
