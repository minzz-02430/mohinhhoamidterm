import { useState } from 'react'
import { BRANCHES, myBranch, addTicket, setTicket, ticketSla, useStore } from './store'
import { Automations, Renewals } from './Extras'
import { Badge, BranchFilter, Empty, Field, Kpi, Modal, PageHead, Tabs, branchScope, inScope, percent } from './ui'

const TYPES = ['Xin nghỉ', 'Đổi lớp', 'Học phí', 'Khiếu nại', 'Phản hồi']
const typeTone = { 'Xin nghỉ': 'blue', 'Đổi lớp': 'purple', 'Học phí': 'amber', 'Khiếu nại': 'red', 'Phản hồi': 'green' }
const statusMeta = { new: ['Mới', 'amber'], processing: ['Đang xử lý', 'blue'], done: ['Hoàn thành', 'green'] }
const slaTone = { done: 'green', ok: 'slate', risk: 'amber', late: 'red' }
const channelIcon = { Chatbot: 'fa-robot', Zalo: 'fa-comment-dots', Hotline: 'fa-phone', 'Cổng phụ huynh': 'fa-globe' }
const integrations = [
  ['fa-inbox', 'Hộp thư tư vấn', 'Gom email tư vấn về một hàng đợi chung'],
  ['fa-comments', 'Zalo OA · Facebook', 'Kênh tuyển sinh chính, tự tạo lead từ tin nhắn'],
  ['fa-chart-simple', 'Lượt truy cập website', 'Theo dõi phụ huynh xem trang tuyển sinh'],
]

function TicketForm({ role, onClose, notify }) {
  const [form, setForm] = useState({ parent: '', student: '', type: TYPES[0], content: '', channel: 'Hotline', branch: role === 'admin' ? BRANCHES[0] : myBranch() })
  const set = key => event => setForm(current => ({ ...current, [key]: event.target.value }))
  return (
    <Modal title="Tạo yêu cầu hỗ trợ" description="Mỗi yêu cầu có hạn phản hồi 24 giờ kể từ lúc tiếp nhận." onClose={onClose}>
      <form className="hm-form" onSubmit={event => { event.preventDefault(); const ticket = addTicket(form); notify(`Đã tạo yêu cầu ${ticket.id}.`); onClose() }}>
        <Field label="Phụ huynh">{id => <input id={id} required value={form.parent} onChange={set('parent')} />}</Field>
        <Field label="Học sinh">{id => <input id={id} required value={form.student} onChange={set('student')} />}</Field>
        <Field label="Loại yêu cầu">{id => <select id={id} value={form.type} onChange={set('type')}>{TYPES.map(item => <option key={item}>{item}</option>)}</select>}</Field>
        <Field label="Kênh tiếp nhận">{id => <select id={id} value={form.channel} onChange={set('channel')}>{Object.keys(channelIcon).map(item => <option key={item}>{item}</option>)}</select>}</Field>
        <div className="hm-span-2">
          <Field label="Nội dung">{id => <textarea id={id} required rows={3} value={form.content} onChange={set('content')} />}</Field>
        </div>
        <div className="hm-form-actions">
          <button type="button" className="button" onClick={onClose}>Hủy</button>
          <button type="submit" className="button primary">Tạo yêu cầu</button>
        </div>
      </form>
    </Modal>
  )
}

// Phản hồi được gửi kèm khi đóng yêu cầu; phụ huynh có tài khoản thấy ở mục Yêu cầu hỗ trợ và nhận thông báo.
function TicketReply({ ticket, notify }) {
  const [reply, setReply] = useState('')
  const submit = event => {
    event.preventDefault()
    if (setTicket(ticket.id, { status: 'done', reply: reply.trim() })) notify(`${ticket.id} đã hoàn thành và báo lại phụ huynh.`)
  }
  return (
    <form className="hm-reply-form" onSubmit={submit}>
      <label className="hm-sr" htmlFor={`reply-${ticket.id}`}>Phản hồi yêu cầu {ticket.id}</label>
      <input id={`reply-${ticket.id}`} required value={reply} onChange={event => setReply(event.target.value)} placeholder="Nội dung phản hồi phụ huynh" />
      <button type="submit" className="button small primary">Phản hồi & hoàn thành</button>
    </form>
  )
}

function Tickets({ tickets, me, notify }) {
  const [status, setStatus] = useState('open')
  const shown = tickets.filter(item => status === 'all' || (status === 'open' ? item.status !== 'done' : item.status === status))
  return (
    <>
      <div className="hm-toolbar">
        <Tabs label="Trạng thái yêu cầu" value={status} onChange={setStatus} tabs={[
          ['open', 'Đang mở', tickets.filter(item => item.status !== 'done').length],
          ['new', 'Mới', tickets.filter(item => item.status === 'new').length],
          ['done', 'Hoàn thành'], ['all', 'Tất cả'],
        ]} />
      </div>
      {!shown.length && <Empty icon="fa-face-smile">Không còn yêu cầu nào trong mục này.</Empty>}
      <ul className="hm-ticket-list">
        {shown.map(item => {
          const sla = ticketSla(item)
          const [label, tone] = statusMeta[item.status]
          return (
            <li key={item.id} className={`hm-ticket${sla.state === 'late' ? ' late' : ''}`}>
              <div className="hm-ticket-head">
                <strong>{item.id}</strong>
                <Badge tone={typeTone[item.type]}>{item.type}</Badge>
                <Badge tone="slate" icon={channelIcon[item.channel]}>{item.channel}</Badge>
                <Badge tone={tone}>{label}</Badge>
                <Badge tone={slaTone[sla.state]} icon="fa-stopwatch">{sla.label}</Badge>
              </div>
              <p>{item.content}</p>
              {item.reply && <p className="hm-reply"><i className="fa-solid fa-reply" aria-hidden="true"></i><span><strong>Đã phản hồi:</strong> {item.reply}</span></p>}
              <div className="hm-ticket-foot">
                <span><i className="fa-solid fa-user" aria-hidden="true"></i>{item.parent}{item.student !== '—' && ` · HS ${item.student}`}</span>
                {item.phone && <span><i className="fa-solid fa-phone" aria-hidden="true"></i>{item.phone}</span>}
                <span><i className="fa-solid fa-location-dot" aria-hidden="true"></i>{item.branch}</span>
                <span><i className="fa-solid fa-headset" aria-hidden="true"></i>{item.owner}</span>
                {item.status === 'new' && <button type="button" className="button small" onClick={() => { setTicket(item.id, { status: 'processing', owner: me }); notify(`${item.id} đã được giao cho ${me}.`) }}>Nhận xử lý</button>}
                {item.status === 'processing' && <TicketReply ticket={item} notify={notify} />}
              </div>
            </li>
          )
        })}
      </ul>
    </>
  )
}

function Knowledge({ faqs }) {
  const [query, setQuery] = useState('')
  const text = query.trim().toLowerCase()
  const shown = faqs.filter(item => !text || `${item.q} ${item.a} ${item.cat}`.toLowerCase().includes(text))
  return (
    <>
      <div className="hm-toolbar">
        <label className="hm-search wide">
          <span className="hm-sr">Tìm trong cơ sở tri thức</span>
          <i className="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
          <input type="search" value={query} onChange={event => setQuery(event.target.value)} placeholder="Tìm chính sách, quy trình, câu hỏi thường gặp" />
        </label>
      </div>
      {!shown.length && <Empty>Chưa có bài viết khớp từ khóa.</Empty>}
      <div className="hm-faq">
        {shown.map(item => (
          <details key={item.id}>
            <summary><Badge tone="orange">{item.cat}</Badge>{item.q}</summary>
            <p>{item.a}</p>
          </details>
        ))}
      </div>
      <p className="hm-form-note">Chatbot 24/7 dùng chính các bài viết này để trả lời phụ huynh và tự tạo yêu cầu khi cần người xử lý.</p>
    </>
  )
}

export default function SupportModule({ role, notify, me }) {
  const store = useStore()
  const [tab, setTab] = useState('tickets')
  const [branch, setBranch] = useState('all')
  const [creating, setCreating] = useState(false)
  const scope = role === 'admin' ? branch : branchScope(role)
  const tickets = store.tickets.filter(item => inScope(item, scope))
  const open = tickets.filter(item => item.status !== 'done')
  const late = open.filter(item => ticketSla(item).state === 'late').length
  const bot = tickets.filter(item => item.channel === 'Chatbot').length

  return (
    <>
      <PageHead title="Chăm sóc khách hàng" description="Tiếp nhận phản hồi, khiếu nại, xin nghỉ, đổi lớp từ mọi kênh và theo dõi hạn phản hồi 24 giờ.">
        <button type="button" className="button primary" onClick={() => setCreating(true)}><i className="fa-solid fa-plus" aria-hidden="true"></i>Tạo yêu cầu</button>
      </PageHead>

      <div className="kpi-grid">
        <Kpi label="Yêu cầu đang mở" value={open.length} icon="fa-inbox" tone={open.length ? 'warn' : 'good'} note={`${tickets.filter(item => item.status === 'new').length} yêu cầu chưa phân công`} />
        <Kpi label="Quá hạn 24h" value={late} icon="fa-triangle-exclamation" tone={late ? 'bad' : 'good'} note={late ? 'Cần xử lý ngay' : 'Không có yêu cầu quá hạn'} />
        <Kpi label="Tạo từ chatbot" value={bot} icon="fa-robot" note={`${percent(bot, tickets.length)}% yêu cầu đến ngoài quầy`} />
        <Kpi label="Tỷ lệ hoàn thành" value={percent(tickets.length - open.length, tickets.length)} unit="%" icon="fa-circle-check" note={`${tickets.length - open.length}/${tickets.length} yêu cầu đã đóng`} />
      </div>

      <article className="card hm-panel">
        <div className="hm-toolbar">
          <Tabs label="Phân hệ CSKH" value={tab} onChange={setTab} tabs={[['tickets', 'Yêu cầu', open.length], ['automation', 'Kịch bản tự động'], ['renewal', 'Gia hạn khóa học', store.renewals.filter(item => inScope(item, scope) && item.status === 'Chưa liên hệ').length || undefined], ['faq', 'Cơ sở tri thức', store.faqs.length], ['channels', 'Kênh tích hợp']]} />
          <div className="hm-filters"><BranchFilter role={role} value={branch} onChange={setBranch} /></div>
        </div>
        {tab === 'tickets' && <Tickets tickets={tickets} me={me} notify={notify} />}
        {tab === 'automation' && <Automations items={store.automations} />}
        {tab === 'renewal' && <Renewals items={store.renewals.filter(item => inScope(item, scope))} />}
        {tab === 'faq' && <Knowledge faqs={store.faqs} />}
        {tab === 'channels' && (
          <div className="grid-3 hm-flush">
            {integrations.map(([icon, title, text]) => (
              <article key={title} className="hm-integration">
                <span className="kpi-icon"><i className={`fa-solid ${icon}`} aria-hidden="true"></i></span>
                <strong>{title}</strong>
                <p>{text}</p>
                <Badge tone="slate" icon="fa-flag">Giai đoạn 2</Badge>
              </article>
            ))}
          </div>
        )}
      </article>

      {creating && <TicketForm role={role} notify={notify} onClose={() => setCreating(false)} />}
    </>
  )
}
