import { useSyncExternalStore } from 'react'

// Kho dữ liệu duy nhất của ứng dụng: mọi màn hình và mọi vai trò đọc/ghi tại đây.
// shortcut: lưu localStorage trong trình duyệt, thay bằng API backend (Prompt 12 của bản audit) khi có server.
const STORAGE_KEY = 'hoa-ma-toan-store-v3'
const SESSION_KEY = 'hoa-ma-toan-session-v2'
const SESSION_START = Date.now()
const HOUR = 3600000
const DAY = 24 * HOUR

export const DEMO_MODE = import.meta.env?.VITE_DEMO_MODE === 'true'
export const BRANCHES = ['Nguyễn Chí Thanh', 'Cầu Giấy', 'Hà Đông', 'Long Biên', 'Thanh Xuân']
export const CHANNELS = ['Facebook', 'Zalo', 'Website', 'Giới thiệu', 'Sự kiện']
export const GRADE_GROUPS = ['Khối 1–5', 'Khối 6–9', 'Khối 10–12']
export const STAGES = [
  { id: 'new', label: 'Mới', tone: 'slate' },
  { id: 'contacted', label: 'Đã liên hệ', tone: 'blue' },
  { id: 'trial', label: 'Đã lên lịch test', tone: 'amber' },
  { id: 'enrolled', label: 'Đã nhập học', tone: 'green' },
  { id: 'lost', label: 'Thất bại', tone: 'red' },
]
export const DAYS = ['Thứ 2', 'Thứ 3', 'Thứ 4', 'Thứ 5', 'Thứ 6', 'Thứ 7', 'Chủ nhật']
export const ROOMS = ['P.101', 'P.102', 'P.201', 'P.202', 'P.301']
export const SLA_HOURS = 24
export const ROLE_LABELS = {
  admin: 'Ban giám đốc', manager: 'Quản lý cơ sở', teacher: 'Giáo viên', parent: 'Phụ huynh',
  accountant: 'Kế toán', sales: 'Tư vấn viên', assistant: 'Trợ giảng',
}
export const STAFF_ROLES = ['admin', 'manager', 'teacher', 'accountant', 'sales', 'assistant']
export const BANKS = {
  Vietcombank: '970436', MBBank: '970422', Techcombank: '970407', BIDV: '970418',
  VietinBank: '970415', ACB: '970416', TPBank: '970423', VPBank: '970432',
}

// Ma trận phân quyền: hành động nhạy cảm -> các vai trò được phép. Kiểm tra ở tầng store, không chỉ ở giao diện.
const RULES = {
  'account.manage': ['admin'],
  'settings.bank': ['admin'],
  'store.reset': ['admin'],
  'payroll.approve': ['admin'],
  'payroll.request': ['manager'],
  'invoice.confirm': ['admin', 'manager', 'accountant'],
  'invoice.pay': ['parent'],
  'finance.write': ['admin', 'manager', 'accountant'],
  'proposal.create': ['teacher', 'assistant'],
  'proposal.decide': ['admin', 'manager'],
  'task.assign': ['admin', 'manager'],
  'lesson.write': ['admin', 'manager', 'teacher', 'assistant'],
  'staff.write': ['admin', 'manager'],
  'crm.write': ['admin', 'manager', 'sales'],
  'schedule.write': ['admin', 'manager'],
  'student.write': ['admin', 'manager', 'sales'],
  'ticket.manage': ['admin', 'manager', 'sales', 'accountant'],
  'support.write': ['admin', 'manager', 'sales'],
}

const lead = (id, parent, phone, student, grade, course, channel, branch, stage, owner, value, daysAgo) => ({
  id, parent, phone, student, grade, course, channel, branch, stage, owner, value, daysAgo,
})
const session = (id, classId, day, start, end, room, teacher, branch) => ({ id, classId, day, start, end, room, teacher, branch })
const roster = names => names.map(name => ({ name, status: 'present', score: '', comment: '' }))
const account = (username, name, role, branch, extra = {}) => ({
  username, name, role, branch, email: `${username}@hoamatoan.vn`, phone: '', status: 'active',
  plain: '123456', mustChange: false, lastLogin: null, failed: 0, lockedUntil: 0, ...extra,
})
const invoice = (id, studentId, student, classLabel, branch, parent, parentUser, sessions, unitPrice, deduction, extra, dueInDays, more = {}) => ({
  id, studentId, student, classLabel, branch, parent, parentUser, month: monthKey(), sessions, unitPrice, deduction, extra,
  dueDate: Date.now() + dueInDays * DAY, status: 'pending', paidAt: null, remindedAt: null, ...more,
})

export function monthKey(time = Date.now()) {
  const date = new Date(time)
  return `${String(date.getMonth() + 1).padStart(2, '0')}/${date.getFullYear()}`
}

function createSeed() {
  const now = Date.now()
  const month = monthKey(now)
  const tx = (id, type, category, amount, branch, note, daysAgo, by) => ({ id, type, category, amount, branch, note, at: now - daysAgo * DAY, by })
  const tuition = [68, 60, 52, 41, 49]
  const running = [30, 27, 23, 19, 21]
  return {
    accounts: [
      account('admin', 'Nguyễn Thu Hà', 'admin', null),
      account('quanly', 'Trần Minh Quân', 'manager', BRANCHES[0]),
      account('giaovien', 'Trần Văn Anh', 'teacher', BRANCHES[0]),
      account('ketoan', 'Vũ Lan', 'accountant', BRANCHES[0]),
      account('phuhuynh', 'Lê Thị Mai', 'parent', BRANCHES[0], { phone: '0988 120 456' }),
    ],
    // Quy mô theo cơ sở: nguồn duy nhất cho số học viên, số lớp và cơ cấu khối trên mọi màn hình.
    org: BRANCHES.map((branch, index) => ({
      branch,
      groups: [[23, 21, 18], [20, 19, 16], [18, 16, 14], [14, 13, 11], [17, 15, 13]][index],
      classes: [5, 4, 3, 3, 3][index],
    })),
    quality: { attendance: 92, retention: 96.2, target: 300 },
    history: [
      { label: 'T6', students: 221, income: 232, expense: 118 },
      { label: 'T7', students: 228, income: 241, expense: 121 },
      { label: 'T8', students: 233, income: 255, expense: 124 },
      { label: 'T9', students: 239, income: 262, expense: 119 },
      { label: 'T10', students: 244, income: 268, expense: 122 },
    ],
    transactions: [
      ...BRANCHES.map((branch, index) => tx(`PT-11${index + 1}`, 'income', 'Học phí', tuition[index] * 1e6, branch, `Thu học phí tháng ${month}`, 6 + index, 'Vũ Lan')),
      ...BRANCHES.map((branch, index) => tx(`PC-11${index + 1}`, 'expense', 'Lương & vận hành', running[index] * 1e6, branch, `Lương, mặt bằng, điện nước tháng ${month}`, 4 + index, 'Vũ Lan')),
    ],
    invoices: [
      invoice('HD-1101', 'HV-2026-0101', 'Lê Minh Anh', 'Toán nâng cao 5A', BRANCHES[0], 'Lê Thị Mai', 'phuhuynh', 12, 200000, 200000, 100000, 5),
      invoice('HD-1102', 'HV-2026-0102', 'Lê Bảo Nam', 'Luyện thi vào 10', BRANCHES[0], 'Lê Thị Mai', 'phuhuynh', 12, 250000, 0, 0, 5),
      invoice('HD-1103', 'HV-2026-0077', 'Trần Hoàng Nam', 'Toán 11 chuyên đề', BRANCHES[0], 'Anh Trần Hoàng Sơn', null, 12, 350000, 0, 0, -9),
      invoice('HD-1104', 'HV-2026-0054', 'Lê Bảo Ngọc', 'Toán nâng cao 5A', BRANCHES[0], 'Chị Lê Thu Thảo', null, 12, 200000, 0, 0, -7),
      invoice('HD-1105', 'HV-2026-0061', 'Phạm Gia Huy', 'Toán nâng cao 5A', BRANCHES[0], 'Anh Phạm Gia Bình', null, 12, 200000, 0, 0, -6),
      invoice('HD-1106', 'HV-2026-0090', 'Đỗ Quang Minh', 'Toán 8 nâng cao', BRANCHES[0], 'Chị Đỗ Minh Hằng', null, 12, 250000, 0, 0, -4),
      invoice('HD-1107', 'HV-2026-0133', 'Vũ Bảo Châu', 'Luyện thi THPT QG', BRANCHES[1], 'Chị Vũ Hồng Nhung', null, 12, 380000, 0, 0, -8),
      invoice('HD-1108', 'HV-2026-0247', 'Đinh Gia Huy', 'Toán nâng cao lớp 5', BRANCHES[3], 'Chị Đinh Kim Oanh', null, 12, 200000, 0, 0, -3),
      invoice('HD-1001', 'HV-2026-0101', 'Lê Minh Anh', 'Toán nâng cao 5A', BRANCHES[0], 'Lê Thị Mai', 'phuhuynh', 12, 200000, 0, 0, -25, { month: monthKey(now - 30 * DAY), status: 'paid', paidAt: now - 36 * DAY }),
      invoice('HD-1002', 'HV-2026-0102', 'Lê Bảo Nam', 'Luyện thi vào 10', BRANCHES[0], 'Lê Thị Mai', 'phuhuynh', 12, 250000, 0, 0, -25, { month: monthKey(now - 30 * DAY), status: 'paid', paidAt: now - 35 * DAY }),
    ],
    leads: [
      lead('L-1041', 'Chị Nguyễn Thu Trang', '0912 345 245', 'Bé Gia Hân', GRADE_GROUPS[0], 'Toán nâng cao lớp 5', 'Facebook', BRANCHES[0], 'new', 'Lê Thị Bình', 4.8, 0),
      lead('L-1040', 'Anh Phạm Quốc Việt', '0983 112 908', 'Phạm Minh Khang', GRADE_GROUPS[1], 'Toán 8 nâng cao', 'Zalo', BRANCHES[1], 'new', 'Đỗ Hải Yến', 5.2, 1),
      lead('L-1039', 'Chị Vũ Hồng Nhung', '0904 771 630', 'Vũ Bảo Châu', GRADE_GROUPS[2], 'Luyện thi THPT QG', 'Website', BRANCHES[2], 'new', 'Lê Thị Bình', 6.5, 1),
      lead('L-1038', 'Anh Lê Minh Đức', '0936 508 817', 'Lê Gia Bảo', GRADE_GROUPS[1], 'Luyện thi vào 10', 'Giới thiệu', BRANCHES[0], 'contacted', 'Đỗ Hải Yến', 6.0, 2),
      lead('L-1037', 'Chị Trần Mai Phương', '0977 204 115', 'Trần Nhật Minh', GRADE_GROUPS[0], 'Toán tư duy lớp 3', 'Facebook', BRANCHES[3], 'contacted', 'Ngô Thanh Tùng', 3.9, 3),
      lead('L-1036', 'Anh Hoàng Văn Sơn', '0915 660 482', 'Hoàng Tuệ Lâm', GRADE_GROUPS[2], 'Toán 11 chuyên đề', 'Sự kiện', BRANCHES[4], 'contacted', 'Ngô Thanh Tùng', 5.8, 4),
      lead('L-1035', 'Chị Phạm Hoài An', '0968 339 362', 'Phạm An Nhiên', GRADE_GROUPS[0], 'Toán tư duy lớp 3', 'Website', BRANCHES[0], 'trial', 'Lê Thị Bình', 3.9, 5),
      lead('L-1034', 'Anh Đặng Quang Huy', '0902 845 771', 'Đặng Khánh Linh', GRADE_GROUPS[1], 'Toán 7 cơ bản', 'Zalo', BRANCHES[1], 'trial', 'Đỗ Hải Yến', 4.6, 6),
      lead('L-1033', 'Chị Bùi Thanh Hà', '0945 127 096', 'Bùi Đức Anh', GRADE_GROUPS[2], 'Luyện thi THPT QG', 'Giới thiệu', BRANCHES[2], 'trial', 'Lê Thị Bình', 6.5, 7),
      lead('L-1032', 'Anh Ngô Bá Long', '0989 400 213', 'Ngô Phương Vy', GRADE_GROUPS[1], 'Luyện thi vào 10', 'Facebook', BRANCHES[0], 'enrolled', 'Đỗ Hải Yến', 6.0, 9),
      lead('L-1031', 'Chị Đinh Kim Oanh', '0931 556 748', 'Đinh Gia Huy', GRADE_GROUPS[0], 'Toán nâng cao lớp 5', 'Zalo', BRANCHES[3], 'enrolled', 'Ngô Thanh Tùng', 4.8, 11),
      lead('L-1030', 'Anh Trịnh Xuân Bách', '0916 872 304', 'Trịnh Hà My', GRADE_GROUPS[2], 'Toán 11 chuyên đề', 'Website', BRANCHES[4], 'enrolled', 'Ngô Thanh Tùng', 5.8, 12),
      lead('L-1029', 'Chị Lý Thu Hương', '0973 018 559', 'Lý Minh Quân', GRADE_GROUPS[1], 'Toán 8 nâng cao', 'Facebook', BRANCHES[1], 'lost', 'Đỗ Hải Yến', 5.2, 14),
      lead('L-1028', 'Anh Cao Thế Vinh', '0907 263 481', 'Cao Bảo Ngọc', GRADE_GROUPS[0], 'Toán tư duy lớp 3', 'Sự kiện', BRANCHES[2], 'lost', 'Lê Thị Bình', 3.9, 16),
    ],
    campaigns: [
      { id: 'CD-07', name: 'Tuyển sinh luyện thi vào 10', channel: 'Facebook', period: '01/10 – 30/11', budget: 45, leads: 182, enrolled: 41, status: 'Đang chạy' },
      { id: 'CD-06', name: 'Học thử miễn phí khối 1–5', channel: 'Zalo', period: '15/10 – 15/11', budget: 18, leads: 96, enrolled: 27, status: 'Đang chạy' },
      { id: 'CD-05', name: 'Hội thảo phụ huynh cuối kỳ', channel: 'Sự kiện', period: '02/11 – 09/11', budget: 22, leads: 64, enrolled: 19, status: 'Đang chạy' },
      { id: 'CD-04', name: 'Giới thiệu bạn – tặng học phí', channel: 'Giới thiệu', period: '01/09 – 31/10', budget: 12, leads: 58, enrolled: 31, status: 'Đã kết thúc' },
    ],
    targets: [
      { branch: BRANCHES[0], target: 60, actual: 52 },
      { branch: BRANCHES[1], target: 55, actual: 41 },
      { branch: BRANCHES[2], target: 45, actual: 38 },
      { branch: BRANCHES[3], target: 40, actual: 22 },
      { branch: BRANCHES[4], target: 50, actual: 47 },
    ],
    activities: [
      { id: 'A-301', type: 'call', title: 'Gọi tư vấn lộ trình vào 10', who: 'Anh Lê Minh Đức', owner: 'Đỗ Hải Yến', due: 'Hôm nay 14:00', branch: BRANCHES[0], done: false },
      { id: 'A-302', type: 'meeting', title: 'Buổi học thử Toán tư duy', who: 'Chị Phạm Hoài An', owner: 'Lê Thị Bình', due: 'Hôm nay 17:30', branch: BRANCHES[0], done: false },
      { id: 'A-303', type: 'task', title: 'Gửi bảng giá và lịch khai giảng', who: 'Chị Nguyễn Thu Trang', owner: 'Lê Thị Bình', due: 'Hôm nay 16:00', branch: BRANCHES[0], done: false },
      { id: 'A-304', type: 'call', title: 'Gọi nhắc học phí kỳ này', who: 'Anh Ngô Bá Long', owner: 'Kế toán · Vũ Lan', due: 'Ngày mai 09:00', branch: BRANCHES[0], done: false },
      { id: 'A-305', type: 'meeting', title: 'Họp phụ huynh lớp Toán 8', who: 'GVCN Trần Văn Anh', owner: 'Đỗ Hải Yến', due: 'Thứ 7 09:00', branch: BRANCHES[1], done: false },
      { id: 'A-306', type: 'task', title: 'Chăm sóc lại lead thất bại', who: 'Chị Lý Thu Hương', owner: 'Đỗ Hải Yến', due: 'Thứ 6 10:00', branch: BRANCHES[1], done: true },
    ],
    students: [
      { id: 'HV-2026-0101', name: 'Lê Minh Anh', classId: 'C-5A', branch: BRANCHES[0], parent: 'phuhuynh', parentName: 'Lê Thị Mai', phone: '0988 120 456', birth: '15/08/2016', grade: 'Lớp 5' },
      { id: 'HV-2026-0102', name: 'Lê Bảo Nam', classId: 'C-9V', branch: BRANCHES[0], parent: 'phuhuynh', parentName: 'Lê Thị Mai', phone: '0988 120 456', birth: '22/03/2012', grade: 'Lớp 9' },
      { id: 'HV-2026-0248', name: 'Ngô Phương Vy', classId: 'C-9V', branch: BRANCHES[0], parent: null, parentName: 'Anh Ngô Bá Long', phone: '0989 400 213', birth: '09/01/2012', grade: 'Lớp 9' },
      { id: 'HV-2026-0247', name: 'Đinh Gia Huy', classId: null, branch: BRANCHES[3], parent: null, parentName: 'Chị Đinh Kim Oanh', phone: '0931 556 748', birth: '30/06/2016', grade: 'Lớp 5' },
      { id: 'HV-2026-0246', name: 'Trịnh Hà My', classId: null, branch: BRANCHES[4], parent: null, parentName: 'Anh Trịnh Xuân Bách', phone: '0916 872 304', birth: '11/11/2010', grade: 'Lớp 11' },
    ],
    classes: [
      { id: 'C-5A', name: 'Toán nâng cao 5A', group: GRADE_GROUPS[0], teacher: 'Nguyễn Thu Hương', branch: BRANCHES[0], size: 18, capacity: 20 },
      { id: 'C-3B', name: 'Toán tư duy 3B', group: GRADE_GROUPS[0], teacher: 'Lê Thị Bình', branch: BRANCHES[0], size: 12, capacity: 16 },
      { id: 'C-8A', name: 'Toán 8 nâng cao', group: GRADE_GROUPS[1], teacher: 'Trần Văn Anh', branch: BRANCHES[0], size: 16, capacity: 18 },
      { id: 'C-9V', name: 'Luyện thi vào 10', group: GRADE_GROUPS[1], teacher: 'Trần Văn Anh', branch: BRANCHES[0], size: 15, capacity: 15 },
      { id: 'C-11C', name: 'Toán 11 chuyên đề', group: GRADE_GROUPS[2], teacher: 'Phạm Đức Long', branch: BRANCHES[0], size: 14, capacity: 18 },
      { id: 'C-12T', name: 'Luyện thi THPT QG', group: GRADE_GROUPS[2], teacher: 'Phạm Đức Long', branch: BRANCHES[1], size: 17, capacity: 20 },
      { id: 'C-7B', name: 'Toán 7 cơ bản', group: GRADE_GROUPS[1], teacher: 'Hoàng Mai Chi', branch: BRANCHES[1], size: 13, capacity: 18 },
    ],
    sessions: [
      session('S-01', 'C-5A', 0, '18:00', '19:30', 'P.101', 'Nguyễn Thu Hương', BRANCHES[0]),
      session('S-02', 'C-8A', 0, '18:00', '19:30', 'P.201', 'Trần Văn Anh', BRANCHES[0]),
      session('S-03', 'C-3B', 1, '17:30', '19:00', 'P.102', 'Lê Thị Bình', BRANCHES[0]),
      session('S-04', 'C-9V', 1, '19:15', '20:45', 'P.201', 'Trần Văn Anh', BRANCHES[0]),
      session('S-05', 'C-5A', 2, '18:00', '19:30', 'P.101', 'Nguyễn Thu Hương', BRANCHES[0]),
      session('S-06', 'C-11C', 2, '19:30', '21:00', 'P.301', 'Phạm Đức Long', BRANCHES[0]),
      session('S-07', 'C-8A', 3, '18:00', '19:30', 'P.201', 'Trần Văn Anh', BRANCHES[0]),
      // Xung đột có chủ đích trong dữ liệu demo: cùng giáo viên, trùng giờ Thứ 5.
      session('S-08', 'C-9V', 3, '18:30', '20:00', 'P.202', 'Trần Văn Anh', BRANCHES[0]),
      session('S-09', 'C-3B', 4, '17:30', '19:00', 'P.102', 'Lê Thị Bình', BRANCHES[0]),
      session('S-10', 'C-11C', 5, '09:00', '10:30', 'P.301', 'Phạm Đức Long', BRANCHES[0]),
      session('S-11', 'C-5A', 5, '09:00', '10:30', 'P.101', 'Nguyễn Thu Hương', BRANCHES[0]),
      session('S-12', 'C-12T', 1, '18:00', '19:30', 'P.101', 'Phạm Đức Long', BRANCHES[1]),
      session('S-13', 'C-7B', 3, '18:00', '19:30', 'P.102', 'Hoàng Mai Chi', BRANCHES[1]),
    ],
    lessons: [
      { id: 'B-2211', classId: 'C-5A', topic: 'Phân số và tỉ số phần trăm', teacher: 'Nguyễn Thu Hương', endedHoursAgo: 2, done: false, students: roster(['Lê Minh Anh', 'Lê Bảo Ngọc', 'Phạm Gia Huy', 'Trần Khánh Vy']) },
      { id: 'B-2210', classId: 'C-8A', topic: 'Hằng đẳng thức đáng nhớ', teacher: 'Trần Văn Anh', endedHoursAgo: 20, done: false, students: roster(['Đỗ Quang Minh', 'Vũ Thùy Linh', 'Hoàng Đức Trí']) },
      { id: 'B-2209', classId: 'C-9V', topic: 'Hệ phương trình bậc nhất', teacher: 'Trần Văn Anh', endedHoursAgo: 31, done: false, students: roster(['Lê Bảo Nam', 'Ngô Phương Vy', 'Bùi Tuấn Kiệt']) },
      { id: 'B-2208', classId: 'C-11C', topic: 'Giới hạn dãy số', teacher: 'Phạm Đức Long', endedHoursAgo: 46, done: true, students: roster(['Trần Hoàng Nam', 'Đặng Thu Uyên']).map(item => ({ ...item, score: '8.5', comment: 'Nắm chắc bài, cần luyện thêm dạng nâng cao.' })) },
      { id: 'B-2205', classId: 'C-9V', topic: 'Căn bậc hai và hằng đẳng thức', teacher: 'Trần Văn Anh', endedHoursAgo: 72, done: true, students: roster(['Lê Bảo Nam', 'Ngô Phương Vy', 'Bùi Tuấn Kiệt']).map((item, index) => ({ ...item, score: ['8', '9', '7.5'][index], comment: ['Làm bài cẩn thận, cần tăng tốc độ tính.', 'Hiểu bài nhanh, tích cực phát biểu.', 'Cần ôn lại phần rút gọn biểu thức.'][index] })) },
      { id: 'B-2204', classId: 'C-5A', topic: 'Hình tam giác và diện tích', teacher: 'Nguyễn Thu Hương', endedHoursAgo: 96, done: true, students: roster(['Lê Minh Anh', 'Lê Bảo Ngọc', 'Phạm Gia Huy', 'Trần Khánh Vy']).map((item, index) => ({ ...item, status: index === 3 ? 'absent' : 'present', score: index === 3 ? '' : ['9', '8.5', '7'][index], comment: index === 3 ? '' : ['Con tiếp thu tốt, trình bày sạch.', 'Chăm chú nghe giảng.', 'Cần luyện thêm bài tập về nhà.'][index] })) },
    ],
    proposals: [],
    staff: [
      { id: 'NS-01', name: 'Nguyễn Thu Hương', role: 'Giáo viên Toán', branch: BRANCHES[0], phone: '0912 880 145', contract: 'Toàn thời gian', joined: '12/08/2023', status: 'Đang làm việc', checkIn: '17:42', sessions: 26, kpi: 94, salary: 14.3, payroll: 'Chờ duyệt' },
      { id: 'NS-02', name: 'Trần Văn Anh', role: 'Giáo viên Toán', branch: BRANCHES[0], phone: '0903 417 622', contract: 'Toàn thời gian', joined: '03/04/2022', status: 'Đang làm việc', checkIn: '17:50', sessions: 32, kpi: 88, salary: 17.6, payroll: 'Chờ duyệt' },
      { id: 'NS-03', name: 'Lê Thị Bình', role: 'Tư vấn viên', branch: BRANCHES[0], phone: '0977 305 918', contract: 'Toàn thời gian', joined: '21/06/2024', status: 'Đang làm việc', checkIn: '08:01', sessions: 0, kpi: 91, salary: 11.2, payroll: 'Chờ duyệt' },
      { id: 'NS-04', name: 'Phạm Đức Long', role: 'Giáo viên Toán', branch: BRANCHES[1], phone: '0986 224 730', contract: 'Toàn thời gian', joined: '15/01/2021', status: 'Đang làm việc', checkIn: '18:55', sessions: 28, kpi: 96, salary: 16.8, payroll: 'Đã duyệt' },
      { id: 'NS-05', name: 'Đỗ Hải Yến', role: 'Tư vấn viên', branch: BRANCHES[1], phone: '0934 610 277', contract: 'Toàn thời gian', joined: '09/09/2023', status: 'Nghỉ phép', checkIn: '—', sessions: 0, kpi: 86, salary: 10.9, payroll: 'Đã duyệt' },
      { id: 'NS-06', name: 'Hoàng Mai Chi', role: 'Giáo viên Toán', branch: BRANCHES[1], phone: '0918 742 063', contract: 'Bán thời gian', joined: '02/03/2025', status: 'Đang làm việc', checkIn: '17:38', sessions: 22, kpi: 82, salary: 12.4, payroll: 'Chờ duyệt' },
      { id: 'NS-07', name: 'Vũ Lan', role: 'Kế toán', branch: BRANCHES[0], phone: '0909 158 344', contract: 'Toàn thời gian', joined: '18/11/2020', status: 'Đang làm việc', checkIn: '07:56', sessions: 0, kpi: 93, salary: 13.0, payroll: 'Đã duyệt' },
      { id: 'NS-08', name: 'Ngô Thanh Tùng', role: 'Tư vấn viên', branch: BRANCHES[3], phone: '0961 437 580', contract: 'Thử việc', joined: '27/05/2024', status: 'Đang làm việc', checkIn: '08:10', sessions: 0, kpi: 79, salary: 10.5, payroll: 'Chờ duyệt' },
    ],
    tickets: [
      { id: 'CS-0206', parent: 'Lê Thị Mai', parentUser: 'phuhuynh', phone: '0988 120 456', student: 'Lê Minh Anh', type: 'Xin nghỉ', content: 'Xin nghỉ buổi Thứ 4 do con ốm, mong được xếp học bù.', channel: 'Chatbot', owner: 'Chưa phân công', status: 'new', hoursAgo: 1, branch: BRANCHES[0], reply: '' },
      { id: 'CS-0205', parent: 'Anh Ngô Bá Long', phone: '0989 400 213', student: 'Ngô Phương Vy', type: 'Học phí', content: 'Đề nghị xác nhận biên lai học phí kỳ này.', channel: 'Cổng phụ huynh', owner: 'Vũ Lan', status: 'processing', hoursAgo: 6, branch: BRANCHES[0], reply: '' },
      { id: 'CS-0204', parent: 'Chị Đinh Kim Oanh', phone: '0931 556 748', student: 'Đinh Gia Huy', type: 'Đổi lớp', content: 'Muốn chuyển sang ca tối Thứ 3 – Thứ 5.', channel: 'Zalo', owner: 'Ngô Thanh Tùng', status: 'processing', hoursAgo: 19, branch: BRANCHES[3], reply: '' },
      { id: 'CS-0203', parent: 'Anh Hoàng Văn Sơn', phone: '0915 660 482', student: 'Hoàng Tuệ Lâm', type: 'Khiếu nại', content: 'Chưa nhận được nhận xét sau buổi học Thứ 2.', channel: 'Hotline', owner: 'Chưa phân công', status: 'new', hoursAgo: 27, branch: BRANCHES[4], reply: '' },
      { id: 'CS-0202', parent: 'Chị Bùi Thanh Hà', phone: '0945 127 096', student: 'Bùi Đức Anh', type: 'Phản hồi', content: 'Cảm ơn thầy Long đã kèm con phần giới hạn.', channel: 'Zalo', owner: 'Lê Thị Bình', status: 'done', hoursAgo: 40, branch: BRANCHES[2], reply: 'Trung tâm cảm ơn chị, sẽ chuyển lời tới thầy Long.' },
    ],
    faqs: [
      { id: 'F-1', cat: 'Chính sách', q: 'Con nghỉ học thì được học bù như thế nào?', a: 'Phụ huynh báo nghỉ trước giờ học ít nhất 2 tiếng. Trung tâm xếp học bù trong vòng 14 ngày tại lớp cùng trình độ.' },
      { id: 'F-2', cat: 'Học phí', q: 'Học phí được tính và đóng ra sao?', a: 'Học phí = số buổi × đơn giá − khấu trừ buổi nghỉ có phép + phụ phí tài liệu. Hóa đơn phát hành đầu tháng, hạn đóng ghi trên hóa đơn, thanh toán bằng VietQR hoặc tại quầy.' },
      { id: 'F-3', cat: 'Quy trình', q: 'Làm sao để đổi lớp hoặc đổi ca học?', a: 'Gửi yêu cầu đổi lớp qua cổng phụ huynh hoặc chatbot. Quản lý cơ sở phản hồi trong 24 giờ sau khi kiểm tra sĩ số và lịch phòng.' },
      { id: 'F-4', cat: 'Học vụ', q: 'Khi nào phụ huynh nhận được nhận xét buổi học?', a: 'Giáo viên điểm danh, nhập điểm và nhận xét trong vòng 24 giờ sau buổi học. Quá hạn, hệ thống tự cảnh báo quản lý cơ sở.' },
      { id: 'F-5', cat: 'Tuyển sinh', q: 'Trung tâm có cho học thử không?', a: 'Mỗi học sinh được học thử miễn phí 1 buổi và làm bài kiểm tra xếp lớp trước khi ghi danh.' },
    ],
    threads: [
      { id: 'TH-01', title: 'Lê Bảo Nam · Luyện thi vào 10', members: ['phuhuynh', 'giaovien'], lastAt: now - 20 * HOUR, seen: { giaovien: now - 20 * HOUR } },
      { id: 'TH-02', title: 'Cơ sở Nguyễn Chí Thanh', members: ['phuhuynh', 'quanly'], lastAt: now - 50 * HOUR, seen: { phuhuynh: now, quanly: now } },
    ],
    messages: [
      { id: 'M-001', threadId: 'TH-01', from: 'phuhuynh', text: 'Thầy ơi, tuần này Nam có cần làm thêm đề nào không ạ?', at: now - 22 * HOUR },
      { id: 'M-002', threadId: 'TH-01', from: 'giaovien', text: 'Chào chị Mai, Nam làm giúp tôi đề số 4 phần hệ phương trình, Thứ 3 tôi chữa trên lớp.', at: now - 20 * HOUR },
      { id: 'M-003', threadId: 'TH-02', from: 'quanly', text: 'Trung tâm đã phát hành hóa đơn học phí tháng này, chị kiểm tra ở mục Học phí giúp em ạ.', at: now - 50 * HOUR },
    ],
    tasks: [
      { id: 'CV-01', title: 'Chốt danh sách lớp luyện thi vào 10 đợt 2', description: 'Rà sĩ số, phòng học và giáo viên, gửi lại trước cuối tuần.', assignee: 'quanly', assigner: 'admin', branch: BRANCHES[0], priority: 'high', due: now + 2 * DAY, status: 'doing', comments: [] },
      { id: 'CV-02', title: 'Nộp đề kiểm tra giữa kỳ lớp Toán 8', description: 'Đề 45 phút, kèm đáp án và thang điểm.', assignee: 'giaovien', assigner: 'quanly', branch: BRANCHES[0], priority: 'normal', due: now + 3 * DAY, status: 'new', comments: [] },
      { id: 'CV-03', title: 'Đối soát học phí quá hạn', description: 'Gọi nhắc các khoản quá hạn trên 5 ngày.', assignee: 'ketoan', assigner: 'quanly', branch: BRANCHES[0], priority: 'normal', due: now - DAY, status: 'new', comments: [] },
    ],
    notifications: [
      { id: 'TB-003', toRole: 'manager', branch: BRANCHES[0], type: 'ticket', title: 'Yêu cầu mới CS-0206', body: 'Lê Thị Mai xin nghỉ cho Lê Minh Anh.', tab: 'support', at: now - HOUR, read: false },
      { id: 'TB-002', toRole: 'admin', type: 'payroll', title: 'Bảng lương chờ duyệt', body: '5 phiếu lương đang chờ Ban giám đốc duyệt.', tab: 'hr', at: now - 5 * HOUR, read: false },
      { id: 'TB-001', toUser: 'phuhuynh', type: 'invoice', title: 'Hóa đơn học phí mới', body: `Trung tâm đã phát hành hóa đơn tháng ${month} cho Lê Minh Anh và Lê Bảo Nam.`, tab: 'p-fees', at: now - 30 * HOUR, read: false },
    ],
    // Lịch trực quầy theo tuần: mỗi ô (ngày × ca) gán nhân sự của cơ sở.
    shifts: [
      { id: 'LT-01', branch: BRANCHES[0], day: 0, shift: 0, staffId: 'NS-03' },
      { id: 'LT-02', branch: BRANCHES[0], day: 0, shift: 2, staffId: 'NS-07' },
      { id: 'LT-03', branch: BRANCHES[0], day: 1, shift: 1, staffId: 'NS-03' },
      { id: 'LT-04', branch: BRANCHES[0], day: 2, shift: 2, staffId: 'NS-01' },
      { id: 'LT-05', branch: BRANCHES[0], day: 5, shift: 0, staffId: 'NS-07' },
      { id: 'LT-06', branch: BRANCHES[0], day: 5, shift: 1, staffId: 'NS-07' },
    ],
    automations: [
      { id: 'KB-01', name: 'Nhắc học phí trước hạn', channel: 'ZNS', trigger: 'Trước hạn thanh toán 3 ngày', schedule: '09:00', enabled: true, sent: 186, template: 'Hòa Ma Toán kính gửi {phu_huynh}: học phí tháng {thang} của {hoc_sinh} là {so_tien}, hạn {han}. Thanh toán bằng VietQR trong cổng phụ huynh.' },
      { id: 'KB-02', name: 'Nhắc lịch học ngày mai', channel: 'SMS', trigger: 'Tối hôm trước buổi học', schedule: '20:00', enabled: true, sent: 742, template: 'HMT: {hoc_sinh} co buoi {lop} luc {gio} ngay mai tai {phong}. Bao nghi truoc gio hoc 2 tieng.' },
      { id: 'KB-03', name: 'Chúc mừng sinh nhật học viên', channel: 'ZNS', trigger: 'Đúng ngày sinh của học viên', schedule: '08:00', enabled: false, sent: 21, template: 'Hòa Ma Toán chúc {hoc_sinh} sinh nhật vui vẻ và học tốt! Tặng con 1 buổi học thử lớp chuyên đề.' },
    ],
    renewals: [
      { id: 'GH-01', student: 'Lê Bảo Nam', parent: 'Lê Thị Mai', phone: '0988 120 456', classLabel: 'Luyện thi vào 10', branch: BRANCHES[0], endsInDays: 6, status: 'Chưa liên hệ' },
      { id: 'GH-02', student: 'Ngô Phương Vy', parent: 'Anh Ngô Bá Long', phone: '0989 400 213', classLabel: 'Luyện thi vào 10', branch: BRANCHES[0], endsInDays: 6, status: 'Đã liên hệ' },
      { id: 'GH-03', student: 'Đỗ Quang Minh', parent: 'Chị Đỗ Minh Hằng', phone: '0912 664 019', classLabel: 'Toán 8 nâng cao', branch: BRANCHES[0], endsInDays: 12, status: 'Đã tái đăng ký' },
      { id: 'GH-04', student: 'Trần Hoàng Nam', parent: 'Anh Trần Hoàng Sơn', phone: '0903 771 285', classLabel: 'Toán 11 chuyên đề', branch: BRANCHES[0], endsInDays: 15, status: 'Chưa liên hệ' },
      { id: 'GH-05', student: 'Vũ Bảo Châu', parent: 'Chị Vũ Hồng Nhung', phone: '0904 771 630', classLabel: 'Luyện thi THPT QG', branch: BRANCHES[1], endsInDays: 9, status: 'Đã tái đăng ký' },
      { id: 'GH-06', student: 'Đinh Gia Huy', parent: 'Chị Đinh Kim Oanh', phone: '0931 556 748', classLabel: 'Toán nâng cao lớp 5', branch: BRANCHES[3], endsInDays: 18, status: 'Không tiếp tục' },
    ],
    auditLog: [],
    settings: {
      center: { name: 'HÒA MA TOÁN · Trung tâm Toán học', hotline: '1900 6868', email: 'lienhe@hoamatoan.vn', year: '2026 – 2027' },
      bank: { bankId: 'Vietcombank', accountNo: '1029384756', accountName: 'CONG TY TNHH HOA MA TOAN' },
      toggles: { feeReminder: true, lessonComment: true, weeklyReport: false, chatbot: true },
    },
  }
}

function load() {
  try {
    const saved = JSON.parse(window.localStorage.getItem(STORAGE_KEY) || 'null')
    if (saved && Array.isArray(saved.accounts) && Array.isArray(saved.invoices)) return saved
  } catch (error) {
    console.error('Không thể đọc dữ liệu đã lưu:', error)
  }
  return createSeed()
}

let state = load()
let actor = null
let viewAs = null
let denyHandler = message => console.warn(message)
const listeners = new Set()
const emit = () => listeners.forEach(listener => listener())
const subscribe = listener => {
  listeners.add(listener)
  return () => listeners.delete(listener)
}

function readSession() {
  try {
    return JSON.parse(window.sessionStorage?.getItem(SESSION_KEY) || 'null')
  } catch {
    return null
  }
}

// Vai trò luôn lấy từ tài khoản trong kho, không lấy từ giá trị người dùng tự sửa được.
function refreshActor() {
  const saved = readSession()
  const own = saved && state.accounts.find(item => item.username === saved.username && item.token === saved.token && item.status === 'active')
  if (!own) {
    actor = null
    viewAs = null
    return
  }
  const shown = viewAs && own.role === 'admin' && DEMO_MODE
    ? state.accounts.find(item => item.role === viewAs && item.status === 'active')
    : null
  const base = shown || own
  actor = {
    username: base.username, name: base.name, role: base.role, branch: base.branch, email: base.email, phone: base.phone,
    mustChange: own.mustChange, readOnly: Boolean(shown), realRole: own.role,
  }
}

function commit(next) {
  state = next
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
  } catch (error) {
    console.error('Không thể lưu dữ liệu:', error)
  }
  refreshActor()
  emit()
}

// Đồng bộ giữa hai cửa sổ: thao tác ở vai trò này hiện ngay ở cửa sổ vai trò kia.
if (typeof window.addEventListener === 'function') {
  window.addEventListener('storage', event => {
    if (event.key !== STORAGE_KEY) return
    state = load()
    refreshActor()
    emit()
  })
}

export const getState = () => state
export const getActor = () => actor
export const setActor = next => { actor = next }
export const setDenyHandler = handler => { denyHandler = handler }
export const useStore = () => useSyncExternalStore(subscribe, getState)
export const useActor = () => useSyncExternalStore(subscribe, getActor)
export const myBranch = () => actor?.branch || BRANCHES[0]

export function allowed(action) {
  if (actor?.readOnly) {
    denyHandler('Đang xem với tư cách vai trò khác: chế độ chỉ đọc.')
    return false
  }
  const roles = RULES[action]
  if (roles && !roles.includes(actor?.role)) {
    denyHandler('Tài khoản của bạn không có quyền thực hiện thao tác này.')
    return false
  }
  return true
}

// Ngoài Ban giám đốc, mọi vai trò chỉ ghi được dữ liệu thuộc cơ sở gắn trên tài khoản của mình.
function owns(branch) {
  if (actor?.role === 'admin' || actor?.branch === branch) return true
  denyHandler('Bạn chỉ thao tác được dữ liệu của cơ sở mình.')
  return false
}

export function update(recipe, { silent = false } = {}) {
  if (actor?.readOnly) {
    if (!silent) denyHandler('Đang xem với tư cách vai trò khác: chế độ chỉ đọc.')
    return false
  }
  commit(recipe(state))
  return true
}

const nextId = (items, prefix, pad = 4) => {
  const max = items.reduce((highest, item) => Math.max(highest, Number(String(item.id).split('-').pop()) || 0), 0)
  return `${prefix}-${String(max + 1).padStart(pad, '0')}`
}
const digits = text => String(text || '').replace(/\D/g, '')
const nextStudentId = students => `HV-2026-${String(Math.max(...students.map(item => Number(item.id.slice(-4)))) + 1).padStart(4, '0')}`

// ---- Thông báo và nhật ký ----
const withNotes = (current, notes) => ({
  ...current,
  notifications: [
    ...notes.map((note, index) => ({ id: `TB-${Date.now().toString(36)}${index}`, at: Date.now(), read: false, ...note })),
    ...current.notifications,
  ].slice(0, 120),
})
const withAudit = (current, action) => ({
  ...current,
  auditLog: [{ at: Date.now(), who: actor?.name || 'Hệ thống', role: actor?.role || 'system', action }, ...current.auditLog].slice(0, 200),
})
export const pushNote = note => update(current => withNotes(current, [note]))

export function notesFor(who = actor, current = state) {
  if (!who) return []
  return current.notifications.filter(note => note.toUser
    ? note.toUser === who.username
    : note.toRole === who.role && (!note.branch || who.role === 'admin' || note.branch === who.branch))
}
export const markRead = id => update(current => ({
  ...current, notifications: current.notifications.map(note => note.id === id ? { ...note, read: true } : note),
}), { silent: true })
export const markAllRead = () => {
  const mine = new Set(notesFor().map(note => note.id))
  update(current => ({ ...current, notifications: current.notifications.map(note => mine.has(note.id) ? { ...note, read: true } : note) }), { silent: true })
}

// ---- Tài khoản và đăng nhập ----
async function digest(text) {
  const subtle = globalThis.crypto?.subtle
  if (subtle) {
    const bytes = await subtle.digest('SHA-256', new TextEncoder().encode(text))
    return [...new Uint8Array(bytes)].map(byte => byte.toString(16).padStart(2, '0')).join('')
  }
  // shortcut: trang chạy qua http nội bộ không có crypto.subtle nên dùng FNV-1a; backend thật phải băm bằng bcrypt/argon2.
  let hash = 0x811c9dc5
  for (const char of text) hash = Math.imul(hash ^ char.codePointAt(0), 0x01000193)
  return (hash >>> 0).toString(16)
}
const randomText = (length, alphabet = 'abcdefghjkmnpqrstuvwxyz23456789') => {
  const bytes = globalThis.crypto.getRandomValues(new Uint8Array(length))
  return [...bytes].map(byte => alphabet[byte % alphabet.length]).join('')
}
const hashed = async password => {
  const salt = randomText(10)
  return { salt, hash: await digest(salt + password) }
}
export const passwordProblem = password => (password.length >= 8 && /[a-zA-Z]/.test(password) && /\d/.test(password)
  ? '' : 'Mật khẩu cần ít nhất 8 ký tự, có cả chữ và số.')

// Mật khẩu demo trong dữ liệu mẫu được băm ngay khi khởi động, không lưu dạng thô.
export const ready = (async () => {
  if (!state.accounts.some(item => item.plain)) return refreshActor()
  const accounts = await Promise.all(state.accounts.map(async ({ plain, ...item }) => plain ? { ...item, ...await hashed(plain) } : item))
  commit({ ...state, accounts })
})()

const patchAccount = (username, patch) => current => ({
  ...current, accounts: current.accounts.map(item => item.username === username ? { ...item, ...patch } : item),
})

export async function login(username, password) {
  const name = username.trim().toLowerCase()
  const found = state.accounts.find(item => item.username === name)
  if (!found) return { ok: false, message: 'Tên đăng nhập hoặc mật khẩu chưa đúng.' }
  if (found.status === 'locked') return { ok: false, message: 'Tài khoản đã bị khóa. Vui lòng liên hệ Ban giám đốc.' }
  if (found.status === 'pending') return { ok: false, message: 'Tài khoản đang chờ trung tâm liên kết với học viên.' }
  if (found.lockedUntil > Date.now()) {
    return { ok: false, message: `Đăng nhập sai quá 5 lần. Thử lại sau ${Math.ceil((found.lockedUntil - Date.now()) / 60000)} phút.` }
  }
  if (await digest(found.salt + password) !== found.hash) {
    const failed = found.failed + 1
    commit(patchAccount(name, failed >= 5 ? { failed: 0, lockedUntil: Date.now() + 15 * 60000 } : { failed })(state))
    return { ok: false, message: failed >= 5 ? 'Đăng nhập sai 5 lần, tài khoản tạm khóa 15 phút.' : 'Tên đăng nhập hoặc mật khẩu chưa đúng.' }
  }
  const token = randomText(24)
  window.sessionStorage.setItem(SESSION_KEY, JSON.stringify({ username: name, token }))
  viewAs = null
  commit(patchAccount(name, { token, failed: 0, lockedUntil: 0, lastLogin: Date.now() })(state))
  return { ok: true }
}

export function logout() {
  window.sessionStorage.removeItem(SESSION_KEY)
  viewAs = null
  refreshActor()
  emit()
}

export function setViewAs(role) {
  viewAs = role && role !== 'admin' ? role : null
  refreshActor()
  emit()
}

// Đăng ký công khai chỉ tạo được tài khoản Phụ huynh; phải khớp mã học viên hoặc SĐT đã khai với trung tâm.
export async function registerParent({ name, username, email, phone, password, link }) {
  const user = username.trim().toLowerCase()
  if (!/^[a-z0-9._]{3,}$/.test(user)) return { ok: false, message: 'Tên đăng nhập cần ít nhất 3 ký tự, không dấu, không khoảng trắng.' }
  if (state.accounts.some(item => item.username === user)) return { ok: false, message: 'Tên đăng nhập đã tồn tại.' }
  const problem = passwordProblem(password)
  if (problem) return { ok: false, message: problem }
  const key = link.trim().toUpperCase()
  const children = state.students.filter(student => !student.parent
    && (student.id === key || (digits(link).length >= 9 && digits(student.phone) === digits(link))))
  const linked = children.length > 0
  const record = {
    username: user, name: name.trim(), role: 'parent', branch: children[0]?.branch || BRANCHES[0], email, phone,
    status: linked ? 'active' : 'pending', mustChange: false, lastLogin: null, failed: 0, lockedUntil: 0, ...await hashed(password),
  }
  commit(withNotes({
    ...state,
    accounts: [...state.accounts, record],
    students: state.students.map(student => children.includes(student) ? { ...student, parent: user, parentName: record.name } : student),
    invoices: state.invoices.map(item => children.some(child => child.id === item.studentId) ? { ...item, parentUser: user } : item),
  }, linked ? [] : [{ toRole: 'manager', type: 'account', title: 'Tài khoản phụ huynh chờ liên kết', body: `${record.name} (${phone || email}) đăng ký nhưng chưa khớp học viên.`, tab: 'settings' }]))
  return { ok: true, linked }
}

// Quên mật khẩu: OTP 6 số, hết hạn sau 5 phút, tối đa 5 lần thử. Bản demo hiện mã trên màn hình thay cho email.
const otps = new Map()
export function requestOtp(username, email) {
  const user = username.trim().toLowerCase()
  const found = state.accounts.find(item => item.username === user && item.email.toLowerCase() === email.trim().toLowerCase())
  if (!found) return { ok: false, message: 'Không tìm thấy tài khoản khớp tên đăng nhập và email.' }
  const code = randomText(6, '0123456789')
  otps.set(user, { code, expires: Date.now() + 5 * 60000, tries: 0 })
  return { ok: true, code }
}
export async function resetWithOtp(username, code, password) {
  const user = username.trim().toLowerCase()
  const entry = otps.get(user)
  if (!entry || entry.expires < Date.now()) return { ok: false, message: 'Mã OTP đã hết hạn. Vui lòng lấy mã mới.' }
  if (entry.tries >= 5) return { ok: false, message: 'Nhập sai quá 5 lần. Vui lòng lấy mã mới.' }
  if (entry.code !== code.trim()) {
    entry.tries += 1
    return { ok: false, message: `Mã OTP chưa đúng (còn ${5 - entry.tries} lần thử).` }
  }
  const problem = passwordProblem(password)
  if (problem) return { ok: false, message: problem }
  otps.delete(user)
  commit(withAudit(patchAccount(user, { ...await hashed(password), mustChange: false, failed: 0, lockedUntil: 0 })(state), `Đặt lại mật khẩu bằng OTP cho ${user}`))
  return { ok: true }
}

export async function changePassword(current, next) {
  const own = state.accounts.find(item => item.username === readSession()?.username)
  if (!own) return { ok: false, message: 'Phiên đăng nhập đã hết.' }
  if (!own.mustChange && await digest(own.salt + current) !== own.hash) return { ok: false, message: 'Mật khẩu hiện tại chưa đúng.' }
  const problem = passwordProblem(next)
  if (problem) return { ok: false, message: problem }
  commit(withAudit(patchAccount(own.username, { ...await hashed(next), mustChange: false })(state), `${own.name} đổi mật khẩu`))
  return { ok: true }
}

export async function createAccount({ name, email, phone, role, branch }) {
  if (!allowed('account.manage')) return { ok: false, message: '' }
  const base = email.split('@')[0].toLowerCase().replace(/[^a-z0-9._]/g, '')
  if (base.length < 3) return { ok: false, message: 'Email chưa hợp lệ.' }
  if (state.accounts.some(item => item.email.toLowerCase() === email.toLowerCase())) return { ok: false, message: 'Email này đã có tài khoản.' }
  let username = base
  for (let index = 2; state.accounts.some(item => item.username === username); index += 1) username = `${base}${index}`
  const temp = `Hmt${randomText(6)}9`
  const record = {
    username, name: name.trim(), role, branch: role === 'admin' ? null : branch, email, phone, status: 'active',
    mustChange: true, lastLogin: null, failed: 0, lockedUntil: 0, ...await hashed(temp),
  }
  commit(withAudit({ ...state, accounts: [...state.accounts, record] }, `Tạo tài khoản ${username} (${ROLE_LABELS[role]})`))
  return { ok: true, username, temp }
}

export async function resetAccountPassword(username) {
  if (!allowed('account.manage')) return { ok: false }
  const temp = `Hmt${randomText(6)}9`
  commit(withAudit(patchAccount(username, { ...await hashed(temp), mustChange: true, failed: 0, lockedUntil: 0 })(state), `Đặt lại mật khẩu cho ${username}`))
  return { ok: true, temp }
}

export function patchAccountByAdmin(username, patch, label) {
  if (!allowed('account.manage')) return false
  if (username === actor.username && (patch.status === 'locked' || patch.role)) {
    denyHandler('Không thể tự khóa hoặc tự đổi vai trò của chính mình.')
    return false
  }
  return update(current => withAudit(patchAccount(username, patch)(current), `${label} ${username}`))
}

export function deleteAccount(username) {
  if (!allowed('account.manage')) return false
  if (username === actor.username) {
    denyHandler('Không thể xóa tài khoản đang đăng nhập.')
    return false
  }
  return update(current => withAudit({ ...current, accounts: current.accounts.filter(item => item.username !== username) }, `Xóa tài khoản ${username}`))
}

export function resetStore() {
  if (!DEMO_MODE || !allowed('store.reset')) return false
  // Giữ lại tài khoản để phiên đăng nhập hiện tại không bị mất.
  return update(current => withAudit({ ...createSeed(), accounts: current.accounts }, 'Khôi phục dữ liệu demo'))
}

export function saveSettings(section, value) {
  if (section === 'bank' && !allowed('settings.bank')) return false
  return update(current => withAudit({ ...current, settings: { ...current.settings, [section]: value } }, `Cập nhật cài đặt: ${section}`))
}

// ---- CRM ----
export const findDuplicateLead = phone => state.leads.find(item => digits(item.phone) === digits(phone) && digits(phone).length >= 9)

export function addLead(input) {
  if (!allowed('crm.write') || !owns(input.branch)) return null
  const item = { ...input, id: nextId(state.leads, 'L'), stage: 'new', daysAgo: 0, value: Number(input.value) || 4.5 }
  update(current => ({ ...current, leads: [item, ...current.leads] }))
  return item
}

const bumpOrg = (org, branch, group, delta = 1) => org.map(item => item.branch === branch
  ? { ...item, groups: item.groups.map((count, index) => index === Math.max(0, GRADE_GROUPS.indexOf(group)) ? count + delta : count) }
  : item)

// Ghi danh: mã học viên là dữ liệu chủ (master data) nối lead → học viên → hóa đơn.
export function moveLead(leadId, stage) {
  const item = state.leads.find(entry => entry.id === leadId)
  if (!item || item.stage === stage) return null
  if (!allowed('crm.write') || !owns(item.branch)) return false
  let created = null
  update(current => {
    const next = { ...current, leads: current.leads.map(entry => entry.id === leadId ? { ...entry, stage } : entry) }
    if (stage === 'enrolled' && !current.students.some(student => student.leadId === leadId)) {
      const studentId = nextStudentId(current.students)
      created = { studentId, invoiceId: nextId(current.invoices, 'HD') }
      next.students = [{ id: studentId, leadId, name: item.student, classId: null, branch: item.branch, parent: null, parentName: item.parent, phone: item.phone, birth: '', grade: item.grade }, ...current.students]
      next.invoices = [invoice(created.invoiceId, studentId, item.student, item.course, item.branch, item.parent, null, 12, Math.round(item.value * 1e6 / 12), 0, 0, 7), ...current.invoices]
      next.targets = current.targets.map(target => target.branch === item.branch ? { ...target, actual: target.actual + 1 } : target)
      next.org = bumpOrg(current.org, item.branch, item.grade)
    }
    return next
  })
  return created
}

export const toggleActivity = id => allowed('crm.write') && update(current => ({
  ...current, activities: current.activities.map(item => item.id === id ? { ...item, done: !item.done } : item),
}))
export const addActivity = input => allowed('crm.write') && update(current => ({
  ...current, activities: [{ ...input, id: nextId(current.activities, 'A', 3), done: false }, ...current.activities],
}))

// ---- Học viên, lớp, nhân sự ----
export function addStudent({ name, classId, parentName, phone, birth, branch }) {
  const klass = state.classes.find(item => item.id === classId)
  if (!allowed('student.write') || !owns(klass?.branch || branch)) return null
  const id = nextStudentId(state.students)
  const record = { id, name: name.trim(), classId: classId || null, branch: klass?.branch || branch, parent: null, parentName, phone, birth, grade: klass?.group || '' }
  const done = update(current => withAudit({
    ...current,
    students: [record, ...current.students],
    classes: current.classes.map(item => item.id === classId ? { ...item, size: item.size + 1 } : item),
    org: bumpOrg(current.org, record.branch, klass?.group || GRADE_GROUPS[0]),
  }, `Thêm học viên ${record.name} (${id})`))
  return done ? record : null
}

export function addClass({ name, group, teacher, branch, capacity }) {
  if (!allowed('staff.write') || !owns(branch)) return null
  const record = { id: `C-${String(state.classes.length + 1).padStart(2, '0')}`, name: name.trim(), group, teacher, branch, size: 0, capacity: Number(capacity) || 18 }
  update(current => withAudit({
    ...current, classes: [...current.classes, record],
    org: current.org.map(item => item.branch === branch ? { ...item, classes: item.classes + 1 } : item),
  }, `Tạo lớp ${record.name}`))
  return record
}

export function addStaff(input) {
  if (!allowed('staff.write') || !owns(input.branch)) return null
  const record = { ...input, id: nextId(state.staff, 'NS', 2), status: 'Đang làm việc', checkIn: '—', sessions: 0, kpi: 80, salary: Number(input.salary) || 10, payroll: 'Chờ duyệt' }
  update(current => withAudit({ ...current, staff: [...current.staff, record] }, `Thêm nhân sự ${record.name}`))
  return record
}

export function approvePayroll(ids) {
  if (!allowed('payroll.approve')) return false
  const branches = [...new Set(state.staff.filter(item => ids.includes(item.id)).map(item => item.branch))]
  return update(current => withAudit(withNotes({
    ...current, staff: current.staff.map(item => ids.includes(item.id) ? { ...item, payroll: 'Đã duyệt' } : item),
  }, branches.map(branch => ({ toRole: 'manager', branch, type: 'payroll', title: 'Bảng lương đã được duyệt', body: `Ban giám đốc đã duyệt ${ids.length} phiếu lương.`, tab: 'hr' }))), `Duyệt ${ids.length} phiếu lương`))
}

export function requestPayrollApproval() {
  if (!allowed('payroll.request')) return false
  return pushNote({ toRole: 'admin', type: 'payroll', title: 'Đề nghị duyệt bảng lương', body: `${actor.name} gửi bảng lương cơ sở ${actor.branch} chờ duyệt.`, tab: 'hr' })
}

// ---- Học vụ: quét xung đột lịch/phòng ----
const minutes = time => Number(time.slice(0, 2)) * 60 + Number(time.slice(3))
const overlaps = (a, b) => a.day === b.day && minutes(a.start) < minutes(b.end) && minutes(b.start) < minutes(a.end)

export function findConflicts(candidate, sessions = state.sessions) {
  return sessions
    .filter(item => item.id !== candidate.id && overlaps(item, candidate))
    .flatMap(item => {
      const found = []
      if (item.branch === candidate.branch && item.room === candidate.room) found.push({ kind: 'room', with: item })
      if (item.teacher === candidate.teacher) found.push({ kind: 'teacher', with: item })
      return found
    })
}

export function freeRooms(candidate, sessions = state.sessions) {
  return ROOMS.filter(room => !sessions.some(item =>
    item.id !== candidate.id && item.branch === candidate.branch && item.room === room && overlaps(item, candidate)))
}

export const scanConflicts = (sessions = state.sessions) => sessions.filter(item => findConflicts(item, sessions).length > 0)
export const saveSession = input => allowed('schedule.write') && owns(input.branch) && update(current => ({
  ...current,
  sessions: input.id
    ? current.sessions.map(item => item.id === input.id ? input : item)
    : [...current.sessions, { ...input, id: nextId(current.sessions, 'S', 2) }],
}))
export const removeSession = id => allowed('schedule.write') && update(current => ({ ...current, sessions: current.sessions.filter(item => item.id !== id) }))

// ---- Học vụ: SLA nhận xét 24h ----
export function lessonSla(lesson, now = Date.now()) {
  const elapsed = lesson.endedHoursAgo + (now - SESSION_START) / HOUR
  const left = SLA_HOURS - elapsed
  if (lesson.done) return { state: 'done', label: 'Đã gửi phụ huynh', left }
  if (left <= 0) return { state: 'late', label: `Quá hạn ${Math.ceil(-left)} giờ`, left }
  if (left <= 6) return { state: 'risk', label: `Còn ${Math.max(1, Math.floor(left))} giờ`, left }
  return { state: 'ok', label: `Còn ${Math.floor(left)} giờ`, left }
}

// Gửi nhận xét: phụ huynh có tài khoản thấy ngay ở mục Kết quả và nhận thông báo.
export function saveLesson(id, students, done) {
  if (!allowed('lesson.write')) return false
  const lesson = state.lessons.find(item => item.id === id)
  const klass = state.classes.find(item => item.id === lesson.classId)
  // Giáo viên chỉ nhập kết quả cho buổi mình dạy; quản lý chỉ trong cơ sở mình.
  if (['teacher', 'assistant'].includes(actor.role) ? lesson.teacher !== actor.name : !owns(klass.branch)) {
    if (lesson.teacher !== actor.name) denyHandler('Bạn chỉ nhập kết quả cho lớp mình phụ trách.')
    return false
  }
  const notes = done ? students.flatMap(entry => {
    const child = state.students.find(student => student.name === entry.name && student.parent)
    return child ? [{ toUser: child.parent, type: 'lesson', title: `Có nhận xét mới cho ${child.name}`, body: `${klass?.name}: ${lesson.topic}.`, tab: 'p-results' }] : []
  }) : []
  return update(current => withNotes({
    ...current, lessons: current.lessons.map(item => item.id === id ? { ...item, students, done } : item),
  }, notes))
}

// ---- Đề xuất dạy bù / dạy thay ----
export function addProposal(input) {
  if (!allowed('proposal.create')) return null
  const klass = state.classes.find(item => item.id === input.classId)
  const record = { ...input, id: nextId(state.proposals, 'DX', 3), teacher: actor.name, teacherUser: actor.username, branch: klass.branch, status: 'pending', at: Date.now(), note: '' }
  update(current => withNotes({ ...current, proposals: [record, ...current.proposals] }, [{
    toRole: 'manager', branch: klass.branch, type: 'proposal', title: `Đề xuất ${input.type.toLowerCase()} cần duyệt`,
    body: `${actor.name} · ${klass.name} · ${DAYS[input.day]} ${input.start}–${input.end}.`, tab: 'education',
  }]))
  return record
}

export function decideProposal(id, approve, room) {
  if (!allowed('proposal.decide')) return { ok: false }
  const proposal = state.proposals.find(item => item.id === id)
  const klass = state.classes.find(item => item.id === proposal.classId)
  if (!owns(proposal.branch)) return { ok: false }
  const candidate = { classId: proposal.classId, day: proposal.day, start: proposal.start, end: proposal.end, room: room || proposal.room, teacher: proposal.teacher, branch: proposal.branch }
  if (approve) {
    const conflicts = findConflicts(candidate)
    if (conflicts.length) return { ok: false, conflicts }
  }
  const text = `${klass.name} · ${DAYS[proposal.day]} ${proposal.start}–${proposal.end}${approve ? ` · ${candidate.room}` : ''}`
  const parents = state.students.filter(student => student.classId === proposal.classId && student.parent).map(student => student.parent)
  update(current => withAudit(withNotes({
    ...current,
    proposals: current.proposals.map(item => item.id === id ? { ...item, status: approve ? 'approved' : 'rejected', room: candidate.room, decidedBy: actor.name } : item),
    sessions: approve ? [...current.sessions, { ...candidate, id: nextId(current.sessions, 'S', 2), makeup: proposal.type }] : current.sessions,
  }, [
    { toUser: proposal.teacherUser, type: 'proposal', title: approve ? 'Đề xuất đã được duyệt' : 'Đề xuất bị từ chối', body: text, tab: 't-proposal' },
    ...(approve ? [...new Set(parents)].map(user => ({ toUser: user, type: 'schedule', title: `Lịch ${proposal.type.toLowerCase()} mới`, body: text, tab: 'p-schedule' })) : []),
  ]), `${approve ? 'Duyệt' : 'Từ chối'} đề xuất ${id}`))
  return { ok: true }
}

// ---- CSKH ----
export function addTicket(input) {
  const item = { owner: 'Chưa phân công', status: 'new', hoursAgo: 0, branch: myBranch(), reply: '', phone: '', ...input, id: nextId(state.tickets, 'CS') }
  update(current => withNotes({ ...current, tickets: [item, ...current.tickets] }, [{
    toRole: 'manager', branch: item.branch, type: 'ticket', title: `Yêu cầu mới ${item.id}`, body: `${item.parent}: ${item.type}.`, tab: 'support',
  }]))
  return item
}
export function setTicket(id, patch) {
  const ticket = state.tickets.find(item => item.id === id)
  if (!allowed('ticket.manage') || !owns(ticket.branch)) return false
  const notes = ticket.parentUser && (patch.reply || patch.status === 'done') ? [{
    toUser: ticket.parentUser, type: 'ticket', title: patch.status === 'done' ? `Yêu cầu ${id} đã hoàn thành` : `Trung tâm phản hồi yêu cầu ${id}`,
    body: patch.reply || ticket.reply || ticket.content, tab: 'p-requests',
  }] : []
  return update(current => withNotes({ ...current, tickets: current.tickets.map(item => item.id === id ? { ...item, ...patch } : item) }, notes))
}
export function ticketSla(ticket) {
  const left = SLA_HOURS - ticket.hoursAgo
  if (ticket.status === 'done') return { state: 'done', label: 'Đã xử lý' }
  if (left <= 0) return { state: 'late', label: `Quá hạn ${-left} giờ` }
  return { state: left <= 6 ? 'risk' : 'ok', label: `Còn ${left} giờ` }
}

// Chatbot 24/7: trả lời từ cơ sở tri thức và tự tạo ticket khi phụ huynh cần người xử lý.
const INTENTS = [
  { type: 'Xin nghỉ', test: /xin nghỉ|nghỉ học|báo nghỉ|con ốm|học bù/i, faq: 'F-1' },
  { type: 'Đổi lớp', test: /đổi lớp|chuyển lớp|đổi ca|đổi lịch/i, faq: 'F-3' },
  { type: 'Học phí', test: /học phí|biên lai|thanh toán|công nợ|hóa đơn/i, faq: 'F-2' },
  { type: 'Khiếu nại', test: /khiếu nại|không hài lòng|phản ánh|chưa nhận được|chậm/i, faq: 'F-4' },
]
export function answerChat(text) {
  const intent = INTENTS.find(item => item.test.test(text))
  if (!intent) {
    const faq = state.faqs.find(item => text.toLowerCase().split(/\s+/).filter(word => word.length > 3).some(word => item.q.toLowerCase().includes(word)))
    return { reply: faq ? faq.a : 'Mình chưa có câu trả lời sẵn cho nội dung này. Bạn có thể hỏi về xin nghỉ, đổi lớp, học phí hoặc gửi phản ánh để mình tạo yêu cầu cho cơ sở.', ticket: null }
  }
  const isParent = actor?.role === 'parent'
  const ticket = addTicket({
    parent: actor ? actor.name : 'Phụ huynh (chatbot)', parentUser: isParent ? actor.username : undefined, phone: actor?.phone || '',
    student: isParent ? state.students.find(student => student.parent === actor.username)?.name || '—' : '—',
    type: intent.type, content: text, channel: 'Chatbot',
  })
  const faq = state.faqs.find(item => item.id === intent.faq)
  return { reply: `${faq.a} Mình đã tạo yêu cầu ${ticket.id} (${intent.type}) và chuyển cho quản lý cơ sở, hạn phản hồi 24 giờ.`, ticket }
}

// ---- Tài chính và học phí ----
// Tổng tiền luôn do hàm này tính, không nhận từ giao diện.
export const invoiceTotal = item => item.sessions * item.unitPrice - item.deduction + item.extra
export const invoiceState = (item, now = Date.now()) => (item.status === 'pending' && item.dueDate < now ? 'overdue' : item.status)
export const transferNote = item => `HMT ${item.studentId.replace(/\D/g, '').slice(-4)} T${item.month.slice(0, 2)}`

export function addTransaction({ type, category, amount, note, branch }) {
  if (!allowed('finance.write') || !owns(branch)) return null
  const value = Math.round(Number(amount))
  if (!(value > 0)) return null
  const record = { id: nextId(state.transactions.filter(item => item.type === type), type === 'income' ? 'PT' : 'PC', 3), type, category, amount: value, branch, note, at: Date.now(), by: actor.name }
  update(current => withAudit({ ...current, transactions: [record, ...current.transactions] }, `Tạo ${type === 'income' ? 'phiếu thu' : 'phiếu chi'} ${record.id}`))
  return record
}
export function removeTransaction(id) {
  if (!allowed('finance.write') || !owns(state.transactions.find(item => item.id === id)?.branch)) return false
  return update(current => withAudit({ ...current, transactions: current.transactions.filter(item => item.id !== id) }, `Xóa phiếu ${id}`))
}

export function remindInvoices(ids) {
  if (!allowed('finance.write')) return 0
  const targets = state.invoices.filter(item => ids.includes(item.id) && item.status === 'pending' && (actor.role === 'admin' || item.branch === actor.branch))
  update(current => withAudit(withNotes({
    ...current, invoices: current.invoices.map(item => targets.includes(item) ? { ...item, remindedAt: Date.now() } : item),
  }, targets.filter(item => item.parentUser).map(item => ({
    toUser: item.parentUser, type: 'invoice', title: `Nhắc học phí ${item.student}`, body: `Hóa đơn ${item.id} tháng ${item.month} chưa thanh toán.`, tab: 'p-fees',
  }))), `Nhắc phí ${targets.length} hóa đơn`))
  return targets.length
}

// Phụ huynh báo đã chuyển khoản: hóa đơn chờ kế toán/quản lý xác nhận.
export function payInvoice(id) {
  if (!allowed('invoice.pay')) return false
  const item = state.invoices.find(entry => entry.id === id && entry.parentUser === actor.username && entry.status === 'pending')
  if (!item) return false
  const note = { branch: item.branch, type: 'payment', title: 'Phụ huynh báo đã chuyển khoản', body: `${item.parent} · ${item.student} · hóa đơn ${id}.`, tab: 'finance' }
  return update(current => withNotes({
    ...current, invoices: current.invoices.map(entry => entry.id === id ? { ...entry, status: 'awaiting' } : entry),
  }, [{ ...note, toRole: 'manager' }, { ...note, toRole: 'accountant' }]))
}

// Xác nhận đã nhận tiền: ghi phiếu thu nên doanh thu trên Dashboard và Tài chính tăng theo.
export function confirmInvoice(id) {
  if (!allowed('invoice.confirm')) return false
  const item = state.invoices.find(entry => entry.id === id && entry.status !== 'paid')
  if (!item || !owns(item.branch)) return false
  const receipt = { id: nextId(state.transactions.filter(entry => entry.type === 'income'), 'PT', 3), type: 'income', category: 'Học phí', amount: invoiceTotal(item), branch: item.branch, note: `${item.student} · hóa đơn ${id}`, at: Date.now(), by: actor.name }
  return update(current => withAudit(withNotes({
    ...current,
    invoices: current.invoices.map(entry => entry.id === id ? { ...entry, status: 'paid', paidAt: Date.now() } : entry),
    transactions: [receipt, ...current.transactions],
  }, item.parentUser ? [{ toUser: item.parentUser, type: 'payment', title: 'Đã xác nhận thanh toán', body: `Trung tâm đã nhận học phí hóa đơn ${id}. Cảm ơn anh/chị.`, tab: 'p-fees' }] : []), `Xác nhận thanh toán ${id}`))
}

// ---- Tin nhắn ----
const classTeacherUsers = (current, classIds) => current.accounts
  .filter(item => item.role === 'teacher' && current.classes.some(klass => classIds.includes(klass.id) && klass.teacher === item.name))
export function contactsFor(who = actor, current = state) {
  if (!who) return []
  const active = current.accounts.filter(item => item.status === 'active' && item.username !== who.username)
  if (who.role === 'admin') return active
  if (who.role === 'parent') {
    const classIds = current.students.filter(student => student.parent === who.username).map(student => student.classId)
    return [...classTeacherUsers(current, classIds), ...active.filter(item => item.role === 'manager' && item.branch === who.branch)]
  }
  if (who.role === 'teacher' || who.role === 'assistant') {
    const classIds = current.classes.filter(klass => klass.teacher === who.name).map(klass => klass.id)
    const parents = current.students.filter(student => classIds.includes(student.classId) && student.parent).map(student => student.parent)
    return active.filter(item => parents.includes(item.username) || (item.role === 'manager' && item.branch === who.branch))
  }
  return active.filter(item => item.role === 'admin' || item.branch === who.branch)
}
export const threadsFor = (who = actor, current = state) => current.threads
  .filter(thread => thread.members.includes(who?.username)).sort((a, b) => b.lastAt - a.lastAt)
export const isUnread = (thread, who = actor) => thread.lastAt > (thread.seen[who.username] || 0)

export function openThread(username) {
  const existing = state.threads.find(thread => thread.members.length === 2 && thread.members.includes(actor.username) && thread.members.includes(username))
  if (existing) return existing.id
  if (!contactsFor().some(item => item.username === username)) return null
  const other = state.accounts.find(item => item.username === username)
  const id = nextId(state.threads, 'TH', 2)
  return update(current => ({ ...current, threads: [{ id, title: `${actor.name} · ${other.name}`, members: [actor.username, username], lastAt: Date.now(), seen: { [actor.username]: Date.now() } }, ...current.threads] })) ? id : null
}

export function sendMessage(threadId, text) {
  const body = text.trim()
  const thread = state.threads.find(item => item.id === threadId && item.members.includes(actor.username))
  if (!body || !thread) return false
  const now = Date.now()
  return update(current => withNotes({
    ...current,
    messages: [...current.messages, { id: nextId(current.messages, 'M', 3), threadId, from: actor.username, text: body, at: now }],
    threads: current.threads.map(item => item.id === threadId ? { ...item, lastAt: now, seen: { ...item.seen, [actor.username]: now } } : item),
  }, thread.members.filter(user => user !== actor.username).map(user => ({ toUser: user, type: 'message', title: `Tin nhắn mới từ ${actor.name}`, body: body.slice(0, 80), tab: 'messages' }))))
}
export const markThreadSeen = threadId => update(current => ({
  ...current, threads: current.threads.map(item => item.id === threadId ? { ...item, seen: { ...item.seen, [actor.username]: Date.now() } } : item),
}), { silent: true })

// ---- Giao việc ----
export function assigneesFor(who = actor, current = state) {
  const staff = current.accounts.filter(item => item.status === 'active' && item.role !== 'parent' && item.username !== who?.username)
  if (who?.role === 'admin') return staff.filter(item => item.role === 'manager')
  if (who?.role === 'manager') return staff.filter(item => item.branch === who.branch && !['admin', 'manager'].includes(item.role))
  return []
}
export function addTask({ title, description, assignee, priority, due }) {
  if (!allowed('task.assign') || !assigneesFor().some(item => item.username === assignee)) return null
  const target = state.accounts.find(item => item.username === assignee)
  const record = { id: nextId(state.tasks, 'CV', 2), title: title.trim(), description, assignee, assigner: actor.username, branch: target.branch, priority, due: new Date(due).getTime(), status: 'new', comments: [] }
  update(current => withNotes({ ...current, tasks: [record, ...current.tasks] }, [{ toUser: assignee, type: 'task', title: 'Bạn được giao việc mới', body: record.title, tab: 'tasks' }]))
  return record
}
export function patchTask(id, patch, comment) {
  const task = state.tasks.find(item => item.id === id && [item.assignee, item.assigner].includes(actor.username))
  if (!task) return false
  const other = task.assignee === actor.username ? task.assigner : task.assignee
  const labels = { new: 'Mới', doing: 'Đang làm', done: 'Hoàn thành' }
  return update(current => withNotes({
    ...current,
    tasks: current.tasks.map(item => item.id === id ? {
      ...item, ...patch, comments: comment ? [...item.comments, { from: actor.name, text: comment, at: Date.now() }] : item.comments,
    } : item),
  }, [{ toUser: other, type: 'task', title: comment ? `${actor.name} bình luận công việc` : `Công việc chuyển sang “${labels[patch.status]}”`, body: comment || task.title, tab: 'tasks' }]))
}

// ---- Phần bổ sung theo Figma: lịch trực, nhập nhân sự, sửa phiếu, kịch bản tự động, gia hạn ----
export const SHIFTS = ['Sáng 8–12h', 'Chiều 13–17h', 'Tối 17–21h']
export const RENEWAL_STATUSES = ['Chưa liên hệ', 'Đã liên hệ', 'Đã tái đăng ký', 'Không tiếp tục']

export function assignShift(branch, day, shift, staffId) {
  if (!allowed('staff.write') || !owns(branch)) return false
  if (state.shifts.some(item => item.branch === branch && item.day === day && item.shift === shift && item.staffId === staffId)) return false
  return update(current => ({ ...current, shifts: [...current.shifts, { id: nextId(current.shifts, 'LT', 2), branch, day, shift, staffId }] }))
}
export const removeShift = id => allowed('staff.write') && update(current => ({ ...current, shifts: current.shifts.filter(item => item.id !== id) }))
// Cảnh báo trùng: một người bị xếp từ 2 ca trở lên trong cùng một ngày.
export const shiftClashes = (shifts = state.shifts) => shifts.filter(item => shifts.some(other => other.id !== item.id && other.staffId === item.staffId && other.day === item.day))

// Nhập danh sách nhân sự từ CSV (cột: Họ tên, Vị trí, SĐT, Hợp đồng, Lương triệu). Dòng thiếu tên hoặc sai SĐT bị bỏ qua.
export function importStaff(rows, branch) {
  if (!allowed('staff.write') || !owns(branch)) return { added: 0, skipped: rows.length }
  const valid = rows.filter(row => row.name?.trim() && /^0\d{9}$/.test(digits(row.phone)) && !state.staff.some(item => digits(item.phone) === digits(row.phone)))
  update(current => withAudit({
    ...current,
    staff: [...current.staff, ...valid.map((row, index) => ({
      id: `NS-${String(current.staff.length + index + 1).padStart(2, '0')}`, name: row.name.trim(), role: row.role?.trim() || 'Hành chính', branch,
      phone: row.phone.trim(), contract: row.contract?.trim() || 'Toàn thời gian', joined: new Date().toLocaleDateString('vi-VN'),
      status: 'Đang làm việc', checkIn: '—', sessions: 0, kpi: 80, salary: Number(String(row.salary).replace(',', '.')) || 10, payroll: 'Chờ duyệt',
    }))],
  }, `Nhập ${valid.length} nhân sự từ CSV`))
  return { added: valid.length, skipped: rows.length - valid.length }
}

export function updateTransaction(id, { category, amount, note, branch }) {
  if (!allowed('finance.write') || !owns(state.transactions.find(item => item.id === id)?.branch) || !owns(branch)) return false
  const value = Math.round(Number(amount))
  if (!(value > 0)) return false
  return update(current => withAudit({
    ...current, transactions: current.transactions.map(item => item.id === id ? { ...item, category, amount: value, note, branch } : item),
  }, `Sửa phiếu ${id}`))
}
export const restoreTransaction = record => allowed('finance.write') && update(current => ({ ...current, transactions: [record, ...current.transactions] }))

export const toggleAutomation = id => allowed('support.write') && update(current => withAudit({
  ...current, automations: current.automations.map(item => item.id === id ? { ...item, enabled: !item.enabled } : item),
}, `Bật/tắt kịch bản ${id}`))
export const setRenewal = (id, status) => allowed('support.write') && update(current => ({
  ...current, renewals: current.renewals.map(item => item.id === id ? { ...item, status } : item),
}))
