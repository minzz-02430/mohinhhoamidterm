import { useState } from 'react'
import { DAYS, invoiceTotal, monthKey, remindInvoices, useStore } from './store'
import { debtTotal, groupBreakdown, inBranch, monthTotal, monthlyHistory, overdueInvoices, payrollPending, payrollTotal, studentCount, classCount } from './selectors'
import { exportCsv, formatMoney, formatTime, percent } from './format'
import { StudentForm } from './forms'
import { Badge, BarChart, BranchFilter, Donut, Empty, Kpi, PageHead, Progress, Select, branchScope, navigate, toast } from './ui'

const compact = value => formatMoney(value, { compact: true })
const millions = value => Math.round(value / 1e6)

export default function DashboardModule({ role }) {
  const store = useStore()
  const [branch, setBranch] = useState('all')
  const [adding, setAdding] = useState(false)
  const [month, setMonth] = useState(monthKey())
  const scope = role === 'admin' ? branch : branchScope(role)
  const now = Date.now()

  const students = studentCount(store, scope)
  const income = monthTotal(store, scope, 'income', month)
  const months = [...new Set([monthKey(), ...store.transactions.map(item => monthKey(item.at))])]
  const overdue = overdueInvoices(store, scope, now)
  const pending = payrollPending(store, scope)
  const history = monthlyHistory(store, scope)
  const previous = history.at(-2)
  const growth = previous.students ? ((students - previous.students) / previous.students) * 100 : 0
  const target = Math.round(store.quality.target * (students / studentCount(store, 'all'))) * 1e6
  const today = (new Date().getDay() + 6) % 7
  const upcoming = store.sessions.filter(item => inBranch(item, scope) && item.day === today).sort((a, b) => a.start.localeCompare(b.start))
  const className = id => store.classes.find(item => item.id === id)?.name || id

  const exportReport = () => {
    const count = exportCsv('dashboard', [
      ['Cơ sở', row => row.branch], ['Học viên', row => studentCount(store, row.branch)], ['Số lớp', row => classCount(store, row.branch)],
      [`Doanh thu ${monthKey()} (đ)`, row => monthTotal(store, row.branch, 'income')], ['Học phí chưa thu (đ)', row => debtTotal(store, row.branch)],
      ['Khoản quá hạn', row => overdueInvoices(store, row.branch, now).length],
    ], store.org.filter(item => inBranch(item, scope)))
    toast(`Đã xuất báo cáo ${count} cơ sở ra file CSV.`)
  }
  const remind = ids => {
    const count = remindInvoices(ids)
    if (count) toast(`Đã gửi nhắc phí ${count} khoản. Phụ huynh có tài khoản nhận thông báo ngay.`)
  }

  return (
    <>
      <PageHead title="Dashboard tổng quan" description={`Số liệu tháng ${monthKey()}, cập nhật lúc ${formatTime(now)} từ cùng một nguồn với Tài chính và Báo cáo.`}>
        <Select label="Tháng" icon="fa-calendar" value={month} onChange={setMonth} options={months.map(item => [item, `Tháng ${item}`])} />
        <BranchFilter role={role} value={branch} onChange={setBranch} />
        <button type="button" className="button" onClick={exportReport}><i className="fa-solid fa-download" aria-hidden="true"></i>Xuất báo cáo</button>
        <button type="button" className="button primary" onClick={() => setAdding(true)}><i className="fa-solid fa-plus" aria-hidden="true"></i>Thêm học viên</button>
      </PageHead>

      <div className="kpi-grid">
        <Kpi label="Học viên đang học" value={students} icon="fa-graduation-cap" note={`${growth >= 0 ? '+' : ''}${growth.toFixed(1)}% so với tháng trước · ${classCount(store, scope)} lớp`} />
        <Kpi label={`Doanh thu tháng ${month}`} value={income / 1e6} unit="triệu" icon="fa-sack-dollar" format={value => value.toLocaleString('vi-VN', { maximumFractionDigits: 1 })} note={month === monthKey() && previous.income ? `${income >= previous.income ? '+' : ''}${(((income - previous.income) / previous.income) * 100).toFixed(1)}% so với tháng trước (${compact(previous.income)})` : 'Tổng phiếu thu trong tháng'} />
        <Kpi label="Học phí chưa thu" value={debtTotal(store, scope) / 1e6} unit="triệu" icon="fa-file-invoice-dollar" format={value => value.toLocaleString('vi-VN', { maximumFractionDigits: 1 })} tone={overdue.length ? 'warn' : 'good'} note={overdue.length ? `${overdue.length} khoản đã quá hạn` : 'Không có khoản quá hạn'} />
        <Kpi label="Lương chờ duyệt" value={payrollTotal(store, scope) / 1e6} unit="triệu" icon="fa-users" format={value => value.toLocaleString('vi-VN', { maximumFractionDigits: 1 })} tone={pending.length ? 'warn' : 'good'} note={pending.length ? `${pending.length} phiếu lương chờ Ban giám đốc` : 'Đã duyệt toàn bộ'} />
      </div>

      <div className="grid-2">
        <article className="card">
          <h2 className="card-title">Thu và chi 6 tháng gần nhất <span className="muted">Đơn vị: triệu đồng</span></h2>
          <BarChart data={history} series={[['income', 'Thu', '#ee6a25'], ['expense', 'Chi', '#f7c9ac']]} format={millions} />
          <div className="hm-goal">
            <span>Đã thu {compact(income)} / mục tiêu {compact(target)}</span>
            <Progress value={percent(income, target)} tone={income >= target ? 'green' : 'orange'} label="Tiến độ doanh thu so với mục tiêu tháng" />
            <strong>{percent(income, target)}%</strong>
          </div>
        </article>
        <article className="card hm-stretch">
          <h2 className="card-title">Cơ cấu học viên <span className="muted">Theo khối lớp</span></h2>
          <Donut data={groupBreakdown(store, scope)} unit="HV" centerLabel="học viên" />
          <div className="hm-goal"><span>Tỷ lệ duy trì học viên</span><Progress value={store.quality.retention} tone="green" label="Tỷ lệ duy trì" /><strong>{store.quality.retention}%</strong></div>
        </article>
      </div>

      <div className="grid-2">
        <article className="card hm-panel">
          <div className="hm-toolbar">
            <h2 className="card-title hm-flat">Học phí quá hạn <Badge tone={overdue.length ? 'red' : 'green'}>{overdue.length} khoản</Badge></h2>
            <button type="button" className="button small" disabled={!overdue.length} onClick={() => remind(overdue.map(item => item.id))}><i className="fa-solid fa-paper-plane" aria-hidden="true"></i>Nhắc phí tất cả</button>
          </div>
          {!overdue.length && <Empty icon="fa-circle-check">Không có khoản học phí nào quá hạn.</Empty>}
          {overdue.length > 0 && (
            <div className="table-wrap">
              <table>
                <thead><tr><th>HỌC VIÊN</th><th>LỚP</th><th>SỐ TIỀN</th><th>QUÁ HẠN</th><th></th></tr></thead>
                <tbody>
                  {overdue.map(item => (
                    <tr key={item.id}>
                      <td><strong>{item.student}</strong><br /><small>{item.id} · {item.branch}</small></td>
                      <td>{item.classLabel}</td>
                      <td><strong>{formatMoney(invoiceTotal(item))}</strong></td>
                      <td><Badge tone="red">{Math.ceil((now - item.dueDate) / 86400000)} ngày</Badge></td>
                      <td>{item.remindedAt
                        ? <Badge tone="green" icon="fa-check">Đã nhắc lúc {formatTime(item.remindedAt)}</Badge>
                        : <button type="button" className="button small" onClick={() => remind([item.id])}>Nhắc phí</button>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </article>
        <div className="hm-stack">
          <article className="card">
            <h2 className="card-title">Kỳ lương chờ duyệt <Badge tone={pending.length ? 'amber' : 'green'}>{pending.length} phiếu</Badge></h2>
            <p className="hm-form-note">{pending.length ? `Tổng ${compact(payrollTotal(store, scope))} đang chờ Ban giám đốc duyệt.` : 'Không còn phiếu lương nào chờ duyệt.'}</p>
            <button type="button" className="button small" onClick={() => navigate('hr')}>Xem bảng lương<i className="fa-solid fa-arrow-right" aria-hidden="true"></i></button>
          </article>
          <article className="card">
            <h2 className="card-title">Lớp học hôm nay <span className="muted">{DAYS[today]}</span></h2>
            {!upcoming.length && <Empty icon="fa-mug-hot">Hôm nay không có buổi học nào.</Empty>}
            <ul className="hm-mini-list">
              {upcoming.map(item => (
                <li key={item.id}>
                  <strong>{item.start}</strong>
                  <span>{className(item.classId)}<small>GV {item.teacher} · {item.room} · {item.branch}</small></span>
                  {item.makeup && <Badge tone="blue">{item.makeup}</Badge>}
                </li>
              ))}
            </ul>
          </article>
        </div>
      </div>

      {adding && <StudentForm role={role} onClose={() => setAdding(false)} />}
    </>
  )
}
