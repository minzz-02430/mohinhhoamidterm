import { useState } from 'react'
import { confirmInvoice, invoiceState, invoiceTotal, monthKey, remindInvoices, removeTransaction, restoreTransaction, useStore } from './store'
import { debtTotal, inBranch, monthTotal, monthlyHistory, unpaidInvoices } from './selectors'
import { exportCsv, formatDate, formatMoney, formatTime } from './format'
import { TransactionForm } from './forms'
import { Badge, BarChart, BranchFilter, Empty, Kpi, PageHead, Pager, Select, Tabs, branchScope, toast, usePager } from './ui'

const compactNumber = value => value.toLocaleString('vi-VN', { maximumFractionDigits: 1 })
const STATE = { pending: ['Chờ thanh toán', 'slate'], overdue: ['Quá hạn', 'red'], awaiting: ['Chờ xác nhận', 'amber'], paid: ['Đã thanh toán', 'green'] }
const TX_COLUMNS = [
  ['Mã phiếu', row => row.id], ['Ngày', row => formatDate(row.at)], ['Loại', row => (row.type === 'income' ? 'Thu' : 'Chi')], ['Hạng mục', row => row.category],
  ['Số tiền (đ)', row => row.amount], ['Cơ sở', row => row.branch], ['Diễn giải', row => row.note], ['Người lập', row => row.by],
]

function Ledger({ rows, canWrite, onEdit }) {
  const pager = usePager(rows, 7)
  if (!rows.length) return <Empty icon="fa-receipt">Chưa có phiếu nào trong kỳ này.</Empty>
  return (
    <>
      <div className="table-wrap">
        <table>
          <thead><tr><th>MÃ PHIẾU</th><th>NGÀY</th><th>LOẠI</th><th>HẠNG MỤC</th><th>DIỄN GIẢI</th><th>CƠ SỞ</th><th>SỐ TIỀN</th><th></th></tr></thead>
          <tbody>
            {pager.rows.map(row => (
              <tr key={row.id}>
                <td><strong>{row.id}</strong></td>
                <td>{formatDate(row.at)}</td>
                <td><Badge tone={row.type === 'income' ? 'green' : 'red'}>{row.type === 'income' ? 'Thu' : 'Chi'}</Badge></td>
                <td>{row.category}</td>
                <td>{row.note}<br /><small>{row.by}</small></td>
                <td>{row.branch}</td>
                <td><strong>{row.type === 'income' ? '+' : '−'}{formatMoney(row.amount)}</strong></td>
                <td>{canWrite && (
                  <span className="hm-row-actions">
                    <button type="button" className="hm-icon-btn" aria-label={`Sửa phiếu ${row.id}`} onClick={() => onEdit(row)}><i className="fa-solid fa-pen" aria-hidden="true"></i></button>
                    <button type="button" className="hm-icon-btn" aria-label={`Xóa phiếu ${row.id}`} onClick={() => {
                      if (removeTransaction(row.id)) toast(`Đã xóa phiếu ${row.id}.`, { label: 'Hoàn tác', run: () => restoreTransaction(row) })
                    }}><i className="fa-solid fa-trash-can" aria-hidden="true"></i></button>
                  </span>
                )}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Pager pager={pager} />
    </>
  )
}

function Debts({ invoices, now }) {
  const pager = usePager(invoices, 7)
  if (!invoices.length) return <Empty icon="fa-circle-check">Không còn khoản học phí nào chưa thu.</Empty>
  return (
    <>
      <div className="table-wrap">
        <table>
          <thead><tr><th>HÓA ĐƠN</th><th>HỌC VIÊN</th><th>PHỤ HUYNH</th><th>KỲ</th><th>SỐ TIỀN</th><th>HẠN</th><th>TRẠNG THÁI</th><th></th></tr></thead>
          <tbody>
            {pager.rows.map(item => {
              const state = invoiceState(item, now)
              const [label, tone] = STATE[state]
              return (
                <tr key={item.id}>
                  <td><strong>{item.id}</strong></td>
                  <td>{item.student}<br /><small>{item.classLabel}</small></td>
                  <td>{item.parent}</td>
                  <td>{item.month}</td>
                  <td><strong>{formatMoney(invoiceTotal(item))}</strong></td>
                  <td>{formatDate(item.dueDate)}</td>
                  <td><Badge tone={tone}>{label}</Badge></td>
                  <td className="hm-row-actions">
                    {state === 'awaiting'
                      ? <button type="button" className="button small primary" onClick={() => { if (confirmInvoice(item.id)) toast(`Đã xác nhận nhận ${formatMoney(invoiceTotal(item))} của hóa đơn ${item.id}. Doanh thu đã cập nhật.`) }}>Xác nhận đã nhận</button>
                      : item.remindedAt
                        ? <Badge tone="green" icon="fa-check">Đã nhắc lúc {formatTime(item.remindedAt)}</Badge>
                        : <button type="button" className="button small" onClick={() => { if (remindInvoices([item.id])) toast(`Đã nhắc phí hóa đơn ${item.id}.`) }}>Nhắc phí</button>}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
      <Pager pager={pager} />
    </>
  )
}

export default function FinanceModule({ role }) {
  const store = useStore()
  const [tab, setTab] = useState('cashflow')
  const [branch, setBranch] = useState('all')
  const [month, setMonth] = useState(monthKey())
  const [creating, setCreating] = useState('')
  const [editing, setEditing] = useState(null)
  const scope = role === 'admin' ? branch : branchScope(role)
  const now = Date.now()

  const income = monthTotal(store, scope, 'income', month)
  const expense = monthTotal(store, scope, 'expense', month)
  const months = [...new Set([monthKey(), ...store.transactions.map(item => monthKey(item.at))])]
  const transactions = store.transactions.filter(item => inBranch(item, scope) && monthKey(item.at) === month).sort((a, b) => b.at - a.at)
  const shown = tab === 'cashflow' ? transactions : transactions.filter(item => item.type === tab)
  const invoices = unpaidInvoices(store, scope).sort((a, b) => a.dueDate - b.dueDate)
  const awaiting = invoices.filter(item => item.status === 'awaiting').length

  const exportRows = () => {
    const count = tab === 'debt'
      ? exportCsv('cong-no', [['Hóa đơn', row => row.id], ['Học viên', row => row.student], ['Phụ huynh', row => row.parent], ['Kỳ', row => row.month], ['Số tiền (đ)', invoiceTotal], ['Hạn', row => formatDate(row.dueDate)], ['Trạng thái', row => STATE[invoiceState(row, now)][0]], ['Cơ sở', row => row.branch]], invoices)
      : exportCsv(`so-thu-chi_${month.replace('/', '-')}`, TX_COLUMNS, shown)
    toast(`Đã xuất ${count} dòng ra file CSV.`)
  }

  return (
    <>
      <PageHead title="Tài chính & Kế toán" description="Dòng tiền, sổ thu chi và công nợ học phí. Mọi phiếu ở đây làm thay đổi số liệu trên Dashboard.">
        <button type="button" className="button" onClick={() => setCreating('expense')}><i className="fa-solid fa-minus" aria-hidden="true"></i>Tạo phiếu chi</button>
        <button type="button" className="button primary" onClick={() => setCreating('income')}><i className="fa-solid fa-plus" aria-hidden="true"></i>Tạo phiếu thu</button>
      </PageHead>

      <div className="kpi-grid">
        <Kpi label={`Tổng thu tháng ${month}`} value={income / 1e6} unit="triệu" format={compactNumber} icon="fa-arrow-trend-up" note="Học phí và các khoản thu khác" />
        <Kpi label={`Tổng chi tháng ${month}`} value={expense / 1e6} unit="triệu" format={compactNumber} icon="fa-arrow-trend-down" tone="warn" note="Lương, vận hành, marketing" />
        <Kpi label="Lợi nhuận gộp" value={(income - expense) / 1e6} unit="triệu" format={compactNumber} icon="fa-scale-balanced" tone={income >= expense ? 'good' : 'bad'} note="Chênh lệch thu và chi" />
        <Kpi label="Công nợ cần thu" value={debtTotal(store, scope) / 1e6} unit="triệu" format={compactNumber} icon="fa-file-invoice-dollar" tone={awaiting ? 'warn' : 'good'} note={awaiting ? `${awaiting} khoản phụ huynh đã chuyển, chờ xác nhận` : `${invoices.length} hóa đơn chưa thanh toán`} />
      </div>

      <article className="card hm-panel">
        <div className="hm-toolbar">
          <Tabs label="Phân hệ tài chính" value={tab} onChange={setTab} tabs={[['cashflow', 'Báo cáo dòng tiền'], ['income', 'Quản lý Thu'], ['expense', 'Quản lý Chi'], ['debt', 'Công nợ học phí', invoices.length]]} />
          <div className="hm-filters">
            {tab !== 'debt' && <Select label="Kỳ" icon="fa-calendar" value={month} onChange={setMonth} options={months.map(item => [item, `Tháng ${item}`])} />}
            <BranchFilter role={role} value={branch} onChange={setBranch} />
            <button type="button" className="button small" onClick={exportRows}><i className="fa-solid fa-download" aria-hidden="true"></i>Xuất CSV</button>
          </div>
        </div>
        {tab === 'cashflow' && (
          <div>
            <h3 className="hm-subtitle">Thu và chi 6 tháng gần nhất (triệu đồng)</h3>
            <BarChart data={monthlyHistory(store, scope)} series={[['income', 'Thu', '#22c55e'], ['expense', 'Chi', '#ef4444']]} format={value => Math.round(value / 1e6)} />
            <h3 className="hm-subtitle">Giao dịch tháng {month}</h3>
          </div>
        )}
        {tab === 'debt' ? <Debts invoices={invoices} now={now} /> : <Ledger rows={shown} canWrite onEdit={setEditing} />}
      </article>

      {creating && <TransactionForm role={role} type={creating} onClose={() => setCreating('')} />}
      {editing && <TransactionForm role={role} type={editing.type} record={editing} onClose={() => setEditing(null)} />}
    </>
  )
}
