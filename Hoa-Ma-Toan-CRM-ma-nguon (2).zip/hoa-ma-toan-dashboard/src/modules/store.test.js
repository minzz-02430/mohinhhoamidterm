// Chạy: node --test src/modules/store.test.js
import test from 'node:test'
import assert from 'node:assert/strict'

// store.js đọc localStorage/sessionStorage khi nạp, nên dựng bản giả trước khi import.
const fakeStorage = () => {
  const memory = new Map()
  return { getItem: key => memory.get(key) ?? null, setItem: (key, value) => memory.set(key, value), removeItem: key => memory.delete(key) }
}
globalThis.window = { localStorage: fakeStorage(), sessionStorage: fakeStorage() }
const store = await import('./store.js')
const selectors = await import('./selectors.js')
const { buildVietQrPayload, cleanInfo, crc16 } = await import('./vietqr.js')
const { toCsv } = await import('./format.js')
await store.ready
store.setDenyHandler(() => {})

const base = { id: 'X', day: 0, start: '18:00', end: '19:30', room: 'P.101', teacher: 'A', branch: 'B1' }

test('quét xung đột: trùng phòng, trùng giáo viên, và không báo nhầm', () => {
  const sessions = [base]
  assert.deepEqual(store.findConflicts({ ...base, id: 'Y', teacher: 'C', start: '19:00', end: '20:00' }, sessions).map(item => item.kind), ['room'])
  assert.deepEqual(store.findConflicts({ ...base, id: 'Y', room: 'P.102', branch: 'B2' }, sessions).map(item => item.kind), ['teacher'])
  assert.equal(store.findConflicts({ ...base, id: 'Y', start: '19:30', end: '21:00' }, sessions).length, 0)
  assert.equal(store.findConflicts({ ...base, id: 'Y', teacher: 'C', branch: 'B2' }, sessions).length, 0)
  assert.equal(store.findConflicts({ ...base, id: 'Y', day: 1 }, sessions).length, 0)
  assert.ok(!store.freeRooms({ ...base, id: 'Y' }, sessions).includes('P.101'))
  assert.deepEqual(store.scanConflicts().map(item => item.id).sort(), ['S-07', 'S-08'])
})

test('SLA 24h: đúng hạn, sắp trễ, quá hạn, đã gửi', () => {
  const state = hours => store.lessonSla({ endedHoursAgo: hours, done: false }).state
  assert.deepEqual([state(2), state(20), state(31)], ['ok', 'risk', 'late'])
  assert.equal(store.lessonSla({ endedHoursAgo: 31, done: true }).state, 'done')
})

test('mật khẩu không lưu dạng thô và sửa phiên không nâng được quyền', async () => {
  assert.ok(store.getState().accounts.every(item => !item.plain && item.hash && item.salt))
  assert.equal((await store.login('phuhuynh', 'sai-mat-khau')).ok, false)
  assert.equal((await store.login('phuhuynh', '123456')).ok, true)
  assert.equal(store.getActor().role, 'parent')
  // Tự sửa phiên thành admin nhưng không có token của admin thì bị coi như chưa đăng nhập.
  window.sessionStorage.setItem('hoa-ma-toan-session-v2', JSON.stringify({ username: 'admin', token: 'gia-mao' }))
  store.setViewAs(null)
  assert.equal(store.getActor(), null)
})

test('một nguồn số liệu: tổng các cơ sở bằng toàn hệ thống', () => {
  const state = store.getState()
  const sum = pick => store.BRANCHES.reduce((total, branch) => total + pick(branch), 0)
  assert.equal(selectors.studentCount(state, 'all'), 248)
  assert.equal(sum(branch => selectors.studentCount(state, branch)), 248)
  assert.equal(selectors.groupBreakdown(state, 'all').reduce((total, item) => total + item.value, 0), 248)
  assert.equal(selectors.classCount(state, 'all'), 18)
  assert.equal(selectors.monthTotal(state, 'all', 'income'), 270e6)
  assert.equal(sum(branch => selectors.debtTotal(state, branch)), selectors.debtTotal(state, 'all'))
  assert.equal(selectors.monthlyHistory(state, 'all').at(-1).students, 248)
})

test('hóa đơn = số buổi × đơn giá − khấu trừ + phụ phí', () => {
  const invoice = store.getState().invoices.find(item => item.id === 'HD-1101')
  assert.equal(store.invoiceTotal(invoice), 12 * 200000 - 200000 + 100000)
  assert.equal(store.invoiceTotal(invoice), 2300000)
  assert.equal(store.invoiceState({ ...invoice, dueDate: Date.now() - 1 }), 'overdue')
})

test('thanh toán xuyên vai trò: phụ huynh báo chuyển khoản, quản lý xác nhận, doanh thu tăng', async () => {
  await store.login('phuhuynh', '123456')
  assert.equal(store.approvePayroll(['NS-01']), false)
  assert.equal(store.confirmInvoice('HD-1101'), false)
  assert.equal(store.payInvoice('HD-1103'), false) // hóa đơn của người khác
  assert.equal(store.payInvoice('HD-1101'), true)
  assert.equal(store.getState().invoices.find(item => item.id === 'HD-1101').status, 'awaiting')

  await store.login('quanly', '123456')
  assert.ok(store.notesFor().some(note => note.type === 'payment' && !note.read))
  const before = selectors.monthTotal(store.getState(), 'all', 'income')
  assert.equal(store.confirmInvoice('HD-1101'), true)
  assert.equal(selectors.monthTotal(store.getState(), 'all', 'income') - before, 2300000)
  assert.equal(store.approvePayroll(['NS-01']), false) // chỉ Ban giám đốc duyệt lương
  assert.equal(store.resetStore(), false)

  await store.login('phuhuynh', '123456')
  assert.ok(store.notesFor().some(note => note.title === 'Đã xác nhận thanh toán'))
})

test('giáo viên gửi nhận xét và đề xuất dạy bù; quản lý duyệt thì lịch được thêm', async () => {
  await store.login('giaovien', '123456')
  const lesson = store.getState().lessons.find(item => item.id === 'B-2209')
  store.saveLesson(lesson.id, lesson.students.map(item => ({ ...item, comment: 'Tốt' })), true)
  const proposal = store.addProposal({ classId: 'C-9V', type: 'Dạy bù', day: 6, start: '09:00', end: '10:30', room: 'P.101', reason: 'Bù buổi nghỉ' })
  assert.equal(store.decideProposal(proposal.id, true).ok, false) // giáo viên không tự duyệt được

  await store.login('quanly', '123456')
  const sessions = store.getState().sessions.length
  assert.equal(store.decideProposal(proposal.id, true, 'P.101').ok, true)
  assert.equal(store.getState().sessions.length, sessions + 1)

  await store.login('phuhuynh', '123456')
  const titles = store.notesFor().map(note => note.title)
  assert.ok(titles.includes('Có nhận xét mới cho Lê Bảo Nam'))
  assert.ok(titles.includes('Lịch dạy bù mới'))
})

test('ghi danh tạo mã học viên, hóa đơn và cộng số học viên một lần', async () => {
  await store.login('quanly', '123456')
  const created = store.moveLead('L-1035', 'enrolled')
  assert.equal(created.studentId, 'HV-2026-0249')
  assert.equal(store.getState().invoices[0].studentId, created.studentId)
  assert.equal(selectors.studentCount(store.getState(), 'all'), 249)
  store.moveLead('L-1035', 'trial')
  assert.equal(store.moveLead('L-1035', 'enrolled'), null)
  assert.equal(selectors.studentCount(store.getState(), 'all'), 249)
  assert.equal(store.findDuplicateLead('0912345245').id, 'L-1041')
  assert.equal(store.answerChat('xin chào').ticket, null)
  assert.equal(store.answerChat('Con tôi ốm, xin nghỉ học').ticket.type, 'Xin nghỉ')
})

test('chỉ Ban giám đốc cấp tài khoản; mật khẩu tạm buộc đổi; đăng ký công khai chỉ ra phụ huynh', async () => {
  await store.login('quanly', '123456')
  assert.equal((await store.createAccount({ name: 'X', email: 'x.y@hoamatoan.vn', phone: '', role: 'teacher', branch: store.BRANCHES[0] })).ok, false)
  await store.login('admin', '123456')
  const made = await store.createAccount({ name: 'Đỗ Hải Nam', email: 'hainam@hoamatoan.vn', phone: '', role: 'teacher', branch: store.BRANCHES[1] })
  assert.equal(made.ok, true)
  await store.login(made.username, made.temp)
  assert.equal(store.getActor().mustChange, true)
  assert.equal((await store.changePassword('', 'ngan')).ok, false)
  assert.equal((await store.changePassword('', 'matkhau2026')).ok, true)
  assert.equal(store.getActor().mustChange, false)

  const pending = await store.registerParent({ name: 'A', username: 'phb', email: 'a@b.vn', phone: '0900000001', password: 'matkhau2026', link: 'KHONG-KHOP' })
  assert.deepEqual([pending.ok, pending.linked], [true, false])
  assert.equal((await store.login('phb', 'matkhau2026')).ok, false)
  const linked = await store.registerParent({ name: 'Ngô Bá Long', username: 'phlong', email: 'l@b.vn', phone: '0989400213', password: 'matkhau2026', link: 'HV-2026-0248' })
  assert.equal(linked.linked, true)
  assert.equal(store.getState().accounts.find(item => item.username === 'phlong').role, 'parent')
})

test('quên mật khẩu cần đúng OTP', async () => {
  const { code } = store.requestOtp('ketoan', 'ketoan@hoamatoan.vn')
  assert.equal(store.requestOtp('ketoan', 'sai@email.vn').ok, false)
  assert.equal((await store.resetWithOtp('ketoan', code === '000000' ? '111111' : '000000', 'matkhau2026')).ok, false)
  assert.equal((await store.resetWithOtp('ketoan', code, 'matkhau2026')).ok, true)
  assert.equal((await store.login('ketoan', 'matkhau2026')).ok, true)
})

test('VietQR: CRC16 đúng chuẩn và nội dung không dấu', () => {
  assert.equal(crc16('123456789'), '29B1')
  assert.equal(cleanInfo('Học phí Đỗ Minh - T11!'), 'Hoc phi Do Minh T11')
  const payload = buildVietQrPayload({ bin: '970436', accountNo: '1029384756', amount: 2300000, addInfo: 'HMT 0101 T11' })
  assert.ok(payload.startsWith('000201010212'))
  assert.ok(payload.includes('0006970436') && payload.includes('54072300000') && payload.includes('5303704') && payload.includes('0812HMT 0101 T11'))
  assert.equal(payload.slice(-4), crc16(payload.slice(0, -4)))
  assert.throws(() => buildVietQrPayload({ bin: '97', accountNo: '1', amount: 0, addInfo: '' }))
})

test('CSV bọc ô có dấu phẩy và nháy kép', () => {
  assert.equal(toCsv([['Tên', row => row.a], ['Ghi chú', row => row.b]], [{ a: 'An', b: 'x, "y"' }]), 'Tên,Ghi chú\r\nAn,"x, ""y"""')
})

test('lịch trực báo trùng ca, nhập nhân sự bỏ dòng sai, sửa phiếu đổi số liệu', async () => {
  const { parseCsv } = await import('./format.js')
  await store.login('quanly', '123456')
  assert.deepEqual(store.shiftClashes().map(item => item.id).sort(), ['LT-05', 'LT-06'])
  assert.equal(store.assignShift(store.BRANCHES[0], 0, 0, 'NS-03'), false) // đã có trong ô này
  const rows = parseCsv('Họ tên,Vị trí,SĐT\r\n"Lý, An",Trợ giảng,0911222333\r\nThiếu SĐT,Hành chính,123\r\n')
  assert.deepEqual(rows[1], ['Lý, An', 'Trợ giảng', '0911222333'])
  const before = store.getState().staff.length
  const result = store.importStaff(rows.slice(1).map(([name, role, phone]) => ({ name, role, phone })), store.BRANCHES[0])
  assert.deepEqual(result, { added: 1, skipped: 1 })
  assert.equal(store.getState().staff.length, before + 1)
  const receipt = store.getState().transactions.find(item => item.type === 'income')
  const income = selectors.monthTotal(store.getState(), 'all', 'income')
  assert.equal(store.updateTransaction(receipt.id, { ...receipt, amount: receipt.amount + 500000 }), true)
  assert.equal(selectors.monthTotal(store.getState(), 'all', 'income') - income, 500000)
  await store.login('phuhuynh', '123456')
  assert.equal(store.updateTransaction(receipt.id, { ...receipt, amount: 1 }), false)
})

test('ghi dữ liệu bị chặn theo vai trò và theo cơ sở', async () => {
  const { buildVietQrUrl } = await import('./vietqr.js')
  assert.equal(buildVietQrUrl({ bankId: '970436', accountNo: '1029384756', amount: 2300000, addInfo: 'HMT 0101 T11', accountName: 'Công ty Hòa Ma Toán' }),
    'https://img.vietqr.io/image/970436-1029384756-compact2.png?amount=2300000&addInfo=HMT+0101+T11&accountName=Cong+ty+Hoa+Ma+Toan')
  await store.login('phuhuynh', '123456')
  assert.equal(store.addLead({ parent: 'X', phone: '0900000009', branch: store.BRANCHES[0] }), null)
  assert.equal(store.moveLead('L-1041', 'contacted'), false)
  assert.equal(store.saveSession({ classId: 'C-5A', day: 6, start: '08:00', end: '09:00', room: 'P.101', teacher: 'A', branch: store.BRANCHES[0] }), false)
  assert.equal(store.setTicket('CS-0205', { status: 'done' }), false)
  await store.login('quanly', '123456')
  // Quản lý cơ sở Nguyễn Chí Thanh không ghi được dữ liệu cơ sở khác.
  assert.equal(store.moveLead('L-1040', 'contacted'), false)
  assert.equal(store.confirmInvoice('HD-1107'), false)
  assert.equal(store.remindInvoices(['HD-1107']), 0)
  assert.equal(store.addTransaction({ type: 'income', category: 'Học phí', amount: 1000000, note: 'x', branch: store.BRANCHES[1] }), null)
  assert.equal(store.assignShift(store.BRANCHES[1], 0, 0, 'NS-04'), false)
  assert.notEqual(store.moveLead('L-1041', 'contacted'), false)
  await store.login('giaovien', '123456')
  const other = store.getState().lessons.find(item => item.id === 'B-2211') // buổi của giáo viên khác
  assert.equal(store.saveLesson(other.id, other.students, true), false)
})
