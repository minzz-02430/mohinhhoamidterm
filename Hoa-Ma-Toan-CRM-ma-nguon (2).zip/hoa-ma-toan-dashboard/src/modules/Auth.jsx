import { useState } from 'react'
import logoFull from '../assets/logo-full.png'
import { DEMO_MODE, ROLE_LABELS, changePassword, login, logout, registerParent, requestOtp, resetWithOtp } from './store'

const DEMO_ACCOUNTS = [['admin', 'admin'], ['quanly', 'manager'], ['giaovien', 'teacher'], ['ketoan', 'accountant'], ['phuhuynh', 'parent']]
const SYMBOLS = ['π', '∑', '√', '∫', '∞', 'Δ', 'θ', '÷', 'x²', '≈']

function Input({ label, hint, ...props }) {
  return (
    <div className="auth-field">
      <label htmlFor={props.id}>{label}</label>
      <input {...props} />
      {hint && <small>{hint}</small>}
    </div>
  )
}

function useForm(initial) {
  const [values, setValues] = useState(initial)
  const bind = key => ({ id: `auth-${key}`, value: values[key], onChange: event => setValues(current => ({ ...current, [key]: event.target.value })) })
  return [values, bind, setValues]
}

function Message({ state }) {
  return state.text ? <p className={`auth-message${state.ok ? ' success' : ''}`} role="alert">{state.text}</p> : null
}

function LoginPane({ go, notice }) {
  const [values, bind, setValues] = useForm({ username: '', password: '' })
  const [show, setShow] = useState(false)
  const [state, setState] = useState(notice || { text: '' })
  const [busy, setBusy] = useState(false)
  const [kind, setKind] = useState('staff')
  const submit = async event => {
    event.preventDefault()
    setBusy(true)
    const result = await login(values.username, values.password)
    setBusy(false)
    if (!result.ok) setState({ text: result.message })
  }
  return (
    <section className="auth-pane">
      <img className="auth-logo" src={logoFull} width="520" height="193" alt="Hòa Ma Toán, 15+ năm kinh nghiệm luyện thi" />
      <span className="auth-pill"><i className="fa-solid fa-bolt" aria-hidden="true"></i>Hệ thống quản lý trung tâm</span>
      <h2>Chào mừng trở lại!</h2>
      <div className="auth-kind" role="tablist" aria-label="Loại tài khoản">
        {[['staff', 'Nhân sự'], ['parent', 'Phụ huynh']].map(([id, label]) => (
          <button key={id} type="button" role="tab" aria-selected={kind === id} className={kind === id ? 'active' : ''} onClick={() => setKind(id)}>{label}</button>
        ))}
      </div>
      <p className="auth-subtitle">{kind === 'staff' ? 'Tài khoản nhân sự do Ban giám đốc cấp. Vai trò và cơ sở lấy theo tài khoản.' : 'Phụ huynh xem lịch học, kết quả và học phí của con mình.'}</p>
      <form onSubmit={submit}>
        <Input label="Tên đăng nhập" {...bind('username')} id="login-username" autoComplete="username" required placeholder="Nhập tên đăng nhập" />
        <div className="auth-field">
          <label htmlFor="login-password">Mật khẩu</label>
          <div className="auth-password">
            <input {...bind('password')} id="login-password" type={show ? 'text' : 'password'} autoComplete="current-password" required placeholder="Nhập mật khẩu" />
            <button className="auth-show-password" type="button" onClick={() => setShow(!show)}>{show ? 'Ẩn' : 'Hiện'}</button>
          </div>
        </div>
        <div className="auth-options">
          <span><i className="fa-solid fa-shield-halved" aria-hidden="true"></i> Khóa 15 phút sau 5 lần nhập sai</span>
          <button className="auth-link" type="button" onClick={() => go('forgot')}>Quên mật khẩu?</button>
        </div>
        <Message state={state} />
        <button className="auth-submit" type="submit" disabled={busy}>{busy ? 'Đang kiểm tra…' : 'Đăng nhập'} <i className="fa-solid fa-arrow-right-to-bracket" aria-hidden="true"></i></button>
      </form>
      {kind === 'parent' && <p className="auth-switch">Phụ huynh chưa có tài khoản? <button className="auth-link" type="button" onClick={() => go('register')}>Đăng ký ngay</button></p>}
      {DEMO_MODE && (
        <div className="demo-hint">
          <strong>Chế độ demo:</strong> bấm một vai trò để điền sẵn tài khoản mẫu.
          <div className="auth-demo-chips">
            {DEMO_ACCOUNTS.filter(([, role]) => (role === 'parent') === (kind === 'parent')).map(([username, role]) => (
              <button key={username} type="button" onClick={() => setValues({ username, password: '123456' })}>{ROLE_LABELS[role]}</button>
            ))}
          </div>
        </div>
      )}
    </section>
  )
}

function RegisterPane({ go }) {
  const [values, bind] = useForm({ name: '', username: '', email: '', phone: '', link: '', password: '', confirm: '' })
  const [state, setState] = useState({ text: '' })
  const submit = async event => {
    event.preventDefault()
    if (values.password !== values.confirm) return setState({ text: 'Mật khẩu nhập lại chưa khớp.' })
    const result = await registerParent(values)
    if (!result.ok) return setState({ text: result.message })
    return go('login', {
      ok: true,
      text: result.linked ? 'Đăng ký thành công và đã liên kết với học viên. Mời bạn đăng nhập.' : 'Đã ghi nhận đăng ký. Thông tin chưa khớp học viên nào nên tài khoản đang chờ trung tâm liên kết.',
    })
  }
  return (
    <section className="auth-pane">
      <h2>Đăng ký tài khoản Phụ huynh</h2>
      <p className="auth-subtitle">Tài khoản nhân sự (quản lý, giáo viên, kế toán…) chỉ do Ban giám đốc cấp.</p>
      <form onSubmit={submit}>
        <div className="auth-columns">
          <Input label="Họ và tên" {...bind('name')} required placeholder="Nguyễn Văn An" />
          <Input label="Tên đăng nhập" {...bind('username')} required placeholder="Không dấu, tối thiểu 3 ký tự" />
        </div>
        <div className="auth-columns">
          <Input label="Email" {...bind('email')} type="email" required placeholder="ban@example.com" />
          <Input label="Số điện thoại" {...bind('phone')} inputMode="tel" required placeholder="09xx xxx xxx" />
        </div>
        <Input label="Mã học viên hoặc SĐT đã khai với trung tâm" {...bind('link')} required placeholder="VD: HV-2026-0248" hint="Dùng để liên kết đúng con của bạn. Không khớp thì tài khoản chờ trung tâm xác nhận." />
        <div className="auth-columns">
          <Input label="Mật khẩu" {...bind('password')} type="password" required minLength={8} placeholder="Ít nhất 8 ký tự, có chữ và số" />
          <Input label="Nhập lại mật khẩu" {...bind('confirm')} type="password" required minLength={8} />
        </div>
        <Message state={state} />
        <button className="auth-submit" type="submit">Tạo tài khoản Phụ huynh</button>
      </form>
      <p className="auth-switch">Đã có tài khoản? <button className="auth-link" type="button" onClick={() => go('login')}>Quay lại đăng nhập</button></p>
    </section>
  )
}

function ForgotPane({ go }) {
  const [values, bind] = useForm({ username: '', email: '', code: '', password: '' })
  const [sent, setSent] = useState('')
  const [state, setState] = useState({ text: '' })
  const submit = async event => {
    event.preventDefault()
    if (!sent) {
      const result = requestOtp(values.username, values.email)
      if (!result.ok) return setState({ text: result.message })
      setSent(result.code)
      return setState({ ok: true, text: 'Đã gửi mã OTP tới email đăng ký. Mã có hiệu lực 5 phút.' })
    }
    const result = await resetWithOtp(values.username, values.code, values.password)
    if (!result.ok) return setState({ text: result.message })
    return go('login', { ok: true, text: 'Đã đặt lại mật khẩu. Mời bạn đăng nhập.' })
  }
  return (
    <section className="auth-pane">
      <h2>Khôi phục mật khẩu</h2>
      <p className="auth-subtitle">Xác minh bằng mã OTP 6 số gửi tới email đã đăng ký.</p>
      <form onSubmit={submit}>
        <Input label="Tên đăng nhập" {...bind('username')} required disabled={Boolean(sent)} />
        <Input label="Email đã đăng ký" {...bind('email')} type="email" required disabled={Boolean(sent)} />
        {sent && (
          <>
            {DEMO_MODE && <p className="demo-hint"><strong>Chế độ demo:</strong> mã OTP là <strong>{sent}</strong> (bản thật gửi qua email).</p>}
            <Input label="Mã OTP" {...bind('code')} inputMode="numeric" pattern="[0-9]{6}" required placeholder="6 chữ số" />
            <Input label="Mật khẩu mới" {...bind('password')} type="password" required minLength={8} placeholder="Ít nhất 8 ký tự, có chữ và số" />
          </>
        )}
        <Message state={state} />
        <button className="auth-submit" type="submit">{sent ? 'Đặt lại mật khẩu' : 'Gửi mã OTP'}</button>
      </form>
      <p className="auth-switch">Nhớ mật khẩu? <button className="auth-link" type="button" onClick={() => go('login')}>Quay lại đăng nhập</button></p>
    </section>
  )
}

function ChangePane() {
  const [values, bind] = useForm({ password: '', confirm: '' })
  const [state, setState] = useState({ text: '' })
  const submit = async event => {
    event.preventDefault()
    if (values.password !== values.confirm) return setState({ text: 'Mật khẩu nhập lại chưa khớp.' })
    const result = await changePassword('', values.password)
    if (!result.ok) setState({ text: result.message })
    return undefined
  }
  return (
    <section className="auth-pane">
      <h2>Đổi mật khẩu lần đầu</h2>
      <p className="auth-subtitle">Tài khoản đang dùng mật khẩu tạm do Ban giám đốc cấp. Hãy đặt mật khẩu riêng để tiếp tục.</p>
      <form onSubmit={submit}>
        <Input label="Mật khẩu mới" {...bind('password')} type="password" required minLength={8} placeholder="Ít nhất 8 ký tự, có chữ và số" />
        <Input label="Nhập lại mật khẩu mới" {...bind('confirm')} type="password" required minLength={8} />
        <Message state={state} />
        <button className="auth-submit" type="submit">Lưu mật khẩu và vào hệ thống</button>
      </form>
      <p className="auth-switch"><button className="auth-link" type="button" onClick={logout}>Đăng xuất</button></p>
    </section>
  )
}

export default function Auth({ mustChange }) {
  const [view, setView] = useState({ name: 'login' })
  const go = (name, notice) => setView({ name, notice })
  // Ký hiệu toán trôi nhẹ theo chuột (parallax); CSS tự tắt khi người dùng chọn giảm chuyển động.
  const parallax = event => {
    event.currentTarget.style.setProperty('--px', (event.clientX / window.innerWidth - 0.5).toFixed(3))
    event.currentTarget.style.setProperty('--py', (event.clientY / window.innerHeight - 0.5).toFixed(3))
  }
  return (
    <section className="auth-screen" aria-label="Đăng nhập hệ thống" onMouseMove={parallax}>
      <div className="auth-math" aria-hidden="true">
        {SYMBOLS.map((symbol, index) => <span key={symbol} style={{ '--i': index }}>{symbol}</span>)}
      </div>
      <div className="auth-card">
        <aside className="auth-art">
          <article className="auth-hero">
            <span className="auth-hero-tag"><i className="fa-solid fa-school" aria-hidden="true"></i>Mạng lưới 5 cơ sở</span>
            <h2>Hòa Ma Toán CRM</h2>
            <p>Một hệ thống cho tuyển sinh, học vụ, tài chính và chăm sóc phụ huynh, dùng chung một mã học viên xuyên suốt.</p>
            <div className="auth-stats">
              <div><strong>5</strong><span>cơ sở</span></div>
              <div><strong>15+</strong><span>năm luyện thi</span></div>
            </div>
          </article>
          <article className="auth-feature">
            <span className="auth-feature-icon hm-green"><i className="fa-solid fa-user-plus" aria-hidden="true"></i></span>
            <div><strong>Tuyển sinh không sót lead</strong><p>Pipeline theo cơ sở và kênh, tự phát hiện lead trùng số điện thoại.</p></div>
          </article>
          <article className="auth-feature">
            <span className="auth-feature-icon hm-amber"><i className="fa-solid fa-calendar-check" aria-hidden="true"></i></span>
            <div><strong>Xếp lịch tự quét xung đột</strong><p>Trùng phòng hay trùng giáo viên được chặn ngay khi xếp thời khóa biểu.</p></div>
          </article>
          <article className="auth-feature">
            <span className="auth-feature-icon hm-blue"><i className="fa-solid fa-comments" aria-hidden="true"></i></span>
            <div><strong>Các vai trò làm việc cùng nhau</strong><p>Thông báo, tin nhắn, giao việc và thanh toán VietQR nối phụ huynh, giáo viên, quản lý.</p></div>
          </article>
        </aside>
        <div className="auth-form-side">
          {mustChange ? <ChangePane />
            : view.name === 'register' ? <RegisterPane go={go} />
              : view.name === 'forgot' ? <ForgotPane go={go} />
                : <LoginPane key={view.notice?.text} go={go} notice={view.notice} />}
        </div>
      </div>
    </section>
  )
}
