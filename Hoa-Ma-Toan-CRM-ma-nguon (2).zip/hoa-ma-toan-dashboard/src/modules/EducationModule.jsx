import { useState } from 'react'
import {
  BRANCHES, DAYS, myBranch, ROOMS,
  decideProposal, findConflicts, freeRooms, lessonSla, removeSession, saveLesson, saveSession, scanConflicts, useStore,
} from './store'
import { ClassForm, StudentForm } from './forms'
import { Badge, BranchFilter, Empty, Field, Kpi, Modal, PageHead, Progress, Tabs, percent } from './ui'

const slaTone = { done: 'green', ok: 'blue', risk: 'amber', late: 'red' }
const slaIcon = { done: 'fa-circle-check', ok: 'fa-clock', risk: 'fa-hourglass-half', late: 'fa-triangle-exclamation' }
const conflictText = (conflict, className) => conflict.kind === 'room'
  ? `Phòng ${conflict.with.room} đã có lớp ${className(conflict.with.classId)} lúc ${conflict.with.start}–${conflict.with.end}`
  : `GV ${conflict.with.teacher} đang dạy lớp ${className(conflict.with.classId)} lúc ${conflict.with.start}–${conflict.with.end}`

function ClassTable({ classes }) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr><th>LỚP</th><th>KHỐI</th><th>GIÁO VIÊN</th><th>CƠ SỞ</th><th>SĨ SỐ</th><th>TỶ LỆ LẤP ĐẦY</th><th>TRẠNG THÁI</th></tr>
        </thead>
        <tbody>
          {classes.map(item => {
            const rate = percent(item.size, item.capacity)
            return (
              <tr key={item.id}>
                <td><strong>{item.name}</strong><br /><small>{item.id}</small></td>
                <td>{item.group}</td>
                <td>{item.teacher}</td>
                <td>{item.branch}</td>
                <td>{item.size}/{item.capacity}</td>
                <td>
                  <div className="hm-cell-progress">
                    <Progress value={rate} tone={rate >= 100 ? 'red' : 'orange'} label={`Lấp đầy ${item.name}`} />
                    <span>{rate}%</span>
                  </div>
                </td>
                <td><Badge tone={rate >= 100 ? 'red' : 'green'}>{rate >= 100 ? 'Đủ sĩ số' : 'Đang tuyển'}</Badge></td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}

function SessionForm({ initial, classes, sessions, onClose, notify }) {
  const [form, setForm] = useState(initial)
  const className = id => classes.find(item => item.id === id)?.name || id
  const set = key => event => {
    const value = key === 'day' ? Number(event.target.value) : event.target.value
    setForm(current => {
      const next = { ...current, [key]: value }
      // Chọn lớp thì giáo viên và cơ sở đi theo lớp đó.
      if (key === 'classId') {
        const picked = classes.find(item => item.id === value)
        next.teacher = picked.teacher
        next.branch = picked.branch
      }
      return next
    })
  }
  const validTime = form.start < form.end
  const conflicts = validTime ? findConflicts(form, sessions) : []
  const suggestions = conflicts.some(item => item.kind === 'room') ? freeRooms(form, sessions) : []
  const teachers = [...new Set(classes.map(item => item.teacher))]

  const submit = event => {
    event.preventDefault()
    if (!validTime || conflicts.length) return
    saveSession(form)
    notify(`Đã lưu buổi ${className(form.classId)} · ${DAYS[form.day]} ${form.start}–${form.end} · ${form.room}. Không phát hiện xung đột.`)
    onClose()
  }

  return (
    <Modal title={initial.id ? 'Sửa buổi học' : 'Xếp buổi học mới'} description="Lịch được quét xung đột phòng và giáo viên ngay khi bạn chọn." onClose={onClose}>
      <form className="hm-form" onSubmit={submit}>
        <Field label="Lớp học">{id => <select id={id} value={form.classId} onChange={set('classId')}>{classes.map(item => <option key={item.id} value={item.id}>{item.name} · {item.branch}</option>)}</select>}</Field>
        <Field label="Thứ">{id => <select id={id} value={form.day} onChange={set('day')}>{DAYS.map((day, index) => <option key={day} value={index}>{day}</option>)}</select>}</Field>
        <Field label="Bắt đầu">{id => <input id={id} type="time" required value={form.start} onChange={set('start')} />}</Field>
        <Field label="Kết thúc" error={!validTime && 'Giờ kết thúc phải sau giờ bắt đầu.'}>{id => <input id={id} type="time" required value={form.end} onChange={set('end')} />}</Field>
        <Field label="Phòng học">{id => <select id={id} value={form.room} onChange={set('room')}>{ROOMS.map(room => <option key={room}>{room}</option>)}</select>}</Field>
        <Field label="Giáo viên">{id => <select id={id} value={form.teacher} onChange={set('teacher')}>{teachers.map(name => <option key={name}>{name}</option>)}</select>}</Field>

        <div className={`hm-scan ${conflicts.length ? 'bad' : 'good'}`} role="status">
          <i className={`fa-solid ${conflicts.length ? 'fa-triangle-exclamation' : 'fa-shield-halved'}`} aria-hidden="true"></i>
          <div>
            <strong>{conflicts.length ? `Phát hiện ${conflicts.length} xung đột` : 'Không có xung đột lịch hoặc phòng'}</strong>
            {conflicts.map((conflict, index) => <p key={index}>{conflictText(conflict, className)}</p>)}
            {suggestions.length > 0 && (
              <p className="hm-suggest">
                Phòng trống cùng khung giờ:
                {suggestions.map(room => (
                  <button key={room} type="button" onClick={() => setForm(current => ({ ...current, room }))}>{room}</button>
                ))}
              </p>
            )}
          </div>
        </div>

        <div className="hm-form-actions">
          {initial.id && <button type="button" className="button hm-danger" onClick={() => { removeSession(initial.id); notify('Đã xóa buổi học khỏi thời khóa biểu.'); onClose() }}>Xóa buổi</button>}
          <button type="button" className="button" onClick={onClose}>Hủy</button>
          <button type="submit" className="button primary" disabled={!validTime || conflicts.length > 0}>Lưu lịch</button>
        </div>
      </form>
    </Modal>
  )
}

function Timetable({ sessions, allSessions, classes, onEdit }) {
  const className = id => classes.find(item => item.id === id)?.name || id
  const conflicted = scanConflicts(allSessions)
  const mine = conflicted.filter(item => sessions.includes(item))
  return (
    <>
      <div className={`hm-scan ${mine.length ? 'bad' : 'good'}`} role="status">
        <i className={`fa-solid ${mine.length ? 'fa-triangle-exclamation' : 'fa-shield-halved'}`} aria-hidden="true"></i>
        <div>
          <strong>
            {mine.length
              ? `Đã quét ${sessions.length} buổi: ${mine.length} buổi đang xung đột`
              : `Đã quét ${sessions.length} buổi: không có xung đột phòng hoặc giáo viên`}
          </strong>
          {mine.map(item => (
            <p key={item.id}>
              {className(item.classId)} · {DAYS[item.day]} {item.start}–{item.end}: {conflictText(findConflicts(item, allSessions)[0], className)}
              <button type="button" className="hm-link" onClick={() => onEdit(item)}>Xử lý<i className="fa-solid fa-arrow-right" aria-hidden="true"></i></button>
            </p>
          ))}
        </div>
      </div>
      <div className="hm-week">
        {DAYS.map((day, index) => {
          const items = sessions.filter(item => item.day === index).sort((a, b) => a.start.localeCompare(b.start))
          return (
            <section key={day} className="hm-day" aria-label={day}>
              <h3>{day}<span className="hm-count">{items.length}</span></h3>
              {items.map(item => {
                const bad = conflicted.includes(item)
                return (
                  <button key={item.id} type="button" className={`hm-slot${bad ? ' bad' : ''}`} onClick={() => onEdit(item)}>
                    <span className="hm-slot-time">{item.start}–{item.end}{bad && <i className="fa-solid fa-triangle-exclamation" aria-label="Xung đột"></i>}</span>
                    <strong>{className(item.classId)}</strong>
                    <small><i className="fa-solid fa-door-open" aria-hidden="true"></i>{item.room}</small>
                    <small><i className="fa-solid fa-chalkboard-user" aria-hidden="true"></i>{item.teacher}</small>
                  </button>
                )
              })}
              {!items.length && <p className="hm-day-empty">Trống</p>}
            </section>
          )
        })}
      </div>
    </>
  )
}

export function LessonForm({ lesson, className, onClose, notify }) {
  const [students, setStudents] = useState(lesson.students)
  const set = (index, key) => event => setStudents(current => current.map((item, position) => position === index ? { ...item, [key]: event.target.value } : item))
  const missing = students.filter(item => item.status !== 'absent' && !item.comment.trim()).length
  const save = done => {
    saveLesson(lesson.id, students, done)
    notify(done ? `Đã gửi điểm danh và nhận xét buổi ${lesson.id} cho phụ huynh.` : 'Đã lưu nháp điểm danh và điểm.')
    onClose()
  }
  return (
    <Modal wide title={`Điểm danh & nhận xét · ${className(lesson.classId)}`} description={`${lesson.topic} · GV ${lesson.teacher} · Hạn gửi phụ huynh: 24 giờ sau buổi học`} onClose={onClose}>
      <div className="table-wrap">
        <table className="hm-roster">
          <thead>
            <tr><th>HỌC SINH</th><th>ĐIỂM DANH</th><th>ĐIỂM BTVN</th><th>NHẬN XÉT GỬI PHỤ HUYNH</th></tr>
          </thead>
          <tbody>
            {students.map((item, index) => (
              <tr key={item.name}>
                <td><strong>{item.name}</strong></td>
                <td>
                  <select aria-label={`Điểm danh ${item.name}`} value={item.status} onChange={set(index, 'status')} disabled={lesson.done}>
                    <option value="present">Có mặt</option>
                    <option value="late">Đi muộn</option>
                    <option value="absent">Vắng</option>
                  </select>
                </td>
                <td><input aria-label={`Điểm ${item.name}`} type="number" min="0" max="10" step="0.5" value={item.score} onChange={set(index, 'score')} disabled={lesson.done || item.status === 'absent'} placeholder="0–10" /></td>
                <td><input aria-label={`Nhận xét ${item.name}`} value={item.comment} onChange={set(index, 'comment')} disabled={lesson.done || item.status === 'absent'} placeholder={item.status === 'absent' ? 'Vắng: hệ thống tự báo phụ huynh' : 'Nhận xét ngắn về buổi học'} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {!lesson.done && (
        <div className="hm-form-actions">
          <span className="hm-form-note">{missing ? `Còn ${missing} học sinh chưa có nhận xét.` : 'Đủ nhận xét, có thể gửi phụ huynh.'}</span>
          <button type="button" className="button" onClick={() => save(false)}>Lưu nháp</button>
          <button type="button" className="button primary" disabled={missing > 0} onClick={() => save(true)}><i className="fa-solid fa-paper-plane" aria-hidden="true"></i>Gửi phụ huynh</button>
        </div>
      )}
    </Modal>
  )
}

export function SlaBoard({ lessons, className, onOpen }) {
  if (!lessons.length) return <Empty>Chưa có buổi học nào cần nhận xét.</Empty>
  return (
    <ul className="hm-sla-list">
      {lessons.map(lesson => {
        const sla = lessonSla(lesson)
        const marked = lesson.students.filter(item => item.comment.trim() || item.status === 'absent').length
        return (
          <li key={lesson.id} className={`hm-sla hm-sla-${sla.state}`}>
            <span className={`hm-activity-icon hm-${slaTone[sla.state]}`}><i className={`fa-solid ${slaIcon[sla.state]}`} aria-hidden="true"></i></span>
            <div>
              <strong>{className(lesson.classId)} · {lesson.topic}</strong>
              <small>{lesson.id} · GV {lesson.teacher} · kết thúc {lesson.endedHoursAgo} giờ trước</small>
            </div>
            <div className="hm-cell-progress">
              <Progress value={percent(marked, lesson.students.length)} tone={sla.state === 'late' ? 'red' : 'green'} label={`Tiến độ nhận xét ${lesson.id}`} />
              <span>{marked}/{lesson.students.length}</span>
            </div>
            <Badge tone={slaTone[sla.state]} icon={slaIcon[sla.state]}>{sla.label}</Badge>
            <button type="button" className="button small" onClick={() => onOpen(lesson)}>{lesson.done ? 'Xem' : 'Nhập điểm & nhận xét'}</button>
          </li>
        )
      })}
    </ul>
  )
}

const PROPOSAL_STATUS = { pending: ['Chờ duyệt', 'amber'], approved: ['Đã duyệt', 'green'], rejected: ['Từ chối', 'red'] }

// Quản lý duyệt đề xuất dạy bù/dạy thay: chọn phòng trống, lịch tự thêm vào thời khóa biểu, giáo viên và phụ huynh được báo.
function ProposalRow({ proposal, className, sessions, notify }) {
  const candidate = { ...proposal, id: undefined }
  const rooms = freeRooms(candidate, sessions)
  const [room, setRoom] = useState(rooms.includes(proposal.room) ? proposal.room : rooms[0] || proposal.room)
  const decide = approve => {
    const result = decideProposal(proposal.id, approve, room)
    if (result.ok) notify(approve ? `Đã duyệt ${proposal.id}: thêm buổi vào thời khóa biểu, báo giáo viên và phụ huynh.` : `Đã từ chối đề xuất ${proposal.id}.`)
    else if (result.conflicts) notify(`Không duyệt được: ${room} hoặc giáo viên đang trùng lịch. Hãy chọn phòng khác.`)
  }
  return (
    <li className="hm-ticket">
      <div className="hm-ticket-head"><strong>{proposal.id}</strong><Badge tone="slate">{proposal.type}</Badge><Badge tone={PROPOSAL_STATUS[proposal.status][1]}>{PROPOSAL_STATUS[proposal.status][0]}</Badge></div>
      <p>GV {proposal.teacher} · {className(proposal.classId)} · {DAYS[proposal.day]} {proposal.start}–{proposal.end} · {proposal.branch}</p>
      <div className="hm-ticket-foot">
        <span><i className="fa-solid fa-quote-left" aria-hidden="true"></i>{proposal.reason}</span>
        {proposal.status === 'pending' ? (
          <>
            <label className="hm-inline-select">
              <span className="hm-sr">Phòng cho đề xuất {proposal.id}</span>
              <select value={room} onChange={event => setRoom(event.target.value)}>
                {ROOMS.map(item => <option key={item} value={item} disabled={!rooms.includes(item)}>{item}{rooms.includes(item) ? '' : ' (bận)'}</option>)}
              </select>
            </label>
            <button type="button" className="button small" onClick={() => decide(false)}>Từ chối</button>
            <button type="button" className="button small primary" onClick={() => decide(true)}>Duyệt</button>
          </>
        ) : <span>Phòng {proposal.room}{proposal.decidedBy ? ` · ${proposal.decidedBy} xử lý` : ''}</span>}
      </div>
    </li>
  )
}

function ProposalInbox({ proposals, className, sessions, notify }) {
  if (!proposals.length) return <Empty icon="fa-calendar-plus">Chưa có đề xuất dạy bù hoặc dạy thay nào.</Empty>
  return <ul className="hm-ticket-list">{proposals.map(item => <ProposalRow key={item.id} proposal={item} className={className} sessions={sessions} notify={notify} />)}</ul>
}

export default function EducationModule({ role, notify }) {
  const store = useStore()
  const [tab, setTab] = useState('timetable')
  const [branch, setBranch] = useState('all')
  const [editing, setEditing] = useState(null)
  const [lesson, setLesson] = useState(null)
  const [dialog, setDialog] = useState('')
  const scope = role === 'admin' ? branch : myBranch()

  const classes = store.classes.filter(item => scope === 'all' || item.branch === scope)
  const sessions = store.sessions.filter(item => scope === 'all' || item.branch === scope)
  const className = id => store.classes.find(item => item.id === id)?.name || id
  const lessons = store.lessons.filter(item => classes.some(entry => entry.id === item.classId))
  const conflicts = scanConflicts(store.sessions).filter(item => sessions.includes(item))
  const slaStates = lessons.map(item => lessonSla(item).state)
  const late = slaStates.filter(state => state === 'late').length
  const onTime = percent(slaStates.filter(state => state !== 'late').length, slaStates.length)
  const seats = classes.reduce((sum, item) => sum + item.capacity, 0)
  const firstClass = classes[0] || store.classes[0]
  const proposals = store.proposals.filter(item => scope === 'all' || item.branch === scope)
  const waiting = proposals.filter(item => item.status === 'pending').length

  return (
    <>
      <PageHead title="Học vụ & Đào tạo" description="Lớp học, thời khóa biểu tự quét xung đột và kiểm soát hạn nhận xét 24 giờ sau buổi học.">
        <button type="button" className="button" onClick={() => setDialog('student')}><i className="fa-solid fa-user-plus" aria-hidden="true"></i>Thêm học viên</button>
        <button type="button" className="button" onClick={() => setDialog('class')}><i className="fa-solid fa-chalkboard" aria-hidden="true"></i>Tạo lớp</button>
        <button type="button" className="button primary" onClick={() => setEditing({ classId: firstClass.id, day: 0, start: '18:00', end: '19:30', room: ROOMS[0], teacher: firstClass.teacher, branch: firstClass.branch })}>
          <i className="fa-solid fa-calendar-plus" aria-hidden="true"></i>Xếp buổi học
        </button>
      </PageHead>

      <div className="kpi-grid">
        <Kpi label="Lớp đang mở" value={classes.length} icon="fa-chalkboard" note={`${new Set(classes.map(item => item.teacher)).size} giáo viên giảng dạy`} />
        <Kpi label="Tỷ lệ lấp đầy" value={percent(classes.reduce((sum, item) => sum + item.size, 0), seats)} unit="%" icon="fa-users" note={`${seats} chỗ trên toàn bộ lớp`} />
        <Kpi label="Xung đột lịch / phòng" value={conflicts.length} icon="fa-triangle-exclamation" tone={conflicts.length ? 'bad' : 'good'} note={conflicts.length ? 'Cần xử lý trước khi công bố lịch' : `${sessions.length} buổi/tuần đã quét sạch`} />
        <Kpi label="Nhận xét đúng hạn 24h" value={onTime} unit="%" icon="fa-stopwatch" tone={late ? 'warn' : 'good'} note={late ? `${late} buổi đã quá hạn SLA` : 'Không có buổi nào quá hạn'} />
      </div>

      <article className="card hm-panel">
        <div className="hm-toolbar">
          <Tabs label="Phân hệ học vụ" value={tab} onChange={setTab} tabs={[
            ['timetable', 'Thời khóa biểu', conflicts.length || undefined],
            ['sla', 'Điểm danh & SLA 24h', lessons.filter(item => !item.done).length],
            ['classes', 'Lớp học', classes.length],
            ['proposals', 'Đề xuất dạy bù', waiting || undefined],
          ]} />
          <div className="hm-filters">
            {role !== 'admin'
              ? <BranchFilter role={role} />
              : (
                <label className="hm-select">
                  <span className="hm-sr">Cơ sở</span>
                  <i className="fa-solid fa-location-dot" aria-hidden="true"></i>
                  <select value={branch} onChange={event => setBranch(event.target.value)}>
                    <option value="all">Tất cả 5 cơ sở</option>
                    {BRANCHES.map(item => <option key={item}>{item}</option>)}
                  </select>
                </label>
              )}
          </div>
        </div>
        {tab === 'timetable' && <Timetable sessions={sessions} allSessions={store.sessions} classes={store.classes} onEdit={setEditing} />}
        {tab === 'sla' && <SlaBoard lessons={lessons} className={className} onOpen={setLesson} />}
        {tab === 'classes' && <ClassTable classes={classes} />}
        {tab === 'proposals' && <ProposalInbox proposals={proposals} className={className} sessions={store.sessions} notify={notify} />}
      </article>

      {editing && <SessionForm initial={editing} classes={store.classes} sessions={store.sessions} notify={notify} onClose={() => setEditing(null)} />}
      {lesson && <LessonForm lesson={lesson} className={className} notify={notify} onClose={() => setLesson(null)} />}
      {dialog === 'student' && <StudentForm role={role} onClose={() => setDialog('')} />}
      {dialog === 'class' && <ClassForm role={role} onClose={() => setDialog('')} />}
    </>
  )
}
