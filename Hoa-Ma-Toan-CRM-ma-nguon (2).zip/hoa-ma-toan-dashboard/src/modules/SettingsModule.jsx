import { useState } from 'react'
import {
  BANKS, BRANCHES, DEMO_MODE, ROLE_LABELS, STAFF_ROLES,
  createAccount, deleteAccount, patchAccountByAdmin, resetAccountPassword, resetStore, saveSettings, useStore,
} from './store'
import { formatDate, formatTime } from './format'
import { Avatar, Badge, Empty, Field, Modal, PageHead, Pager, Select, Switch, Tabs, toast, usePager } from './ui'

const TOGGLES = [
  ['feeReminder', 'Tự động nhắc học phí', 'Gửi thông báo cho phụ huynh trước hạn 3 ngày.'],
  ['lessonComment', 'Báo nhận xét sau buổi học', 'Phụ huynh nhận thông báo khi giáo viên gửi nhận xét.'],
  ['weeklyReport', 'Báo cáo tuần cho Ban giám đốc', 'Tổng hợp tuyển sinh, học vụ, tài chính mỗi sáng Thứ 2.'],
  ['chatbot', 'Chatbot trực 24/7', 'Trả lời phụ huynh và tự tạo yêu cầu hỗ trợ.'],
]
const STATUS = { active: ['Hoạt động', 'green'], locked: ['Đã khóa', 'red'], pending: ['Chờ liên kết', 'amber'] }

function TempPassword({ result, onClose }) {
  return (
    <Modal title="Mật khẩu tạm" description="Mật khẩu chỉ hiện một lần. Người dùng buộc phải đổi ở lần đăng nhập đầu tiên." onClose={onClose}>
      <dl className="hm-facts">
        <div><dt>Tên đăng nhập</dt><dd>{result.username}</dd></div>
        <div><dt>Mật khẩu tạm</dt><dd><code>{result.temp}</code></dd></div>
      </dl>
      <div className="hm-form-actions">
        <button type="button" className="button" onClick={() => navigator.clipboard?.writeText(`${result.username} / ${result.temp}`).then(() => toast('Đã sao chép tài khoản và mật khẩu tạm.'))}><i className="fa-solid fa-copy" aria-hidden="true"></i>Sao chép</button>
        <button type="button" className="button primary" onClick={onClose}>Đã lưu lại</button>
      </div>
    </Modal>
  )
}

function AccountForm({ onClose, onCreated }) {
  const [form, setForm] = useState({ name: '', email: '', phone: '', role: 'teacher', branch: BRANCHES[0] })
  const [error, setError] = useState('')
  const set = key => event => setForm(current => ({ ...current, [key]: event.target.value }))
  const submit = async event => {
    event.preventDefault()
    const result = await createAccount(form)
    if (!result.ok) return setError(result.message)
    return onCreated(result)
  }
  return (
    <Modal title="Tạo tài khoản nhân sự" description="Chỉ Ban giám đốc cấp được tài khoản quản lý, giáo viên và nhân viên." onClose={onClose}>
      <form className="hm-form" onSubmit={submit}>
        <Field label="Họ tên">{id => <input id={id} required value={form.name} onChange={set('name')} />}</Field>
        <Field label="Email" error={error}>{id => <input id={id} type="email" required value={form.email} onChange={set('email')} placeholder="ten@hoamatoan.vn" />}</Field>
        <Field label="Số điện thoại">{id => <input id={id} inputMode="tel" value={form.phone} onChange={set('phone')} />}</Field>
        <Field label="Vai trò">{id => <select id={id} value={form.role} onChange={set('role')}>{STAFF_ROLES.map(role => <option key={role} value={role}>{ROLE_LABELS[role]}</option>)}</select>}</Field>
        {form.role !== 'admin' && (
          <Field label="Cơ sở phụ trách">{id => <select id={id} value={form.branch} onChange={set('branch')}>{BRANCHES.map(item => <option key={item}>{item}</option>)}</select>}</Field>
        )}
        <div className="hm-form-actions">
          <button type="button" className="button" onClick={onClose}>Hủy</button>
          <button type="submit" className="button primary">Tạo và cấp mật khẩu tạm</button>
        </div>
      </form>
    </Modal>
  )
}

function Accounts({ accounts, me }) {
  const [query, setQuery] = useState('')
  const [role, setRole] = useState('all')
  const [dialog, setDialog] = useState(null)
  const text = query.trim().toLowerCase()
  const rows = accounts.filter(item => (role === 'all' || item.role === role) && (!text || `${item.name} ${item.username} ${item.email}`.toLowerCase().includes(text)))
  const pager = usePager(rows, 7)
  const reset = async username => {
    const result = await resetAccountPassword(username)
    if (result.ok) setDialog({ type: 'temp', username, temp: result.temp })
  }
  return (
    <>
      <div className="hm-toolbar">
        <div className="hm-filters">
          <label className="hm-search">
            <span className="hm-sr">Tìm tài khoản</span>
            <i className="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
            <input type="search" value={query} onChange={event => setQuery(event.target.value)} placeholder="Tìm tên, email" />
          </label>
          <Select label="Vai trò" icon="fa-user-tag" value={role} onChange={setRole} options={[['all', 'Mọi vai trò'], ...Object.entries(ROLE_LABELS)]} />
        </div>
        <button type="button" className="button primary small" onClick={() => setDialog({ type: 'create' })}><i className="fa-solid fa-user-plus" aria-hidden="true"></i>Tạo tài khoản</button>
      </div>
      {!rows.length && <Empty>Không có tài khoản nào khớp bộ lọc.</Empty>}
      <div className="table-wrap">
        <table>
          <thead><tr><th>TÀI KHOẢN</th><th>VAI TRÒ</th><th>CƠ SỞ</th><th>TRẠNG THÁI</th><th>ĐĂNG NHẬP CUỐI</th><th></th></tr></thead>
          <tbody>
            {pager.rows.map(item => {
              const [label, tone] = STATUS[item.status]
              const self = item.username === me
              return (
                <tr key={item.username}>
                  <td><span className="hm-person"><Avatar name={item.name} /><span><strong>{item.name}</strong><small>{item.username} · {item.email}</small></span></span></td>
                  <td>
                    <label className="hm-inline-select">
                      <span className="hm-sr">Vai trò của {item.name}</span>
                      <select value={item.role} disabled={self || item.role === 'parent'} onChange={event => { if (patchAccountByAdmin(item.username, { role: event.target.value }, 'Đổi vai trò')) toast(`Đã đổi vai trò của ${item.name}.`) }}>
                        {(item.role === 'parent' ? ['parent'] : STAFF_ROLES).map(key => <option key={key} value={key}>{ROLE_LABELS[key]}</option>)}
                      </select>
                    </label>
                  </td>
                  <td>{item.branch || 'Toàn hệ thống'}</td>
                  <td><Badge tone={tone}>{label}</Badge>{item.mustChange && <Badge tone="blue">Chưa đổi mật khẩu tạm</Badge>}</td>
                  <td>{item.lastLogin ? `${formatDate(item.lastLogin)} ${formatTime(item.lastLogin)}` : 'Chưa đăng nhập'}</td>
                  <td className="hm-row-actions">
                    {item.status === 'pending' && <button type="button" className="button small primary" onClick={() => { if (patchAccountByAdmin(item.username, { status: 'active' }, 'Kích hoạt')) toast(`Đã kích hoạt tài khoản ${item.username}.`) }}>Kích hoạt</button>}
                    <button type="button" className="button small" onClick={() => reset(item.username)}>Đặt lại mật khẩu</button>
                    {!self && item.status !== 'pending' && (
                      <button type="button" className="button small" onClick={() => { if (patchAccountByAdmin(item.username, { status: item.status === 'locked' ? 'active' : 'locked' }, item.status === 'locked' ? 'Mở khóa' : 'Khóa')) toast(`${item.status === 'locked' ? 'Đã mở khóa' : 'Đã khóa'} tài khoản ${item.username}.`) }}>
                        {item.status === 'locked' ? 'Mở khóa' : 'Khóa'}
                      </button>
                    )}
                    {!self && (
                      <button type="button" className="hm-icon-btn" aria-label={`Xóa tài khoản ${item.username}`} onClick={() => { if (window.confirm(`Xóa tài khoản ${item.username}? Thao tác không hoàn tác được.`) && deleteAccount(item.username)) toast(`Đã xóa tài khoản ${item.username}.`) }}>
                        <i className="fa-solid fa-trash-can" aria-hidden="true"></i>
                      </button>
                    )}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
      <Pager pager={pager} />
      {dialog?.type === 'create' && <AccountForm onClose={() => setDialog(null)} onCreated={result => setDialog({ type: 'temp', ...result })} />}
      {dialog?.type === 'temp' && <TempPassword result={dialog} onClose={() => setDialog(null)} />}
    </>
  )
}

function General({ settings, isAdmin }) {
  const [center, setCenter] = useState(settings.center)
  const [bank, setBank] = useState(settings.bank)
  const edit = (setter, key) => event => setter(current => ({ ...current, [key]: event.target.value }))
  const validBank = /^\d{6,19}$/.test(bank.accountNo) && bank.accountName.trim().length > 2
  return (
    <div className="grid-3 hm-flush hm-settings">
      <form className="hm-setting-card" onSubmit={event => { event.preventDefault(); if (saveSettings('center', center)) toast('Đã lưu thông tin trung tâm.') }}>
        <h3 className="hm-subtitle"><i className="fa-solid fa-school" aria-hidden="true"></i>Thông tin trung tâm</h3>
        <Field label="Tên trung tâm">{id => <input id={id} required disabled={!isAdmin} value={center.name} onChange={edit(setCenter, 'name')} />}</Field>
        <Field label="Hotline">{id => <input id={id} required disabled={!isAdmin} value={center.hotline} onChange={edit(setCenter, 'hotline')} />}</Field>
        <Field label="Email liên hệ">{id => <input id={id} type="email" required disabled={!isAdmin} value={center.email} onChange={edit(setCenter, 'email')} />}</Field>
        <Field label="Năm học hiện tại">{id => <input id={id} required disabled={!isAdmin} value={center.year} onChange={edit(setCenter, 'year')} />}</Field>
        {isAdmin && <button type="submit" className="button primary small">Lưu thông tin</button>}
      </form>

      <form className="hm-setting-card" onSubmit={event => { event.preventDefault(); if (validBank && saveSettings('bank', bank)) toast('Đã lưu tài khoản nhận học phí. Mã VietQR mới dùng thông tin này.') }}>
        <h3 className="hm-subtitle"><i className="fa-solid fa-building-columns" aria-hidden="true"></i>Tài khoản nhận học phí (VietQR)</h3>
        <Field label="Ngân hàng">{id => <select id={id} disabled={!isAdmin} value={bank.bankId} onChange={edit(setBank, 'bankId')}>{Object.keys(BANKS).map(item => <option key={item}>{item}</option>)}</select>}</Field>
        <Field label="Số tài khoản" error={!validBank && isAdmin && 'Số tài khoản gồm 6–19 chữ số và phải có tên chủ tài khoản.'}>{id => <input id={id} inputMode="numeric" required disabled={!isAdmin} value={bank.accountNo} onChange={edit(setBank, 'accountNo')} />}</Field>
        <Field label="Tên chủ tài khoản (không dấu)">{id => <input id={id} required disabled={!isAdmin} value={bank.accountName} onChange={edit(setBank, 'accountName')} />}</Field>
        {isAdmin ? <button type="submit" className="button primary small" disabled={!validBank}>Lưu tài khoản nhận</button> : <p className="hm-form-note">Chỉ Ban giám đốc sửa được tài khoản nhận.</p>}
      </form>

      <div className="hm-setting-card">
        <h3 className="hm-subtitle"><i className="fa-solid fa-bell" aria-hidden="true"></i>Thông báo tự động</h3>
        <ul className="hm-switch-list">
          {TOGGLES.map(([key, title, text]) => (
            <li key={key}>
              <div><strong>{title}</strong><small>{text}</small></div>
              <Switch label={title} checked={settings.toggles[key]} onChange={value => { if (saveSettings('toggles', { ...settings.toggles, [key]: value })) toast(`${title}: ${value ? 'đã bật' : 'đã tắt'}.`) }} />
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}

export default function SettingsModule({ role, me }) {
  const store = useStore()
  const [tab, setTab] = useState('general')
  const isAdmin = role === 'admin'
  const logs = usePager(store.auditLog, 10)
  return (
    <>
      <PageHead title="Cài đặt hệ thống" description={isAdmin ? 'Thông tin trung tâm, tài khoản nhận học phí, tài khoản người dùng và nhật ký thao tác.' : 'Thông tin trung tâm và thông báo tự động. Quản trị tài khoản thuộc quyền Ban giám đốc.'}>
        {isAdmin && DEMO_MODE && (
          <button type="button" className="button" onClick={() => { if (window.confirm('Khôi phục toàn bộ dữ liệu demo về ban đầu? Tài khoản người dùng được giữ lại.') && resetStore()) toast('Đã khôi phục dữ liệu demo.') }}>
            <i className="fa-solid fa-rotate-left" aria-hidden="true"></i>Khôi phục dữ liệu demo
          </button>
        )}
      </PageHead>
      <article className="card hm-panel">
        <div className="hm-toolbar">
          <Tabs label="Cài đặt" value={tab} onChange={setTab} tabs={isAdmin
            ? [['general', 'Chung'], ['accounts', 'Tài khoản & phân quyền', store.accounts.length], ['audit', 'Nhật ký thao tác', store.auditLog.length]]
            : [['general', 'Chung']]} />
        </div>
        {tab === 'general' && <General key={JSON.stringify(store.settings.bank) + store.settings.center.name} settings={store.settings} isAdmin={isAdmin} />}
        {tab === 'accounts' && isAdmin && <Accounts accounts={store.accounts} me={me} />}
        {tab === 'audit' && isAdmin && (
          <>
            {!store.auditLog.length && <Empty icon="fa-clipboard-list">Chưa có thao tác nào được ghi lại.</Empty>}
            <ul className="hm-audit">
              {logs.rows.map((item, index) => (
                <li key={index}><time>{formatDate(item.at)} {formatTime(item.at)}</time><strong>{item.who}</strong><Badge tone="slate">{ROLE_LABELS[item.role] || 'Hệ thống'}</Badge><span>{item.action}</span></li>
              ))}
            </ul>
            <Pager pager={logs} />
          </>
        )}
      </article>
    </>
  )
}
