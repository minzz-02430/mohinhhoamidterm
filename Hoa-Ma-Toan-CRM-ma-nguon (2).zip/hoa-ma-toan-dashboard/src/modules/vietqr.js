// Sinh nội dung mã VietQR (chuẩn EMVCo/NAPAS 247) ngay trên máy, không phụ thuộc mạng.
const field = (id, value) => `${id}${String(value.length).padStart(2, '0')}${value}`

export function crc16(text) {
  let crc = 0xffff
  for (const char of text) {
    crc ^= char.charCodeAt(0) << 8
    for (let bit = 0; bit < 8; bit += 1) crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff
  }
  return crc.toString(16).toUpperCase().padStart(4, '0')
}

// Nội dung chuyển khoản: bỏ dấu và ký tự đặc biệt, tối đa 50 ký tự.
export const cleanInfo = text => text.normalize('NFD').replace(/\p{Diacritic}/gu, '').replace(/đ/g, 'd').replace(/Đ/g, 'D')
  .replace(/[^a-zA-Z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 50)

export function buildVietQrPayload({ bin, accountNo, amount, addInfo }) {
  const value = Math.round(Number(amount))
  if (!/^\d{6}$/.test(bin) || !/^\d{6,19}$/.test(accountNo) || !(value > 0)) throw new Error('Thông tin tài khoản nhận hoặc số tiền không hợp lệ.')
  const merchant = field('00', 'A000000727') + field('01', field('00', bin) + field('01', accountNo)) + field('02', 'QRIBFTTA')
  const body = field('00', '01') + field('01', '12') + field('38', merchant) + field('53', '704') + field('54', String(value))
    + field('58', 'VN') + field('62', field('08', cleanInfo(addInfo))) + '6304'
  return body + crc16(body)
}

// Quick Link của VietQR (cần internet). bankId là mã BIN; nội dung tối đa 50 ký tự không dấu.
export function buildVietQrUrl({ bankId, accountNo, amount, addInfo, accountName, template = 'compact2' }) {
  const value = Math.round(Number(amount))
  if (!/^\d{6}$/.test(bankId) || !/^\d{6,19}$/.test(accountNo) || !(value > 0)) throw new Error('Thông tin tài khoản nhận hoặc số tiền không hợp lệ.')
  const query = new URLSearchParams({ amount: String(value), addInfo: cleanInfo(addInfo), accountName: cleanInfo(accountName) })
  return `https://img.vietqr.io/image/${bankId}-${accountNo}-${template}.png?${query}`
}
