import { useEffect, useId, useRef, useState } from 'react'
import { BRANCHES, myBranch } from './store'
import { initials } from './format'

export { money, percent, initials } from './format'

// Ban giám đốc xem được cả 5 cơ sở; các vai trò còn lại chỉ thấy cơ sở gắn trên tài khoản.
export const branchScope = role => (role === 'admin' ? 'all' : myBranch())
export const inScope = (item, branch) => branch === 'all' || item.branch === branch

// ---- Kênh phát toast và điều hướng dùng chung (không cần truyền prop qua nhiều tầng) ----
const toastListeners = new Set()
export const toast = (message, action) => toastListeners.forEach(listener => listener({ id: Math.random(), message, action }))
const navListeners = new Set()
export const navigate = tab => navListeners.forEach(listener => listener(tab))
export function useNavigation(handler) {
  useEffect(() => {
    navListeners.add(handler)
    return () => navListeners.delete(handler)
  }, [handler])
}

export function Toasts() {
  const [items, setItems] = useState([])
  useEffect(() => {
    const listener = item => {
      setItems(current => [...current.slice(-2), item])
      window.setTimeout(() => setItems(current => current.filter(entry => entry.id !== item.id)), 3600)
    }
    toastListeners.add(listener)
    return () => toastListeners.delete(listener)
  }, [])
  return (
    <div className="hm-toasts" role="status" aria-live="polite">
      {items.map(item => (
        <div key={item.id} className="hm-toast">
          <span>{item.message}</span>
          {item.action && (
            <button type="button" onClick={() => { item.action.run(); setItems(current => current.filter(entry => entry.id !== item.id)) }}>{item.action.label}</button>
          )}
          <i className="hm-toast-bar" aria-hidden="true"></i>
        </div>
      ))}
    </div>
  )
}

const reducedMotion = () => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches

// Số chạy lên 800ms (easeOutCubic); tắt khi người dùng yêu cầu giảm chuyển động.
export function CountUp({ value, format = number => Math.round(number).toLocaleString('vi-VN') }) {
  const [shown, setShown] = useState(reducedMotion() ? value : 0)
  const from = useRef(0)
  useEffect(() => {
    if (reducedMotion()) return undefined
    const start = performance.now()
    const origin = from.current
    let frame = requestAnimationFrame(function tick(now) {
      const progress = Math.min(1, (now - start) / 800)
      const current = origin + (value - origin) * (1 - (1 - progress) ** 3)
      from.current = current
      setShown(current)
      if (progress < 1) frame = requestAnimationFrame(tick)
    })
    return () => cancelAnimationFrame(frame)
  }, [value])
  return format(reducedMotion() ? value : shown)
}

export function PageHead({ title, description, children }) {
  return (
    <div className="page-heading">
      <div>
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
      <div className="hm-head-actions">{children}</div>
    </div>
  )
}

export function Kpi({ label, value, unit, note, icon, tone = 'good', format }) {
  return (
    <article className="card kpi hm-kpi">
      <span className="kpi-icon"><i className={`fa-solid ${icon}`} aria-hidden="true"></i></span>
      <div className="kpi-label">{label}</div>
      <div className="kpi-value">
        {typeof value === 'number' ? <CountUp value={value} format={format} /> : value}
        {unit && <> <small>{unit}</small></>}
      </div>
      <div className={`kpi-note${tone === 'warn' ? ' warn' : ''}${tone === 'bad' ? ' hm-bad' : ''}`}>{note}</div>
    </article>
  )
}

export function Tabs({ tabs, value, onChange, label }) {
  return (
    <div className="hm-tabs" role="tablist" aria-label={label}>
      {tabs.map(([id, text, count]) => (
        <button key={id} type="button" role="tab" aria-selected={value === id} className={value === id ? 'active' : ''} onClick={() => onChange(id)}>
          {text}
          {count !== undefined && <span className="hm-count">{count}</span>}
        </button>
      ))}
    </div>
  )
}

export function Badge({ tone = 'slate', icon, children }) {
  return (
    <span className={`hm-badge hm-${tone}`}>
      {icon && <i className={`fa-solid ${icon}`} aria-hidden="true"></i>}
      {children}
    </span>
  )
}

export function Avatar({ name }) {
  return <span className="hm-avatar" aria-hidden="true">{initials(name)}</span>
}

export function Progress({ value, tone = 'orange', label }) {
  return (
    <div className="hm-progress" role="progressbar" aria-valuenow={value} aria-valuemin={0} aria-valuemax={100} aria-label={label}>
      <span className={`hm-fill hm-fill-${tone}`} style={{ transform: `scaleX(${Math.min(100, value) / 100})` }}></span>
    </div>
  )
}

export function BranchFilter({ role, value, onChange }) {
  if (role !== 'admin') {
    return <span className="hm-scope"><i className="fa-solid fa-location-dot" aria-hidden="true"></i>Cơ sở {myBranch()}</span>
  }
  return (
    <label className="hm-select">
      <span className="hm-sr">Cơ sở</span>
      <i className="fa-solid fa-location-dot" aria-hidden="true"></i>
      <select value={value} onChange={event => onChange(event.target.value)}>
        <option value="all">Tất cả 5 cơ sở</option>
        {BRANCHES.map(branch => <option key={branch} value={branch}>{branch}</option>)}
      </select>
    </label>
  )
}

export function Select({ label, value, onChange, options, icon }) {
  return (
    <label className="hm-select">
      <span className="hm-sr">{label}</span>
      {icon && <i className={`fa-solid ${icon}`} aria-hidden="true"></i>}
      <select value={value} onChange={event => onChange(event.target.value)}>
        {options.map(option => {
          const [id, text] = Array.isArray(option) ? option : [option, option]
          return <option key={id} value={id}>{text}</option>
        })}
      </select>
    </label>
  )
}

export function Field({ label, children, hint, error }) {
  const id = useId()
  return (
    <div className="hm-field">
      <label htmlFor={id}>{label}</label>
      {typeof children === 'function' ? children(id) : children}
      {error ? <small className="hm-error" role="alert">{error}</small> : hint && <small>{hint}</small>}
    </div>
  )
}

export function Modal({ title, description, onClose, children, footer, wide }) {
  const ref = useRef(null)
  const titleId = useId()
  useEffect(() => {
    const dialog = ref.current
    if (dialog && !dialog.open) dialog.showModal()
  }, [])
  return (
    <dialog ref={ref} className={`hm-modal${wide ? ' wide' : ''}`} aria-labelledby={titleId} onClose={onClose} onClick={event => { if (event.target === ref.current) onClose() }}>
      <header>
        <div>
          <h2 id={titleId}>{title}</h2>
          {description && <p>{description}</p>}
        </div>
        <button type="button" className="hm-icon-btn" aria-label="Đóng" onClick={onClose}><i className="fa-solid fa-xmark" aria-hidden="true"></i></button>
      </header>
      <div className="hm-modal-body">{children}</div>
      {footer && <footer>{footer}</footer>}
    </dialog>
  )
}

export function Empty({ icon = 'fa-inbox', children }) {
  return (
    <div className="hm-empty">
      <i className={`fa-solid ${icon}`} aria-hidden="true"></i>
      <p>{children}</p>
    </div>
  )
}

export function Switch({ checked, onChange, label, disabled }) {
  return (
    <button type="button" role="switch" aria-checked={checked} aria-label={label} disabled={disabled} className={`hm-switch${checked ? ' on' : ''}`} onClick={() => onChange(!checked)}>
      <span></span>
    </button>
  )
}

const DONUT_COLORS = ['#ee6a25', '#3b82f6', '#22c55e', '#8b5cf6', '#f59e0b']

// Biểu đồ tròn có tổng ở tâm, vẽ bằng conic-gradient (không cần thư viện, chạy được khi mất mạng).
export function Donut({ data, unit, centerLabel }) {
  const total = data.reduce((sum, item) => sum + item.value, 0)
  let angle = 0
  const stops = data.map((item, index) => {
    const start = angle
    angle += total ? (item.value / total) * 360 : 0
    return `${DONUT_COLORS[index % DONUT_COLORS.length]} ${start}deg ${angle}deg`
  })
  return (
    <div className="hm-donut-wrap">
      <div className="hm-donut" style={{ background: `conic-gradient(${stops.join(', ') || '#f1ece7 0 360deg'})` }} role="img" aria-label={`${centerLabel}: ${total} ${unit}`}>
        <div><strong><CountUp value={total} /></strong><span>{centerLabel}</span></div>
      </div>
      <ul className="hm-legend">
        {data.map((item, index) => (
          <li key={item.label}>
            <i style={{ background: DONUT_COLORS[index % DONUT_COLORS.length] }} aria-hidden="true"></i>
            <span>{item.label}</span>
            <strong>{item.value.toLocaleString('vi-VN')} {unit}</strong>
            <small>{total ? Math.round((item.value / total) * 100) : 0}%</small>
          </li>
        ))}
      </ul>
    </div>
  )
}

// Biểu đồ cột nhóm có nhãn giá trị; cột mọc lên bằng transform để giữ 60fps.
export function BarChart({ data, series, format = value => value }) {
  const max = Math.max(1, ...data.flatMap(item => series.map(([key]) => item[key])))
  return (
    <div className="hm-chart">
      <div className="hm-bars" role="img" aria-label={`Biểu đồ ${series.map(([, name]) => name).join(' và ')}`}>
        {data.map((item, index) => (
          <div key={item.label} className="hm-bar-group">
            <div className="hm-bar-cols">
              {series.map(([key, name, color]) => (
                <div key={key} className="hm-bar-col" title={`${name} ${item.label}: ${format(item[key])}`}>
                  <span className="hm-bar-value">{format(item[key])}</span>
                  <i style={{ height: `${(item[key] / max) * 100}%`, background: color, animationDelay: `${index * 60}ms` }}></i>
                </div>
              ))}
            </div>
            <span className="hm-bar-label">{item.label}</span>
          </div>
        ))}
      </div>
      <ul className="hm-legend inline">
        {series.map(([key, name, color]) => <li key={key}><i style={{ background: color }} aria-hidden="true"></i><span>{name}</span></li>)}
      </ul>
    </div>
  )
}

// Biểu đồ đường một trục, có nhãn tại từng điểm.
export function LineChart({ data, pick, color = '#ee6a25', label }) {
  const values = data.map(pick)
  const min = Math.min(...values)
  const span = Math.max(1, Math.max(...values) - min)
  const point = (value, index) => [20 + (index * 360) / Math.max(1, values.length - 1), 110 - ((value - min) / span) * 80]
  const points = values.map(point)
  return (
    <svg className="hm-line" viewBox="0 0 400 140" role="img" aria-label={label}>
      <polyline points={points.map(([x, y]) => `${x},${y}`).join(' ')} fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" pathLength="1" />
      {points.map(([x, y], index) => (
        <g key={data[index].label}>
          <circle cx={x} cy={y} r="4" fill="#fff" stroke={color} strokeWidth="2" />
          <text x={x} y={y - 10} textAnchor="middle" className="hm-line-value">{values[index].toLocaleString('vi-VN')}</text>
          <text x={x} y="134" textAnchor="middle" className="hm-line-label">{data[index].label}</text>
        </g>
      ))}
    </svg>
  )
}

export function usePager(rows, size = 6) {
  const [page, setPage] = useState(1)
  const pages = Math.max(1, Math.ceil(rows.length / size))
  const current = Math.min(page, pages)
  return { rows: rows.slice((current - 1) * size, current * size), page: current, pages, setPage, total: rows.length, size }
}

export function Pager({ pager }) {
  if (pager.total <= pager.size) return null
  const first = (pager.page - 1) * pager.size + 1
  return (
    <div className="hm-pager">
      <span>{first}–{Math.min(pager.total, first + pager.size - 1)} trong {pager.total}</span>
      <button type="button" className="button small" disabled={pager.page === 1} onClick={() => pager.setPage(pager.page - 1)}>Trước</button>
      <button type="button" className="button small" disabled={pager.page === pager.pages} onClick={() => pager.setPage(pager.page + 1)}>Sau</button>
    </div>
  )
}
