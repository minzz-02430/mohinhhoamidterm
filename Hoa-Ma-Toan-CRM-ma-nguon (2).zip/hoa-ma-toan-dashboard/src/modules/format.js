// Hàm thuần dùng chung: định dạng tiền, ngày, CSV.
export const formatMoney = (value, { compact = false } = {}) => (compact
  ? `${(value / 1e6).toLocaleString('vi-VN', { maximumFractionDigits: 1 })} triệu`
  : `${Math.round(value).toLocaleString('vi-VN')} đ`)
export const money = millions => formatMoney(millions * 1e6, { compact: true })
export const percent = (part, whole) => (whole ? Math.round((part / whole) * 100) : 0)
export const initials = name => name.split(' ').slice(-2).map(word => word[0]).join('').toUpperCase()
export const formatDate = time => new Date(time).toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric' })
export const formatTime = time => new Date(time).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })

export function timeAgo(time, now = Date.now()) {
  const minutes = Math.round((now - time) / 60000)
  if (minutes < 1) return 'Vừa xong'
  if (minutes < 60) return `${minutes} phút trước`
  if (minutes < 60 * 24) return `${Math.floor(minutes / 60)} giờ trước`
  return `${Math.floor(minutes / 1440)} ngày trước`
}

// columns: [[tiêu đề, hàm lấy giá trị]]. Ô có dấu phẩy, nháy kép hoặc xuống dòng được bọc trong nháy kép.
export function toCsv(columns, rows) {
  const cell = value => {
    const text = String(value ?? '')
    return /[",\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text
  }
  return [columns.map(([title]) => cell(title)), ...rows.map(row => columns.map(([, pick]) => cell(pick(row))))]
    .map(line => line.join(',')).join('\r\n')
}

export function exportCsv(screen, columns, rows) {
  // BOM UTF-8 để Excel đọc đúng tiếng Việt.
  const blob = new Blob([String.fromCharCode(0xfeff), toCsv(columns, rows)], { type: 'text/csv;charset=utf-8' })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = `hoa-ma-toan_${screen}_${new Date().toISOString().slice(0, 10)}.csv`
  link.click()
  URL.revokeObjectURL(link.href)
  return rows.length
}

export function parseCsv(text) {
  const rows = [[]]
  let cell = ''
  let quoted = false
  const source = text.replace(/^\uFEFF/, '')
  for (let index = 0; index < source.length; index += 1) {
    const char = source[index]
    if (quoted) {
      if (char === '"' && source[index + 1] === '"') { cell += '"'; index += 1 } else if (char === '"') quoted = false
      else cell += char
    } else if (char === '"') quoted = true
    else if (char === ',' || char === ';') { rows.at(-1).push(cell); cell = '' }
    else if (char === '\n' || char === '\r') {
      if (char === '\r' && source[index + 1] === '\n') index += 1
      rows.at(-1).push(cell); cell = ''; rows.push([])
    } else cell += char
  }
  rows.at(-1).push(cell)
  return rows.filter(row => row.some(value => value.trim()))
}
