import { useEffect, useRef, useState } from 'react'
import { ROLE_LABELS, answerChat } from './store'
import { toast } from './ui'

const GREETING = { sender: 'assistant', text: 'Xin chào! Mình là trợ lý Hòa Ma, trực 24/7. Bạn có thể xin nghỉ, đổi lớp, hỏi học phí hoặc gửi phản ánh; mình sẽ trả lời và tạo yêu cầu cho cơ sở.' }
const SUGGESTIONS = ['Con tôi ốm, xin nghỉ học', 'Học phí được tính thế nào?', 'Tôi muốn đổi ca học']

export default function ChatPanel({ actor }) {
  const [open, setOpen] = useState(false)
  const [messages, setMessages] = useState([GREETING])
  const [input, setInput] = useState('')
  const [pending, setPending] = useState(false)
  const end = useRef(null)
  useEffect(() => { end.current?.scrollIntoView({ block: 'nearest' }) }, [messages, pending, open])

  const ask = question => {
    const text = question.trim()
    if (!text || pending) return
    setInput('')
    setPending(true)
    setMessages(current => [...current, { sender: 'user', text }])
    window.setTimeout(() => {
      const { reply, ticket } = answerChat(text)
      setMessages(current => [...current, { sender: 'assistant', text: reply }])
      if (ticket) toast(`Chatbot đã tạo yêu cầu ${ticket.id} trong phân hệ CSKH.`)
      setPending(false)
    }, 420)
  }

  return (
    <>
      <button className="ai-launcher" type="button" aria-label={open ? 'Đóng trợ lý AI' : 'Mở trợ lý AI'} aria-expanded={open} onClick={() => setOpen(!open)}>
        <i className="fa-solid fa-wand-magic-sparkles" aria-hidden="true"></i>
        {!open && <span className="ai-launcher-label">Trợ lý Hòa Ma AI</span>}
      </button>
      <section className="ai-panel" role="dialog" aria-label="Trợ lý Hòa Ma AI" hidden={!open}>
        <header className="ai-header">
          <span className="ai-mark"><i className="fa-solid fa-wand-magic-sparkles" aria-hidden="true"></i></span>
          <div className="ai-title"><strong>Trợ lý Hòa Ma AI <span className="tag">24/7</span></strong><small>{ROLE_LABELS[actor.role]} · {actor.name}</small></div>
          <button className="ai-clear" type="button" aria-label="Hội thoại mới" onClick={() => setMessages([GREETING])}><i className="fa-solid fa-rotate-right" aria-hidden="true"></i></button>
          <button className="ai-close" type="button" aria-label="Đóng" onClick={() => setOpen(false)}><i className="fa-solid fa-xmark" aria-hidden="true"></i></button>
        </header>
        <div className="ai-scope">Trả lời theo cơ sở tri thức của trung tâm; cần người xử lý thì tự tạo yêu cầu CSKH.</div>
        <div className="ai-messages" aria-live="polite">
          {messages.map((message, index) => <div key={index} className={`ai-message${message.sender === 'user' ? ' user' : ''}`}>{message.text}</div>)}
          {pending && <div className="ai-message typing">Đang soạn câu trả lời…</div>}
          <span ref={end}></span>
        </div>
        <div className="ai-suggestions">
          {SUGGESTIONS.map(item => <button key={item} className="ai-suggestion" type="button" onClick={() => ask(item)}>{item}</button>)}
        </div>
        <form className="ai-compose" onSubmit={event => { event.preventDefault(); ask(input) }}>
          <label className="hm-sr" htmlFor="ai-input">Câu hỏi cho trợ lý</label>
          <textarea id="ai-input" rows={1} value={input} placeholder="Nhập câu hỏi…" onChange={event => setInput(event.target.value)}
            onKeyDown={event => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); ask(input) } if (event.key === 'Escape') setOpen(false) }} />
          <button className="ai-send" type="submit" aria-label="Gửi câu hỏi"><i className="fa-solid fa-arrow-up" aria-hidden="true"></i></button>
        </form>
        <div className="ai-disclaimer">Bản demo chạy cục bộ, không gửi dữ liệu ra ngoài.</div>
      </section>
    </>
  )
}
