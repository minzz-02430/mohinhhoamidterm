import { useState } from 'react'
import { monthKey, useStore } from './store'
import { classCount, debtTotal, groupBreakdown, inBranch, monthTotal, monthlyHistory, studentCount } from './selectors'
import { exportCsv, formatMoney, percent } from './format'
import { Badge, BarChart, BranchFilter, Donut, Kpi, LineChart, PageHead, Progress, branchScope, toast } from './ui'

export default function ReportsModule({ role }) {
  const store = useStore()
  const [branch, setBranch] = useState('all')
  const scope = role === 'admin' ? branch : branchScope(role)
  const history = monthlyHistory(store, scope)
  const branches = store.org.filter(item => inBranch(item, scope))
  const classes = store.classes.filter(item => inBranch(item, scope))
  const columns = [
    ['Cơ sở', row => row.branch], ['Học viên', row => studentCount(store, row.branch)], ['Số lớp', row => classCount(store, row.branch)],
    [`Doanh thu ${monthKey()} (đ)`, row => monthTotal(store, row.branch, 'income')], ['Công nợ (đ)', row => debtTotal(store, row.branch)],
    ['Chỉ tiêu tuyển sinh (%)', row => { const target = store.targets.find(item => item.branch === row.branch); return percent(target.actual, target.target) }],
  ]

  return (
    <>
      <PageHead title="Báo cáo" description="Tổng hợp theo cơ sở và khối lớp. Số liệu trùng khớp với Dashboard và Tài chính vì dùng chung một nguồn.">
        <BranchFilter role={role} value={branch} onChange={setBranch} />
        <button type="button" className="button" onClick={() => toast(`Đã xuất báo cáo ${exportCsv('bao-cao', columns, branches)} cơ sở ra file CSV.`)}><i className="fa-solid fa-download" aria-hidden="true"></i>Xuất báo cáo</button>
      </PageHead>

      <div className="kpi-grid">
        <Kpi label="Học viên đang theo học" value={studentCount(store, scope)} icon="fa-graduation-cap" note={`${history.at(-1).students - history[0].students >= 0 ? '+' : ''}${history.at(-1).students - history[0].students} học viên trong 6 tháng`} />
        <Kpi label="Tổng số lớp mở" value={classCount(store, scope)} icon="fa-chalkboard" note={`${branches.length} cơ sở`} />
        <Kpi label="Tỷ lệ chuyên cần" value={store.quality.attendance} unit="%" icon="fa-user-check" note="Trung bình toàn hệ thống" />
        <Kpi label={`Doanh thu tháng ${monthKey()}`} value={monthTotal(store, scope, 'income') / 1e6} unit="triệu" icon="fa-sack-dollar" format={value => value.toLocaleString('vi-VN', { maximumFractionDigits: 1 })} note={`Công nợ: ${formatMoney(debtTotal(store, scope), { compact: true })}`} />
      </div>

      <div className="grid-equal">
        <article className="card">
          <h2 className="card-title">Tăng trưởng học viên <span className="muted">6 tháng gần nhất</span></h2>
          <LineChart data={history} pick={item => item.students} label="Số học viên theo tháng" />
        </article>
        <article className="card">
          <h2 className="card-title">Doanh thu và chi phí <span className="muted">Triệu đồng</span></h2>
          <BarChart data={history} series={[['income', 'Doanh thu', '#ee6a25'], ['expense', 'Chi phí', '#94a3b8']]} format={value => Math.round(value / 1e6)} />
        </article>
      </div>

      <div className="grid-2">
        <article className="card hm-panel">
          <div className="hm-toolbar"><h2 className="card-title hm-flat">Theo cơ sở</h2></div>
          <div className="table-wrap">
            <table>
              <thead><tr><th>CƠ SỞ</th><th>HỌC VIÊN</th><th>SỐ LỚP</th><th>DOANH THU THÁNG</th><th>CÔNG NỢ</th><th>CHỈ TIÊU TUYỂN SINH</th></tr></thead>
              <tbody>
                {branches.map(row => {
                  const target = store.targets.find(item => item.branch === row.branch)
                  const rate = percent(target.actual, target.target)
                  return (
                    <tr key={row.branch}>
                      <td><strong>{row.branch}</strong></td>
                      <td>{studentCount(store, row.branch)}</td>
                      <td>{classCount(store, row.branch)}</td>
                      <td>{formatMoney(monthTotal(store, row.branch, 'income'), { compact: true })}</td>
                      <td>{formatMoney(debtTotal(store, row.branch), { compact: true })}</td>
                      <td><div className="hm-cell-progress"><Progress value={rate} tone={rate >= 85 ? 'green' : 'orange'} label={`Chỉ tiêu ${row.branch}`} /><span>{rate}%</span></div></td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </article>
        <article className="card hm-stretch">
          <h2 className="card-title">Phân bổ học viên theo khối</h2>
          <Donut data={groupBreakdown(store, scope)} unit="HV" centerLabel="học viên" />
        </article>
      </div>

      <article className="card hm-panel">
        <div className="hm-toolbar"><h2 className="card-title hm-flat">Sĩ số theo lớp <Badge tone="orange">{classes.length} lớp có dữ liệu chi tiết</Badge></h2></div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>LỚP</th><th>KHỐI</th><th>GIÁO VIÊN</th><th>CƠ SỞ</th><th>SĨ SỐ</th><th>LẤP ĐẦY</th></tr></thead>
            <tbody>
              {classes.map(item => (
                <tr key={item.id}>
                  <td><strong>{item.name}</strong></td><td>{item.group}</td><td>{item.teacher}</td><td>{item.branch}</td><td>{item.size}/{item.capacity}</td>
                  <td><div className="hm-cell-progress"><Progress value={percent(item.size, item.capacity)} label={`Lấp đầy ${item.name}`} /><span>{percent(item.size, item.capacity)}%</span></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </article>
    </>
  )
}
