// Mọi con số trên Dashboard, Tài chính, Báo cáo đều tính từ kho dữ liệu qua các hàm này.
import { GRADE_GROUPS, invoiceState, invoiceTotal, monthKey } from './store.js'

const sum = (items, pick) => items.reduce((total, item) => total + pick(item), 0)
export const inBranch = (item, branch) => !branch || branch === 'all' || item.branch === branch
const orgOf = (state, branch) => state.org.filter(item => inBranch(item, branch))

export const studentCount = (state, branch) => sum(orgOf(state, branch), item => sum(item.groups, count => count))
export const classCount = (state, branch) => sum(orgOf(state, branch), item => item.classes)
export const groupBreakdown = (state, branch) => GRADE_GROUPS.map((label, index) => ({ label, value: sum(orgOf(state, branch), item => item.groups[index]) }))
export const monthTotal = (state, branch, type, key = monthKey()) => sum(
  state.transactions.filter(item => item.type === type && monthKey(item.at) === key && inBranch(item, branch)), item => item.amount)
export const unpaidInvoices = (state, branch) => state.invoices.filter(item => item.status !== 'paid' && inBranch(item, branch))
export const overdueInvoices = (state, branch, now = Date.now()) => unpaidInvoices(state, branch).filter(item => invoiceState(item, now) === 'overdue')
export const debtTotal = (state, branch) => sum(unpaidInvoices(state, branch), invoiceTotal)
export const payrollPending = (state, branch) => state.staff.filter(item => item.payroll === 'Chờ duyệt' && inBranch(item, branch))
export const payrollTotal = (state, branch) => sum(payrollPending(state, branch), item => item.salary) * 1e6

// 6 tháng gần nhất: 5 tháng lịch sử + tháng hiện tại tính từ phiếu thu/chi thật.
export function monthlyHistory(state, branch) {
  const share = studentCount(state, branch) / studentCount(state, 'all')
  return [
    ...state.history.map(item => ({ label: item.label, students: Math.round(item.students * share), income: Math.round(item.income * share) * 1e6, expense: Math.round(item.expense * share) * 1e6 })),
    { label: `T${new Date().getMonth() + 1}`, students: studentCount(state, branch), income: monthTotal(state, branch, 'income'), expense: monthTotal(state, branch, 'expense') },
  ]
}
