import { useState } from 'react'
import {
  BRANCHES, CHANNELS, GRADE_GROUPS, myBranch, STAGES,
  addActivity, addLead, findDuplicateLead, moveLead, toggleActivity, useStore,
} from './store'
import { exportCsv } from './format'
import { Avatar, Badge, BranchFilter, Empty, Field, Kpi, Modal, PageHead, Pager, Progress, Select, Tabs, branchScope, inScope, money, percent, toast, usePager } from './ui'

const channelTone = { Facebook: 'blue', Zalo: 'cyan', Website: 'purple', 'Giới thiệu': 'green', 'Sự kiện': 'amber' }
const activityMeta = {
  task: ['Công việc', 'fa-list-check', 'slate'],
  call: ['Cuộc gọi', 'fa-phone', 'blue'],
  meeting: ['Buổi hẹn', 'fa-people-group', 'purple'],
}
const ageText = days => (days === 0 ? 'Hôm nay' : `${days} ngày trước`)

function LeadCard({ lead, onMove }) {
  const index = STAGES.findIndex(stage => stage.id === lead.stage)
  const next = STAGES[index + 1]
  return (
    <article className="hm-lead" draggable onDragStart={event => event.dataTransfer.setData('text/plain', lead.id)}>
      <header>
        <Avatar name={lead.parent} />
        <div>
          <strong>{lead.parent}</strong>
          <small>{lead.student} · {lead.grade}</small>
        </div>
      </header>
      <p>{lead.course}</p>
      <div className="hm-lead-meta">
        <Badge tone={channelTone[lead.channel]}>{lead.channel}</Badge>
        <span><i className="fa-solid fa-location-dot" aria-hidden="true"></i>{lead.branch}</span>
      </div>
      <footer>
        <span>{money(lead.value)} · {ageText(lead.daysAgo)}</span>
        {next && lead.stage !== 'enrolled' && (
          <button type="button" className="hm-link" onClick={() => onMove(lead, next.id)}>
            {next.label}<i className="fa-solid fa-arrow-right" aria-hidden="true"></i>
          </button>
        )}
        {lead.stage === 'lost' && (
          <button type="button" className="hm-link" onClick={() => onMove(lead, 'contacted')}>
            Chăm sóc lại<i className="fa-solid fa-rotate-left" aria-hidden="true"></i>
          </button>
        )}
      </footer>
    </article>
  )
}

function Pipeline({ leads, onMove }) {
  const [over, setOver] = useState('')
  return (
    <div className="hm-board">
      {STAGES.map(stage => {
        const items = leads.filter(lead => lead.stage === stage.id)
        return (
          <section
            key={stage.id}
            className={`hm-column${over === stage.id ? ' over' : ''}`}
            aria-label={stage.label}
            onDragOver={event => { event.preventDefault(); setOver(stage.id) }}
            onDragLeave={() => setOver('')}
            onDrop={event => {
              event.preventDefault()
              setOver('')
              const lead = leads.find(item => item.id === event.dataTransfer.getData('text/plain'))
              if (lead) onMove(lead, stage.id)
            }}
          >
            <header>
              <span className={`hm-dot hm-${stage.tone}`}></span>
              <h3>{stage.label}</h3>
              <span className="hm-count">{items.length}</span>
              <small>{money(items.reduce((sum, lead) => sum + lead.value, 0))}</small>
            </header>
            <div className="hm-column-body">
              {items.map(lead => <LeadCard key={lead.id} lead={lead} onMove={onMove} />)}
              {!items.length && <Empty icon="fa-arrow-down-short-wide">Kéo lead vào đây</Empty>}
            </div>
          </section>
        )
      })}
    </div>
  )
}

function LeadTable({ leads, onMove }) {
  const [selected, setSelected] = useState(() => new Set())
  const [size, setSize] = useState(10)
  const [stage, setStage] = useState('contacted')
  const pager = usePager(leads, size)
  if (!leads.length) return <Empty>Không có lead nào khớp bộ lọc.</Empty>
  const chosen = leads.filter(lead => selected.has(lead.id))
  const pageIds = pager.rows.map(lead => lead.id)
  const allOnPage = pageIds.every(id => selected.has(id))
  const toggle = ids => setSelected(current => {
    const next = new Set(current)
    const remove = ids.every(id => next.has(id))
    ids.forEach(id => (remove ? next.delete(id) : next.add(id)))
    return next
  })
  const moveAll = () => {
    const moved = chosen.filter(lead => moveLead(lead.id, stage) !== false).length
    if (moved) toast(`Đã chuyển ${moved} lead sang “${STAGES.find(item => item.id === stage).label}”.`)
    setSelected(new Set())
  }
  return (
    <>
      {chosen.length > 0 && (
        <div className="hm-bulk" role="region" aria-label="Thao tác hàng loạt">
          <strong>Đã chọn {chosen.length} lead</strong>
          <label className="hm-inline-select">
            <span className="hm-sr">Giai đoạn chuyển tới</span>
            <select value={stage} onChange={event => setStage(event.target.value)}>{STAGES.map(item => <option key={item.id} value={item.id}>{item.label}</option>)}</select>
          </label>
          <button type="button" className="button small primary" onClick={moveAll}>Chuyển giai đoạn</button>
          <button type="button" className="button small" onClick={() => toast(`Đã xuất ${exportCsv('lead-da-chon', [['Mã', row => row.id], ['Phụ huynh', row => row.parent], ['SĐT', row => row.phone], ['Học sinh', row => row.student], ['Khóa quan tâm', row => row.course], ['Cơ sở', row => row.branch]], chosen)} lead đã chọn ra file CSV.`)}>Xuất mục đã chọn</button>
          <button type="button" className="hm-link" onClick={() => setSelected(new Set())}>Bỏ chọn</button>
        </div>
      )}
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th><input type="checkbox" aria-label="Chọn tất cả lead trên trang" checked={allOnPage} onChange={() => toggle(pageIds)} /></th>
              <th>MÃ</th><th>PHỤ HUYNH</th><th>HỌC SINH</th><th>KHÓA QUAN TÂM</th><th>KÊNH</th><th>CƠ SỞ</th><th>TƯ VẤN VIÊN</th><th>GIAI ĐOẠN</th>
            </tr>
          </thead>
          <tbody>
            {pager.rows.map(lead => (
              <tr key={lead.id} className={selected.has(lead.id) ? 'hm-selected' : ''}>
                <td><input type="checkbox" aria-label={`Chọn lead ${lead.id}`} checked={selected.has(lead.id)} onChange={() => toggle([lead.id])} /></td>
                <td>{lead.id}</td>
                <td><strong>{lead.parent}</strong><br /><small>{lead.phone}</small></td>
                <td>{lead.student}<br /><small>{lead.grade}</small></td>
                <td>{lead.course}</td>
                <td><Badge tone={channelTone[lead.channel]}>{lead.channel}</Badge></td>
                <td>{lead.branch}</td>
                <td>{lead.owner}</td>
                <td>
                  <label className="hm-inline-select">
                    <span className="hm-sr">Giai đoạn của {lead.parent}</span>
                    <select value={lead.stage} onChange={event => onMove(lead, event.target.value)}>
                      {STAGES.map(item => <option key={item.id} value={item.id}>{item.label}</option>)}
                    </select>
                  </label>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="hm-pager-row">
        <label className="hm-inline-select">
          <span>Số dòng mỗi trang</span>
          <select value={size} onChange={event => setSize(Number(event.target.value))}>{[5, 10, 20].map(item => <option key={item} value={item}>{item}</option>)}</select>
        </label>
        <Pager pager={pager} />
      </div>
    </>
  )
}

function Activities({ items }) {
  const [kind, setKind] = useState('all')
  const shown = items.filter(item => kind === 'all' || item.type === kind)
  return (
    <>
      <div className="hm-toolbar">
        <Tabs label="Loại hoạt động" value={kind} onChange={setKind} tabs={[
          ['all', 'Tất cả', items.length],
          ...Object.entries(activityMeta).map(([id, [text]]) => [id, text, items.filter(item => item.type === id).length]),
        ]} />
      </div>
      {!shown.length && <Empty>Chưa có hoạt động nào.</Empty>}
      <ul className="hm-activity-list">
        {shown.map(item => {
          const [text, icon, tone] = activityMeta[item.type]
          return (
            <li key={item.id} className={item.done ? 'done' : ''}>
              <label className="hm-check">
                <input type="checkbox" checked={item.done} onChange={() => toggleActivity(item.id)} />
                <span className="hm-sr">Đánh dấu hoàn thành: {item.title}</span>
              </label>
              <span className={`hm-activity-icon hm-${tone}`}><i className={`fa-solid ${icon}`} aria-hidden="true"></i></span>
              <div>
                <strong>{item.title}</strong>
                <small>{text} · {item.who} · {item.branch}</small>
              </div>
              <span className="hm-activity-owner">{item.owner}</span>
              <Badge tone={item.done ? 'green' : item.due.startsWith('Hôm nay') ? 'amber' : 'slate'} icon="fa-clock">{item.done ? 'Hoàn thành' : item.due}</Badge>
            </li>
          )
        })}
      </ul>
    </>
  )
}

function Campaigns({ campaigns }) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr><th>CHIẾN DỊCH</th><th>KÊNH</th><th>THỜI GIAN</th><th>NGÂN SÁCH</th><th>LEAD</th><th>GHI DANH</th><th>CHUYỂN ĐỔI</th><th>CHI PHÍ / HỌC VIÊN</th><th>TRẠNG THÁI</th></tr>
        </thead>
        <tbody>
          {campaigns.map(item => (
            <tr key={item.id}>
              <td><strong>{item.name}</strong><br /><small>{item.id}</small></td>
              <td><Badge tone={channelTone[item.channel]}>{item.channel}</Badge></td>
              <td>{item.period}</td>
              <td>{money(item.budget)}</td>
              <td>{item.leads}</td>
              <td>{item.enrolled}</td>
              <td>
                <div className="hm-cell-progress">
                  <Progress value={percent(item.enrolled, item.leads)} label={`Chuyển đổi ${item.name}`} />
                  <span>{percent(item.enrolled, item.leads)}%</span>
                </div>
              </td>
              <td>{money(item.budget / item.enrolled)}</td>
              <td><Badge tone={item.status === 'Đang chạy' ? 'green' : 'slate'}>{item.status}</Badge></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function Targets({ targets, leads }) {
  const byChannel = CHANNELS.map(channel => {
    const total = leads.filter(lead => lead.channel === channel)
    return { channel, total: total.length, enrolled: total.filter(lead => lead.stage === 'enrolled').length }
  })
  const maxChannel = Math.max(1, ...byChannel.map(item => item.total))
  return (
    <div className="grid-equal hm-flush">
      <div>
        <h3 className="hm-subtitle">Chỉ tiêu tuyển sinh tháng 11 theo cơ sở</h3>
        <ul className="hm-target-list">
          {targets.map(item => {
            const rate = percent(item.actual, item.target)
            return (
              <li key={item.branch}>
                <div><strong>{item.branch}</strong><span>{item.actual}/{item.target} học viên</span></div>
                <Progress value={rate} tone={rate >= 85 ? 'green' : rate >= 60 ? 'orange' : 'red'} label={`Chỉ tiêu ${item.branch}`} />
                <Badge tone={rate >= 85 ? 'green' : rate >= 60 ? 'amber' : 'red'}>{rate}%</Badge>
              </li>
            )
          })}
        </ul>
      </div>
      <div>
        <h3 className="hm-subtitle">Lead theo kênh tuyển sinh</h3>
        <ul className="hm-bar-list">
          {byChannel.map(item => (
            <li key={item.channel}>
              <span>{item.channel}</span>
              <div className="hm-bar"><span className={`hm-fill hm-fill-${channelTone[item.channel]}`} style={{ width: `${(item.total / maxChannel) * 100}%` }}></span></div>
              <strong>{item.total}</strong>
              <small>{item.enrolled} ghi danh</small>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}

function LeadForm({ role, onClose, notify }) {
  const [form, setForm] = useState({
    parent: '', phone: '', student: '', grade: GRADE_GROUPS[0], course: '', channel: CHANNELS[0],
    branch: role === 'admin' ? BRANCHES[0] : myBranch(), owner: 'Lê Thị Bình',
  })
  const set = key => event => setForm(current => ({ ...current, [key]: event.target.value }))
  const duplicate = findDuplicateLead(form.phone)
  const submit = event => {
    event.preventDefault()
    if (duplicate) return
    const lead = addLead(form)
    if (!lead) return onClose()
    notify(`Đã tạo lead ${lead.id} cho ${lead.parent}.`)
    onClose()
  }
  return (
    <Modal title="Thêm lead tuyển sinh" description="Hệ thống tự kiểm tra trùng số điện thoại để không tạo lead lặp." onClose={onClose}>
      <form className="hm-form" onSubmit={submit}>
        <Field label="Phụ huynh">{id => <input id={id} required value={form.parent} onChange={set('parent')} placeholder="Chị Nguyễn Thị A" />}</Field>
        <Field label="Số điện thoại" error={duplicate && `Trùng với lead ${duplicate.id} (${duplicate.parent}) đang ở cơ sở ${duplicate.branch}.`}>
          {id => <input id={id} required inputMode="tel" pattern="[0-9 ]{9,13}" value={form.phone} onChange={set('phone')} placeholder="09xx xxx xxx" />}
        </Field>
        <Field label="Học sinh">{id => <input id={id} required value={form.student} onChange={set('student')} />}</Field>
        <Field label="Khối lớp">{id => <select id={id} value={form.grade} onChange={set('grade')}>{GRADE_GROUPS.map(item => <option key={item}>{item}</option>)}</select>}</Field>
        <Field label="Khóa học quan tâm">{id => <input id={id} required value={form.course} onChange={set('course')} placeholder="Luyện thi vào 10" />}</Field>
        <Field label="Kênh">{id => <select id={id} value={form.channel} onChange={set('channel')}>{CHANNELS.map(item => <option key={item}>{item}</option>)}</select>}</Field>
        <Field label="Cơ sở">
          {id => (
            <select id={id} value={form.branch} onChange={set('branch')} disabled={role !== 'admin'}>
              {BRANCHES.map(item => <option key={item}>{item}</option>)}
            </select>
          )}
        </Field>
        <Field label="Tư vấn viên phụ trách">{id => <input id={id} required value={form.owner} onChange={set('owner')} />}</Field>
        <div className="hm-form-actions">
          <button type="button" className="button" onClick={onClose}>Hủy</button>
          <button type="submit" className="button primary" disabled={Boolean(duplicate)}>Lưu lead</button>
        </div>
      </form>
    </Modal>
  )
}

function ActivityForm({ role, onClose, notify }) {
  const [form, setForm] = useState({ type: 'call', title: '', who: '', owner: 'Lê Thị Bình', due: 'Hôm nay 16:00', branch: role === 'admin' ? BRANCHES[0] : myBranch() })
  const set = key => event => setForm(current => ({ ...current, [key]: event.target.value }))
  return (
    <Modal title="Thêm hoạt động chăm sóc" onClose={onClose}>
      <form className="hm-form" onSubmit={event => { event.preventDefault(); addActivity(form); notify('Đã thêm hoạt động vào hàng đợi công việc.'); onClose() }}>
        <Field label="Loại">{id => <select id={id} value={form.type} onChange={set('type')}>{Object.entries(activityMeta).map(([key, [text]]) => <option key={key} value={key}>{text}</option>)}</select>}</Field>
        <Field label="Hạn thực hiện">{id => <input id={id} required value={form.due} onChange={set('due')} />}</Field>
        <Field label="Nội dung">{id => <input id={id} required value={form.title} onChange={set('title')} placeholder="Gọi tư vấn lộ trình" />}</Field>
        <Field label="Liên quan đến">{id => <input id={id} required value={form.who} onChange={set('who')} placeholder="Tên phụ huynh" />}</Field>
        <div className="hm-form-actions">
          <button type="button" className="button" onClick={onClose}>Hủy</button>
          <button type="submit" className="button primary">Lưu hoạt động</button>
        </div>
      </form>
    </Modal>
  )
}

export default function CrmModule({ role, notify }) {
  const store = useStore()
  const [tab, setTab] = useState('pipeline')
  const [branch, setBranch] = useState('all')
  const [channel, setChannel] = useState('all')
  const [query, setQuery] = useState('')
  const [dialog, setDialog] = useState('')
  const scope = role === 'admin' ? branch : branchScope(role)

  const text = query.trim().toLowerCase()
  const leads = store.leads.filter(lead =>
    inScope(lead, scope)
    && (channel === 'all' || lead.channel === channel)
    && (!text || `${lead.parent} ${lead.student} ${lead.phone} ${lead.course}`.toLowerCase().includes(text)))
  const activities = store.activities.filter(item => inScope(item, scope))
  const targets = store.targets.filter(item => inScope(item, scope))
  const enrolled = leads.filter(lead => lead.stage === 'enrolled').length
  const open = leads.filter(lead => !['enrolled', 'lost'].includes(lead.stage))
  const todo = activities.filter(item => !item.done)

  const onMove = (lead, stage) => {
    const created = moveLead(lead.id, stage)
    if (created === false) return
    const label = STAGES.find(item => item.id === stage).label
    notify(created
      ? `Đã ghi danh ${lead.student}: tạo mã học viên ${created.studentId} và hóa đơn ${created.invoiceId}.`
      : `Đã chuyển ${lead.parent} sang “${label}”.`, created ? undefined : { label: 'Hoàn tác', run: () => moveLead(lead.id, lead.stage) })
  }

  return (
    <>
      <PageHead title="CRM · Tuyển sinh và ghi danh" description="Theo dõi lead từ lúc tiếp nhận đến khi ghi danh, theo cơ sở và kênh tuyển sinh.">
        <button type="button" className="button" onClick={() => notify(`Đã xuất ${exportCsv('lead', [['Mã', row => row.id], ['Phụ huynh', row => row.parent], ['SĐT', row => row.phone], ['Học sinh', row => row.student], ['Khối', row => row.grade], ['Khóa quan tâm', row => row.course], ['Kênh', row => row.channel], ['Cơ sở', row => row.branch], ['Tư vấn viên', row => row.owner], ['Giai đoạn', row => STAGES.find(stage => stage.id === row.stage).label]], leads)} lead đang lọc ra file CSV.`)}><i className="fa-solid fa-download" aria-hidden="true"></i>Xuất danh sách</button>
        <button type="button" className="button" onClick={() => setDialog('activity')}><i className="fa-solid fa-calendar-plus" aria-hidden="true"></i>Thêm hoạt động</button>
        <button type="button" className="button primary" onClick={() => setDialog('lead')}><i className="fa-solid fa-plus" aria-hidden="true"></i>Thêm lead</button>
      </PageHead>

      <div className="kpi-grid">
        <Kpi label="Lead đang theo dõi" value={open.length} icon="fa-user-plus" note={`${leads.filter(lead => lead.daysAgo <= 1).length} lead mới trong 48 giờ`} />
        <Kpi label="Tỷ lệ chuyển đổi" value={percent(enrolled, leads.length)} unit="%" icon="fa-arrow-trend-up" note={`${enrolled}/${leads.length} lead đã ghi danh`} />
        <Kpi label="Giá trị pipeline" value={money(open.reduce((sum, lead) => sum + lead.value, 0))} icon="fa-sack-dollar" note="Học phí kỳ đầu dự kiến" />
        <Kpi label="Việc cần làm" value={todo.length} icon="fa-list-check" tone={todo.length ? 'warn' : 'good'} note={`${todo.filter(item => item.due.startsWith('Hôm nay')).length} việc đến hạn hôm nay`} />
      </div>

      <article className="card hm-panel">
        <div className="hm-toolbar">
          <Tabs label="Phân hệ CRM" value={tab} onChange={setTab} tabs={[
            ['pipeline', 'Pipeline'], ['list', 'Danh sách lead', leads.length], ['activities', 'Hoạt động', todo.length],
            ['campaigns', 'Chiến dịch'], ['targets', 'Chỉ tiêu & kênh'],
          ]} />
          <div className="hm-filters">
            <label className="hm-search">
              <span className="hm-sr">Tìm lead</span>
              <i className="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
              <input type="search" value={query} onChange={event => setQuery(event.target.value)} placeholder="Tìm phụ huynh, học sinh, SĐT" />
            </label>
            <Select label="Kênh" icon="fa-bullhorn" value={channel} onChange={setChannel} options={[['all', 'Mọi kênh'], ...CHANNELS]} />
            <BranchFilter role={role} value={branch} onChange={setBranch} />
          </div>
        </div>
        {tab === 'pipeline' && <Pipeline leads={leads} onMove={onMove} />}
        {tab === 'list' && <LeadTable leads={leads} onMove={onMove} />}
        {tab === 'activities' && <Activities items={activities} />}
        {tab === 'campaigns' && <Campaigns campaigns={store.campaigns} />}
        {tab === 'targets' && <Targets targets={targets} leads={leads} />}
      </article>

      {dialog === 'lead' && <LeadForm role={role} notify={notify} onClose={() => setDialog('')} />}
      {dialog === 'activity' && <ActivityForm role={role} notify={notify} onClose={() => setDialog('')} />}
    </>
  )
}
