import { useState } from 'react'
import { BRANCHES, approvePayroll, myBranch, requestPayrollApproval, useStore } from './store'
import { ShiftBoard, StaffImport } from './Extras'
import { exportCsv } from './format'
import { StaffForm } from './forms'
import { Avatar, Badge, BranchFilter, Empty, Kpi, PageHead, Progress, Select, Tabs, branchScope, inScope, money, percent } from './ui'

export default function HrModule({ role, notify }) {
  const store = useStore()
  const [tab, setTab] = useState('staff')
  const [branch, setBranch] = useState('all')
  const [adding, setAdding] = useState(false)
  const [position, setPosition] = useState('all')
  const scope = role === 'admin' ? branch : branchScope(role)
  const scoped = store.staff.filter(item => inScope(item, scope))
  const positions = [...new Set(scoped.map(item => item.role))]
  const staff = scoped.filter(item => position === 'all' || item.role === position)
  const onLeave = staff.filter(item => item.status === 'Nghỉ phép').length
  const present = staff.filter(item => item.checkIn !== '—').length
  const pending = staff.filter(item => item.payroll === 'Chờ duyệt')
  const canApprove = role === 'admin'

  return (
    <>
      <PageHead title="Quản lý nhân sự" description="Hồ sơ nhân sự, chấm công trong ngày, KPI và phê duyệt bảng lương theo cơ sở.">
        <button type="button" className="button" onClick={() => notify(`Đã xuất ${exportCsv('nhan-su', [['Mã', row => row.id], ['Họ tên', row => row.name], ['Vị trí', row => row.role], ['Cơ sở', row => row.branch], ['SĐT', row => row.phone], ['Hợp đồng', row => row.contract], ['KPI (%)', row => row.kpi], ['Lương (triệu)', row => row.salary], ['Bảng lương', row => row.payroll]], staff)} nhân sự ra file CSV.`)}><i className="fa-solid fa-download" aria-hidden="true"></i>Xuất danh sách</button>
        <StaffImport branch={role !== 'admin' ? myBranch() : scope === 'all' ? BRANCHES[0] : scope} />
        <button type="button" className="button" onClick={() => setAdding(true)}><i className="fa-solid fa-user-plus" aria-hidden="true"></i>Thêm nhân sự</button>
        {role === 'manager' && pending.length > 0 && (
          <button type="button" className="button primary" onClick={() => { if (requestPayrollApproval()) notify('Đã gửi bảng lương lên Ban giám đốc chờ duyệt.') }}>
            <i className="fa-solid fa-paper-plane" aria-hidden="true"></i>Gửi duyệt bảng lương
          </button>
        )}
        {canApprove && pending.length > 0 && (
          <button type="button" className="button primary" onClick={() => { approvePayroll(pending.map(item => item.id)); notify(`Đã duyệt ${pending.length} phiếu lương tháng 10.`) }}>
            <i className="fa-solid fa-check-double" aria-hidden="true"></i>Duyệt {pending.length} phiếu lương
          </button>
        )}
      </PageHead>

      <div className="kpi-grid">
        <Kpi label="Tổng nhân sự" value={staff.length} icon="fa-users" note={`${staff.filter(item => item.role.startsWith('Giáo viên')).length} giáo viên · ${staff.filter(item => !item.role.startsWith('Giáo viên')).length} vận hành`} />
        <Kpi label="Có mặt hôm nay" value={present} icon="fa-user-check" note={`${percent(present, staff.length)}% đã chấm công · ${onLeave} nghỉ phép hôm nay`} />
        <Kpi label="KPI trung bình" value={staff.length ? Math.round(staff.reduce((sum, item) => sum + item.kpi, 0) / staff.length) : 0} unit="%" icon="fa-bullseye" note="Theo chỉ tiêu tháng 10" />
        <Kpi label="Quỹ lương chờ duyệt" value={money(pending.reduce((sum, item) => sum + item.salary, 0))} icon="fa-money-check-dollar" tone={pending.length ? 'warn' : 'good'} note={pending.length ? `${pending.length} phiếu · hạn duyệt 31/10` : 'Đã duyệt toàn bộ'} />
      </div>

      <article className="card hm-panel">
        <div className="hm-toolbar">
          <Tabs label="Phân hệ nhân sự" value={tab} onChange={setTab} tabs={[['staff', 'Hồ sơ', staff.length], ['attendance', 'Chấm công & KPI'], ['payroll', 'Bảng lương', pending.length || undefined], ['shifts', 'Lịch trực']]} />
          <div className="hm-filters">
            <Select label="Vai trò" icon="fa-user-tag" value={position} onChange={setPosition} options={[['all', 'Mọi vai trò'], ...positions]} />
            <BranchFilter role={role} value={branch} onChange={setBranch} />
          </div>
        </div>
        {!staff.length && <Empty>Cơ sở này chưa có nhân sự.</Empty>}
        {tab === 'shifts' && <ShiftBoard staff={staff} shifts={store.shifts} scope={scope} />}
        {tab !== 'shifts' && staff.length > 0 && (
          <div className="table-wrap">
            <table>
              <thead>
                {tab === 'staff' && <tr><th>NHÂN SỰ</th><th>VỊ TRÍ</th><th>SĐT</th><th>HỢP ĐỒNG</th><th>CƠ SỞ</th><th>NGÀY VÀO LÀM</th><th>TRẠNG THÁI</th></tr>}
                {tab === 'attendance' && <tr><th>NHÂN SỰ</th><th>GIỜ VÀO HÔM NAY</th><th>SỐ BUỔI DẠY THÁNG</th><th>KPI</th><th>ĐÁNH GIÁ</th></tr>}
                {tab === 'payroll' && <tr><th>NHÂN SỰ</th><th>VỊ TRÍ</th><th>LƯƠNG THÁNG 10</th><th>TRẠNG THÁI</th><th></th></tr>}
              </thead>
              <tbody>
                {staff.map(item => (
                  <tr key={item.id}>
                    <td><span className="hm-person"><Avatar name={item.name} /><span><strong>{item.name}</strong><small>{item.id}</small></span></span></td>
                    {tab === 'staff' && (
                      <>
                        <td>{item.role}</td>
                        <td>{item.phone}</td>
                        <td>{item.contract}</td>
                        <td>{item.branch}</td>
                        <td>{item.joined}</td>
                        <td><Badge tone={item.status === 'Nghỉ phép' ? 'amber' : 'green'}>{item.status}</Badge></td>
                      </>
                    )}
                    {tab === 'attendance' && (
                      <>
                        <td>{item.checkIn === '—' ? <Badge tone="amber">Nghỉ phép</Badge> : item.checkIn}</td>
                        <td>{item.sessions || '—'}</td>
                        <td>
                          <div className="hm-cell-progress">
                            <Progress value={item.kpi} tone={item.kpi >= 85 ? 'green' : 'orange'} label={`KPI ${item.name}`} />
                            <span>{item.kpi}%</span>
                          </div>
                        </td>
                        <td><Badge tone={item.kpi >= 90 ? 'green' : item.kpi >= 85 ? 'blue' : 'amber'}>{item.kpi >= 90 ? 'Xuất sắc' : item.kpi >= 85 ? 'Đạt' : 'Cần cải thiện'}</Badge></td>
                      </>
                    )}
                    {tab === 'payroll' && (
                      <>
                        <td>{item.role}</td>
                        <td><strong>{money(item.salary)}</strong></td>
                        <td><Badge tone={item.payroll === 'Đã duyệt' ? 'green' : 'amber'}>{item.payroll}</Badge></td>
                        <td>
                          {canApprove && item.payroll === 'Chờ duyệt' && (
                            <button type="button" className="button small" onClick={() => { approvePayroll([item.id]); notify(`Đã duyệt phiếu lương của ${item.name}.`) }}>Duyệt</button>
                          )}
                        </td>
                      </>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {tab === 'payroll' && !canApprove && <p className="hm-form-note">Quản lý cơ sở chỉ xem bảng lương; quyền duyệt thuộc Ban giám đốc.</p>}
      </article>
      {adding && <StaffForm role={role} onClose={() => setAdding(false)} />}
    </>
  )
}
