const API_BASE_URL = (
  import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000/api/v1'
).replace(/\/+$/, '')

export async function getCurrentMonthRevenue(token, signal) {
  const response = await fetch(`${API_BASE_URL}/finance/dashboard/revenue`, {
    headers: {
      Accept: 'application/json',
      Authorization: `Bearer ${token}`,
    },
    signal,
  })

  const contentType = response.headers.get('content-type') || ''
  if (!contentType.includes('application/json')) {
    throw new Error(`Backend trả về dữ liệu không hợp lệ (HTTP ${response.status}). Hãy kiểm tra URL API.`)
  }

  const body = await response.json()
  if (!response.ok) {
    throw new Error(body.message || `Không thể tải doanh thu (HTTP ${response.status}).`)
  }

  const revenue = body
  if (!revenue || typeof revenue.month !== 'string' || !Number.isFinite(Number(revenue.totalRevenue))) {
    throw new Error('Dữ liệu doanh thu trả về không đúng định dạng.')
  }

  return revenue
}
