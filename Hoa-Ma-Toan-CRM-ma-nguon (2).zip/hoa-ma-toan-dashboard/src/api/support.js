const API_BASE_URL = (
  import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000/api/v1'
).replace(/\/+$/, '')

async function supportRequest(path, token, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers: {
      Accept: 'application/json',
      ...(options.body ? { 'Content-Type': 'application/json' } : {}),
      Authorization: `Bearer ${token}`,
      ...options.headers,
    },
  })
  const contentType = response.headers.get('content-type') || ''
  if (!contentType.includes('application/json')) {
    throw new Error(`Backend trả về dữ liệu không hợp lệ (HTTP ${response.status}). Hãy kiểm tra URL API.`)
  }

  const body = await response.json()
  if (!response.ok) {
    throw new Error(body.message || `Không thể gửi yêu cầu hỗ trợ (HTTP ${response.status}).`)
  }

  return body.data
}

export async function createSupportRequest(token, type, description) {
  const data = await supportRequest('/support/requests', token, {
    method: 'POST',
    body: JSON.stringify({ type, description }),
  })
  return data.request
}

export async function getPendingSupportRequests(token, signal) {
  const data = await supportRequest('/support/requests/pending', token, { signal })
  return data.requests
}

export async function updateSupportRequestStatus(token, requestId, status) {
  const data = await supportRequest(`/support/requests/${requestId}/status`, token, {
    method: 'PATCH',
    body: JSON.stringify({ status }),
  })
  return data.request
}
