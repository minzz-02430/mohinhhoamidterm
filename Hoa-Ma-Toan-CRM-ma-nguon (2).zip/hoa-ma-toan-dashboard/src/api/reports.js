const API_BASE_URL = (
  import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000/api/v1'
).replace(/\/+$/, '')

/**
 * Lấy báo cáo buổi học của các học sinh liên kết với phụ huynh đang đăng nhập.
 * Token phải là JWT nhận được từ POST /auth/login; không lưu token trong mã nguồn.
 *
 * @param {string} token JWT access token
 * @param {AbortSignal} [signal] Tín hiệu tùy chọn để hủy request
 * @returns {Promise<Array<object>>} Danh sách báo cáo trong data.reports
 */
export async function getMyChildrenReports(token, signal) {
  if (typeof token !== 'string' || token.trim().length === 0) {
    throw new Error('Cần JWT token để tải báo cáo học tập.')
  }

  const response = await fetch(`${API_BASE_URL}/reports/my-children`, {
    method: 'GET',
    headers: {
      Accept: 'application/json',
      Authorization: `Bearer ${token.trim()}`,
    },
    signal,
  })

  const contentType = response.headers.get('content-type') || ''
  if (!contentType.includes('application/json')) {
    throw new Error(`Backend trả về dữ liệu không hợp lệ (HTTP ${response.status}). Hãy kiểm tra URL API.`)
  }

  const body = await response.json()

  if (!response.ok) {
    throw new Error(body.message || `Không thể tải báo cáo (HTTP ${response.status}).`)
  }

  if (!Array.isArray(body.data?.reports)) {
    throw new Error('Dữ liệu báo cáo trả về không đúng định dạng.')
  }

  return body.data.reports
}
