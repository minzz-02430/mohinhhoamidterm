const API_BASE_URL = (
  import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000/api/v1'
).replace(/\/+$/, '')

async function postJson(path, payload) {
  let response
  try {
    response = await fetch(`${API_BASE_URL}${path}`, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    })
  } catch {
    throw new Error(`Không thể kết nối Backend tại ${API_BASE_URL}. Hãy kiểm tra server và cấu hình API.`)
  }

  const contentType = response.headers.get('content-type') || ''
  if (!contentType.includes('application/json')) {
    throw new Error(`Backend trả về dữ liệu không hợp lệ (HTTP ${response.status}). Hãy kiểm tra URL API.`)
  }

  const body = await response.json()
  if (!response.ok) {
    throw new Error(body.message || `Yêu cầu thất bại (HTTP ${response.status}).`)
  }

  return body.data
}

export async function loginWithPassword({ email, password }) {
  const data = await postJson('/auth/login', { email, password })
  if (!data?.token || !data?.user || typeof data.user.role !== 'string') {
    throw new Error('Phản hồi đăng nhập từ Backend thiếu thông tin phiên hợp lệ.')
  }
  return data
}

export async function registerAccount({ email, password, name, phone, role }) {
  return postJson('/auth/register', { email, password, name, phone, role })
}
