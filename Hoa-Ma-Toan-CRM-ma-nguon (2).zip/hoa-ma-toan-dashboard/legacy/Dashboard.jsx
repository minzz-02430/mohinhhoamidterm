import { useEffect, useRef, useState } from 'react'
import useLegacyDashboard from './useLegacyDashboard'
import './Dashboard.css'
import '../modules/modules.css'
import CrmModule from '../modules/CrmModule'
import EducationModule from '../modules/EducationModule'
import HrModule from '../modules/HrModule'
import SupportModule from '../modules/SupportModule'
import { resetStore } from '../modules/store'
import logo from '../assets/logo.png'
import logoFull from '../assets/logo-full.png'

function Dashboard() {
  const rootRef = useRef(null)
  const [chartReady, setChartReady] = useState(() => Boolean(window.Chart))
  const [revenueData, setRevenueData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [revenueError, setRevenueError] = useState('')
  const {
    roleTitles, roleAvatars, roleNavigation, session, activeRole, activeTab, parentView, authView, toastMessage,
    authMessages, loginRole, loginUsername, loginPassword, showPassword,
    rememberLogin, selectedChildInfo, financeTab, aiOpen, aiInput,
    aiMessages, aiPending, setActiveTab, setParentView, setFinanceTab, setAiInput, setToastMessage, handleClick, handleChange,
    handleSubmit, handleKeyDown,
  } = useLegacyDashboard()
  const canViewAdminModules = activeRole === 'admin' || activeRole === 'manager'

  useEffect(() => {
    if (activeRole !== 'admin') {
      setLoading(false)
      return undefined
    }

    const token = window.localStorage.getItem('token')
    if (!token) {
      // Đăng nhập demo không có JWT: hiển thị số minh họa khớp bản Figma thay vì báo lỗi.
      setRevenueData({ month: '10/2026 (số liệu demo)', totalRevenue: 270000000 })
      setRevenueError('')
      setLoading(false)
      return undefined
    }

    const controller = new AbortController()
    setLoading(true)
    setRevenueError('')

    async function loadRevenue() {
      try {
        const response = await fetch('http://localhost:3000/api/v1/finance/dashboard/revenue', {
          headers: {
            Accept: 'application/json',
            Authorization: `Bearer ${token}`,
          },
          signal: controller.signal,
        })
        const result = await response.json()

        if (!response.ok) {
          throw new Error(result.message || `Không thể tải doanh thu (HTTP ${response.status}).`)
        }
        if (
          result.status !== 'success'
          || typeof result.month !== 'string'
          || !Number.isFinite(Number(result.totalRevenue))
        ) {
          throw new Error('Dữ liệu doanh thu trả về không đúng định dạng.')
        }

        setRevenueData(result)
      } catch (error) {
        if (error.name !== 'AbortError') {
          setRevenueData(null)
          setRevenueError(error.message || 'Không thể tải doanh thu tháng này.')
        }
      } finally {
        if (!controller.signal.aborted) setLoading(false)
      }
    }

    loadRevenue()
    return () => controller.abort()
  }, [activeRole])

  useEffect(() => {
  }, [])

  useEffect(() => {
    const fontLinks = [
      ['legacy-vietnam-font', 'https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700;800&display=swap'],
      ['legacy-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css'],
    ]
    const addedLinks = fontLinks
      .filter(([id]) => !document.getElementById(id))
      .map(([id, href]) => {
        const link = document.createElement('link')
        link.id = id
        link.rel = 'stylesheet'
        link.href = href
        document.head.appendChild(link)
        return link
      })

    if (window.Chart) return () => addedLinks.forEach(link => link.remove())

    const script = document.createElement('script')
    script.src = 'https://cdn.jsdelivr.net/npm/chart.js@4.4.9/dist/chart.umd.min.js'
    script.async = true
    script.onload = () => setChartReady(true)
    script.onerror = () => {
      setToastMessage('Biểu đồ chưa tải được. Kiểm tra kết nối mạng rồi tải lại trang.')
      console.error('Không thể tải Chart.js cho dashboard demo.')
    }
    document.head.appendChild(script)

    return () => {
      script.onload = null
      script.onerror = null
      script.remove()
      addedLinks.forEach(link => link.remove())
    }
  }, [setToastMessage])

  useEffect(() => {
    if (!chartReady || !rootRef.current) return undefined

    const baseOptions = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: { usePointStyle: true, boxWidth: 7, padding: 18, font: { family: 'Be Vietnam Pro', size: 10 } },
        },
      },
      scales: {
        x: { grid: { display: false }, ticks: { color: '#64748b', font: { size: 10 } } },
        y: { beginAtZero: true, grid: { color: '#f1f5f9' }, ticks: { color: '#94a3b8', font: { size: 10 } } },
      },
    }
    const chartConfigs = [
      ['admin-week-chart', {
        type: 'bar',
        data: {
          labels: ['Tuần 1', 'Tuần 2', 'Tuần 3', 'Tuần 4'],
          datasets: [
            { label: 'Doanh thu', data: [62, 70, 76, 83], backgroundColor: '#fdba74', borderRadius: 5 },
            { label: 'Thu học phí', data: [68, 74, 81, 91], backgroundColor: '#f97316', borderRadius: 5 },
          ],
        },
        options: { ...baseOptions, scales: { ...baseOptions.scales, y: { ...baseOptions.scales.y, suggestedMax: 100 } } },
      }],
      ['finance-chart', {
        type: 'bar',
        data: {
          labels: ['Tháng 5', 'Tháng 6', 'Tháng 7', 'Tháng 8', 'Tháng 9', 'Tháng 10'],
          datasets: [
            { label: 'Thu', data: [175, 215, 255, 195, 235, 350], backgroundColor: '#22c55e', borderRadius: 5 },
            { label: 'Chi', data: [115, 135, 155, 175, 145, 120], backgroundColor: '#dc4b3e', borderRadius: 5 },
          ],
        },
        options: { ...baseOptions, scales: { ...baseOptions.scales, y: { ...baseOptions.scales.y, suggestedMax: 400 } } },
      }],
      ['growth-chart', {
        type: 'line',
        data: {
          labels: ['Tháng 5', 'Tháng 6', 'Tháng 7', 'Tháng 8', 'Tháng 9', 'Tháng 10'],
          datasets: [
            { label: 'Học viên', data: [310, 338, 360, 385, 418, 450], borderColor: '#f97316', backgroundColor: '#ffedd5', fill: true, tension: 0.38, yAxisID: 'y' },
            { label: 'Doanh thu (triệu)', data: [190, 210, 235, 260, 288, 320], borderColor: '#3b82f6', tension: 0.38, yAxisID: 'y1' },
          ],
        },
        options: { ...baseOptions, scales: { ...baseOptions.scales, y1: { position: 'right', beginAtZero: true, grid: { drawOnChartArea: false } } } },
      }],
      ['course-chart', {
        type: 'doughnut',
        data: {
          labels: ['Toán Tiểu học', 'Toán THCS', 'Toán THPT'],
          datasets: [{ data: [30, 45, 25], backgroundColor: ['#f97316', '#fb923c', '#22c55e'], borderWidth: 0, hoverOffset: 5 }],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          cutout: '68%',
          plugins: {
            legend: {
              position: 'bottom',
              labels: { usePointStyle: true, boxWidth: 8, padding: 15, font: { family: 'Be Vietnam Pro', size: 10 } },
            },
          },
        },
      }],
      ['parent-score-chart', {
        type: 'bar',
        data: {
          labels: ['T8', 'T9', 'T10', 'T11', 'T12'],
          datasets: [
            { label: 'Minh Anh', data: [8.2, 8.6, 9.0, 8.8, 9.3], backgroundColor: '#f97316', borderRadius: 4 },
            { label: 'Trung bình lớp', data: [7.6, 7.8, 8.1, 7.9, 8.2], backgroundColor: '#cbd5e1', borderRadius: 4 },
          ],
        },
        options: { ...baseOptions, scales: { ...baseOptions.scales, y: { ...baseOptions.scales.y, min: 0, max: 10 } } },
      }],
    ]
    const charts = chartConfigs.flatMap(([id, config]) => {
      const canvas = rootRef.current.querySelector(`#${id}`)
      return canvas ? [new window.Chart(canvas, config)] : []
    })

    return () => charts.forEach(chart => chart.destroy())
  }, [activeRole, activeTab, chartReady, financeTab, parentView])

  return (
    <div ref={rootRef} className="legacy-dashboard" data-active-role={activeRole} data-active-tab={activeTab} data-parent-view={parentView} data-finance-tab={financeTab} data-auth-view={authView} data-authenticated={Boolean(session)} onClick={handleClick} onChange={handleChange} onSubmit={handleSubmit} onKeyDown={handleKeyDown}>
    
  
    <section className={`auth-screen${session ? " hidden" : ""}`} id={"auth-screen"} data-auth-label={authView} aria-label={"Đăng nhập hệ thống"}>
      
    
      <div className={"auth-card"}>
        
      
        <aside className={"auth-art"}>
          <article className={"auth-hero"}>
            <span className={"auth-hero-tag"}><i className={"fa-solid fa-school"} aria-hidden="true"></i>Mạng lưới 5 cơ sở</span>
            <h2>Hòa Ma Toán CRM</h2>
            <p>Một hệ thống cho tuyển sinh, học vụ, tài chính và chăm sóc phụ huynh, dùng chung một mã học viên xuyên suốt.</p>
            <div className={"auth-stats"}>
              <div><strong>5</strong><span>cơ sở tại Hà Nội</span></div>
              <div><strong>15+</strong><span>năm luyện thi</span></div>
            </div>
          </article>
          <article className={"auth-feature"}>
            <span className={"auth-feature-icon hm-green"}><i className={"fa-solid fa-user-plus"} aria-hidden="true"></i></span>
            <div><strong>Tuyển sinh không sót lead</strong><p>Pipeline theo cơ sở và kênh, tự phát hiện lead trùng số điện thoại.</p></div>
          </article>
          <article className={"auth-feature"}>
            <span className={"auth-feature-icon hm-amber"}><i className={"fa-solid fa-calendar-check"} aria-hidden="true"></i></span>
            <div><strong>Xếp lịch tự quét xung đột</strong><p>Trùng phòng hay trùng giáo viên được chặn ngay khi xếp thời khóa biểu.</p></div>
          </article>
          <article className={"auth-feature"}>
            <span className={"auth-feature-icon hm-blue"}><i className={"fa-solid fa-comments"} aria-hidden="true"></i></span>
            <div><strong>Nhận xét 24 giờ và chatbot 24/7</strong><p>Phụ huynh nhận nhận xét sau mỗi buổi; chatbot tự tạo yêu cầu hỗ trợ.</p></div>
          </article>
          <article className={"auth-banner"}>
            <span><i className={"fa-solid fa-location-dot"} aria-hidden="true"></i>Năm học 2026 – 2027</span>
            <strong>Đang mở ghi danh các lớp khối 2–5, 6–9 và 10–12</strong>
          </article>
        </aside>
        
      
        <div className={"auth-form-side"}>
          
        
          <section className={`auth-pane${authView === "login" ? "" : " hidden"}`} id={"auth-login-pane"}>
            
          
            <img className={"auth-logo"} src={logoFull} alt={"Hòa Ma Toán, 15+ năm kinh nghiệm luyện thi"} />
            <span className={"auth-pill"}><i className={"fa-solid fa-bolt"} aria-hidden="true"></i>Hệ thống quản lý trung tâm</span>
            <h2>
              Chào mừng trở lại!
            </h2>
            <p className={"auth-subtitle"}>
              Đăng nhập để điều hành tuyển sinh, lớp học và chăm sóc phụ huynh trên cả 5 cơ sở.
            </p>
            
          
            <form id={"login-form"}>
              
            
              <div className={"auth-field"}>
                <label htmlFor={"login-username"}>
                  Tên đăng nhập
                </label>
                <input id={"login-username"} name={"username"} autoComplete={"username"} required placeholder={"Nhập tên đăng nhập"} value={loginUsername} onChange={handleChange} />
              </div>
              
            
              <div className={"auth-field"}>
                <label htmlFor={"login-password"}>
                  Mật khẩu
                </label>
                <div className={"auth-password"}>
                  <input id={"login-password"} name={"password"} type={showPassword ? "text" : "password"} autoComplete={"current-password"} required placeholder={"Nhập mật khẩu"} value={loginPassword} onChange={handleChange} />
                  <button className={"auth-show-password"} type={"button"} data-toggle-password={"login-password"}>
                    Hiện
                  </button>
                </div>
              </div>
              
            
              <div className={"auth-field"}>
                <label htmlFor={"login-role"}>
                  Vai trò
                </label>
                <select id={"login-role"} name={"role"} required value={loginRole} onChange={handleChange}>
                  <option value={"admin"}>
                    Ban giám đốc
                  </option>
                  <option value={"manager"}>
                    Quản lý cơ sở
                  </option>
                  <option value={"teacher"}>
                    Giáo viên
                  </option>
                  <option value={"parent"}>
                    Phụ huynh
                  </option>
                </select>
                <small style={{"color": "var(--text-desc)", "fontSize": "10px"}}>
                  Chọn vai trò để tự điền tài khoản demo tương ứng.
                </small>
              </div>
              
            
              <div className={"auth-options"}>
                <label>
                  <input id={"remember-login"} type={"checkbox"} checked={rememberLogin} onChange={handleChange} />
                   Ghi nhớ đăng nhập trên thiết bị này
                </label>
                <button className={"auth-link"} type={"button"} data-auth-view={"forgot"}>
                  Quên mật khẩu?
                </button>
              </div>
              
            
              <button className={"auth-submit"} type={"submit"}>
                Đăng nhập 
                <i className={"fa-solid fa-arrow-right-to-bracket"}></i>
              </button>
              
            
              <p className={`auth-message${authMessages.login?.success ? " success" : ""}`} id={"login-message"} role={"status"} aria-live={"polite"}>{authMessages.login?.message}</p>
              
          
            </form>
            
          
            <p className={"auth-switch"}>
              Chưa có tài khoản? 
              <button className={"auth-link"} type={"button"} data-auth-view={"register"}>
                Đăng ký ngay
              </button>
            </p>
            
          
            <div className={"demo-hint"}>
              <strong>
                Tài khoản demo:
              </strong>
               admin / quanly / giaovien / phuhuynh · Mật khẩu: 
              <strong>
                123456
              </strong>
              <br />
              Dữ liệu xác thực chỉ lưu trong trình duyệt này, không dùng cho tài khoản thật.
            </div>
            
        
          </section>
          
        
          <section className={`auth-pane${authView === "register" ? "" : " hidden"}`} id={"auth-register-pane"}>
            
          
            <h2>
              Tạo tài khoản
            </h2>
            <p className={"auth-subtitle"}>
              Đăng ký tài khoản demo để trải nghiệm cổng quản lý.
            </p>
            
          
            <form id={"register-form"}>
              
            
              <div className={"auth-columns"}>
                
              
                <div className={"auth-field"}>
                  <label htmlFor={"register-name"}>
                    Họ và tên
                  </label>
                  <input id={"register-name"} required autoComplete={"name"} placeholder={"Nguyễn Văn An"} />
                </div>
                
              
                <div className={"auth-field"}>
                  <label htmlFor={"register-role"}>
                    Vai trò
                  </label>
                  <select id={"register-role"}>
                    <option value={"manager"}>
                      Quản lý cơ sở
                    </option>
                    <option value={"teacher"}>
                      Giáo viên
                    </option>
                    <option value={"parent"}>
                      Phụ huynh
                    </option>
                    <option value={"admin"}>
                      Ban giám đốc
                    </option>
                  </select>
                </div>
                
            
              </div>
              
            
              <div className={"auth-field"}>
                <label htmlFor={"register-username"}>
                  Tên đăng nhập
                </label>
                <input id={"register-username"} required minLength={"3"} pattern={"[A-Za-z0-9._\\-]+"} autoComplete={"username"} placeholder={"Tối thiểu 3 ký tự, không dấu cách"} />
              </div>
              
            
              <div className={"auth-field"}>
                <label htmlFor={"register-email"}>
                  Email khôi phục
                </label>
                <input id={"register-email"} required type={"email"} autoComplete={"email"} placeholder={"ban@example.com"} />
              </div>
              
            
              <div className={"auth-columns"}>
                
              
                <div className={"auth-field"}>
                  <label htmlFor={"register-password"}>
                    Mật khẩu
                  </label>
                  <input id={"register-password"} required type={"password"} minLength={"6"} autoComplete={"new-password"} placeholder={"Ít nhất 6 ký tự"} />
                </div>
                
              
                <div className={"auth-field"}>
                  <label htmlFor={"register-confirm"}>
                    Nhập lại mật khẩu
                  </label>
                  <input id={"register-confirm"} required type={"password"} minLength={"6"} autoComplete={"new-password"} placeholder={"Xác nhận mật khẩu"} />
                </div>
                
            
              </div>
              
            
              <button className={"auth-submit"} type={"submit"}>
                Tạo tài khoản
              </button>
              
            
              <p className={`auth-message${authMessages.register?.success ? " success" : ""}`} id={"register-message"} role={"status"} aria-live={"polite"}>{authMessages.register?.message}</p>
              
          
            </form>
            
          
            <p className={"auth-switch"}>
              Đã có tài khoản? 
              <button className={"auth-link"} type={"button"} data-auth-view={"login"}>
                Quay lại đăng nhập
              </button>
            </p>
            
        
          </section>
          
        
          <section className={`auth-pane${authView === "forgot" ? "" : " hidden"}`} id={"auth-forgot-pane"}>
            
          
            <h2>
              Khôi phục mật khẩu
            </h2>
            <p className={"auth-subtitle"}>
              Nhập tên đăng nhập và email đã đăng ký để xác minh tài khoản.
            </p>
            
          
            <form id={"forgot-form"}>
              
            
              <div className={"auth-field"}>
                <label htmlFor={"forgot-username"}>
                  Tên đăng nhập
                </label>
                <input id={"forgot-username"} required autoComplete={"username"} placeholder={"Tên đăng nhập của bạn"} />
              </div>
              
            
              <div className={"auth-field"}>
                <label htmlFor={"forgot-email"}>
                  Email khôi phục
                </label>
                <input id={"forgot-email"} type={"email"} required autoComplete={"email"} placeholder={"Email đã đăng ký"} />
              </div>
              
            
              <button className={"auth-submit"} type={"submit"}>
                Xác minh tài khoản
              </button>
              
            
              <p className={`auth-message${authMessages.forgot?.success ? " success" : ""}`} id={"forgot-message"} role={"status"} aria-live={"polite"}>{authMessages.forgot?.message}</p>
              
          
            </form>
            
          
            <p className={"auth-switch"}>
              Nhớ mật khẩu? 
              <button className={"auth-link"} type={"button"} data-auth-view={"login"}>
                Quay lại đăng nhập
              </button>
            </p>
            
        
          </section>
          
        
          <section className={`auth-pane${authView === "reset" ? "" : " hidden"}`} id={"auth-reset-pane"}>
            
          
            <h2>
              Cấp mật khẩu mới
            </h2>
            <p className={"auth-subtitle"} id={"reset-account-label"}>
              Tạo mật khẩu mới cho tài khoản đã xác minh.
            </p>
            
          
            <form id={"reset-form"}>
              
            
              <div className={"auth-field"}>
                <label htmlFor={"reset-password"}>
                  Mật khẩu mới
                </label>
                <input id={"reset-password"} required type={"password"} minLength={"6"} autoComplete={"new-password"} placeholder={"Ít nhất 6 ký tự"} />
              </div>
              
            
              <div className={"auth-field"}>
                <label htmlFor={"reset-confirm"}>
                  Xác nhận mật khẩu mới
                </label>
                <input id={"reset-confirm"} required type={"password"} minLength={"6"} autoComplete={"new-password"} placeholder={"Nhập lại mật khẩu mới"} />
              </div>
              
            
              <button className={"auth-submit"} type={"submit"}>
                Cập nhật mật khẩu
              </button>
              
            
              <p className={`auth-message${authMessages.reset?.success ? " success" : ""}`} id={"reset-message"} role={"status"} aria-live={"polite"}>{authMessages.reset?.message}</p>
              
          
            </form>
            
        
          </section>
          
      
        </div>
        
    
      </div>
      
  
    </section>
    
  
    <header className={`topbar${session ? "" : " hidden"}`}>
      
    
      <a className={"brand"} href={"#"} aria-label={"HÒA MA TOÁN"}>
        <img className={"brand-logo"} src={logo} alt={""} />
      </a>
      
    
      <div className={"context"}>
        <strong>
          Cơ sở 1 · Nguyễn Chí Thanh
        </strong>
        Năm học 2026–2027
      </div>
      
    
      <div className={"top-spacer"}></div>
      
    
      <label className={"search"}>
        <i className={"fa-solid fa-magnifying-glass"}></i>
        <input id={"global-search"} type={"search"} placeholder={"Tìm kiếm..."} aria-label={"Tìm kiếm"} />
      </label>
      
    
      <button className={"icon-button"} id={"notification-button"} type={"button"} aria-label={"Thông báo"}>
        <i className={"fa-regular fa-bell"}></i>
        <span className={"dot"}></span>
      </button>
      
    
      <div className={"user-chip"}>
        <span className={"avatar"} id={"top-avatar"}>
          {roleAvatars[activeRole]}
        </span>
        <span className={"user-meta"}>
          <strong id={"top-role"}>
            {roleTitles[activeRole]}
          </strong>
          <small id={"top-name"}>
            {session?.name || roleTitles[activeRole]}
          </small>
        </span>
      </div>
      
    
      <label className={"role-switcher"} htmlFor={"role-selector"}>
        <span>
          Đang xem
        </span>
        
      
        <select id={"role-selector"} aria-label={"Chọn vai trò"} value={activeRole} onChange={handleChange}>
          
        
          <option value={"admin"}>
            Ban giám đốc
          </option>
          
        
          <option value={"manager"}>
            Quản lý cơ sở
          </option>
          
        
          <option value={"teacher"}>
            Giáo viên
          </option>
          
        
          <option value={"parent"}>
            Phụ huynh
          </option>
          
      
        </select>
        
    
      </label>
      
    
      <button className={"logout-button"} id={"btn-logout"} type={"button"}>
        <i className={"fa-solid fa-arrow-right-from-bracket"}></i>
         Đăng xuất
      </button>
      
    
      <nav className={"parent-topnav"} id={"parent-topnav"} aria-label={"Điều hướng phụ huynh"} data-react-visible={activeRole === "parent"}>
        
      
        <button className={`parent-nav-button${parentView === "schedule" ? " active" : ""}`} data-parent-view={"schedule"} type={"button"}>
          <i className={"fa-regular fa-calendar"}></i>
           Lịch học
        </button>
        
      
        <button className={`parent-nav-button${parentView === "fees" ? " active" : ""}`} data-parent-view={"fees"} type={"button"}>
          <i className={"fa-solid fa-receipt"}></i>
           Học phí
        </button>
        
      
        <button className={`parent-nav-button${parentView === "results" ? " active" : ""}`} data-parent-view={"results"} type={"button"}>
          <i className={"fa-solid fa-chart-line"}></i>
           Kết quả
        </button>
        
      
        <button className={`parent-nav-button${parentView === "children" ? " active" : ""}`} data-parent-view={"children"} type={"button"}>
          <i className={"fa-solid fa-children"}></i>
           Danh sách con
        </button>
        
    
      </nav>
      
  
    </header>
    

  
    <div className={`app-layout${session ? "" : " hidden"}${activeRole === "parent" ? " parent-layout" : ""}`} id={"app-layout"}>
      
    
      <aside className={"sidebar"} id={"sidebar"}>
        
      
        <p className={"nav-caption"}>
          KHÔNG GIAN LÀM VIỆC
        </p>
        
      
        <nav className={"nav-list"} id={"role-navigation"} aria-label={"Điều hướng chính"}>
          {(roleNavigation[activeRole] || []).map(([key, label, icon]) => (
            <button
              className={`nav-item${(activeRole === 'parent' ? parentView : activeTab) === key ? ' active' : ''}`}
              key={key}
              type="button"
              onClick={() => {
                if (activeRole === 'parent') {
                  setParentView(key)
                } else {
                  setActiveTab(key)
                  if (key === 'finance') setFinanceTab('cashflow')
                }
              }}
            >
              <i className={`fa-solid ${icon}`} aria-hidden="true" />
              <span>{label}</span>
            </button>
          ))}
        </nav>
        
      
        <div className={"sidebar-bottom"}>
          <strong>
            <i className={"fa-regular fa-calendar"}></i>
             Năm học hiện tại
          </strong>
          <br />
          2026 – 2027
          <br />
          <span>
            ● Hệ thống đang hoạt động
          </span>
        </div>
        
    
      </aside>
      
    
      <main className={"main"}>
        
      
        <div className={`role-view${canViewAdminModules ? " active" : ""}`} id={"role-admin"} data-react-visible={canViewAdminModules}>
          
        
<section className={`tab-panel${canViewAdminModules && activeTab === "dashboard" ? " active" : ""}`} id={"admin-dashboard"} data-react-visible={canViewAdminModules && activeTab === "dashboard"}>
            
          
            <div className={"page-heading"}>
              <div>
                <h1>
                  Dashboard tổng quan
                </h1>
                <p>
                  Tổng quan hoạt động trung tâm · Cập nhật lúc 08:30 hôm nay
                </p>
              </div>
              <div className={"actions"}>
                <button className={"button"} data-action={"export"}>
                  <i className={"fa-solid fa-download"}></i>
                   Xuất báo cáo
                </button>
                <button className={"button primary"} data-action={"add-student"}>
                  <i className={"fa-solid fa-plus"}></i>
                   Thêm học viên
                </button>
              </div>
            </div>
            
          
            <div className={"kpi-grid"}>
              
            
              <article className={"card kpi"}>
                <span className={"kpi-icon"}>
                  <i className={"fa-solid fa-user-graduate"}></i>
                </span>
                <div className={"kpi-label"}>
                  Học viên đang học
                </div>
                <div className={"kpi-value"}>
                  248
                </div>
                <div className={"kpi-note"}>
                  <i className={"fa-solid fa-arrow-trend-up"}></i>
                   12% so với tháng trước
                </div>
              </article>
              
            
              <article className={"card kpi"}>
                <span className={"kpi-icon"}>
                  <i className={"fa-solid fa-wallet"}></i>
                </span>
                <div className={"kpi-label"}>
                  Doanh thu tháng
                </div>
                <div className={"kpi-value"} aria-live={"polite"}>
                  {loading
                    ? 'Đang tải...'
                    : revenueError
                      ? '—'
                      : revenueData
                        ? new Intl.NumberFormat('vi-VN', {
                          style: 'currency',
                          currency: 'VND',
                          maximumFractionDigits: 0,
                        }).format(Number(revenueData.totalRevenue))
                        : '—'}
                </div>
                <div className={`kpi-note${revenueError ? ' warn' : ''}`} role={revenueError ? 'alert' : 'status'}>
                  {revenueError || (revenueData ? `Doanh thu tháng ${revenueData.month}` : 'Đang chờ dữ liệu doanh thu.')}
                </div>
              </article>
              
            
              <article className={"card kpi"}>
                <span className={"kpi-icon"}>
                  <i className={"fa-solid fa-file-invoice-dollar"}></i>
                </span>
                <div className={"kpi-label"}>
                  Học phí chưa thu
                </div>
                <div className={"kpi-value"}>
                  30 
                  <small style={{"fontSize": "13px"}}>
                    triệu
                  </small>
                </div>
                <div className={"kpi-note warn"}>
                  <i className={"fa-solid fa-circle-exclamation"}></i>
                   8 khoản cần nhắc phí
                </div>
              </article>
              
            
              <article className={"card kpi"}>
                <span className={"kpi-icon"}>
                  <i className={"fa-solid fa-people-group"}></i>
                </span>
                <div className={"kpi-label"}>
                  Lương chờ duyệt
                </div>
                <div className={"kpi-value"}>
                  48 
                  <small style={{"fontSize": "13px"}}>
                    triệu
                  </small>
                </div>
                <div className={"kpi-note warn"}>
                  <i className={"fa-regular fa-clock"}></i>
                   12 nhân sự · hạn 31/10
                </div>
              </article>
              
          
            </div>
            
          
            <div className={"grid-2"}>
              
            
              <article className={"card"}>
                <h2 className={"card-title"}>
                  Doanh thu &amp; thu học phí theo tuần 
                  <span className={"muted"}>
                    Đơn vị: triệu đồng
                  </span>
                </h2>
                <div className={"chart-wrap"}>
                  <canvas id={"admin-week-chart"} aria-label={"Biểu đồ doanh thu và thu học phí theo tuần"}></canvas>
                </div>
              </article>
              
            
              <article className={"card"}>
                <h2 className={"card-title"}>
                  Cơ cấu học viên 
                  <span className={"muted"}>
                    248 học viên
                  </span>
                </h2>
                
              
                <div className={"progress-row"}>
                  <div className={"progress-meta"}>
                    <span>
                      Khối 1–5
                    </span>
                    <span>
                      92 học viên · 37%
                    </span>
                  </div>
                  <div className={"progress"}>
                    <span style={{"width": "37%"}}></span>
                  </div>
                </div>
                
              
                <div className={"progress-row"}>
                  <div className={"progress-meta"}>
                    <span>
                      Khối 6–9
                    </span>
                    <span>
                      84 học viên · 34%
                    </span>
                  </div>
                  <div className={"progress blue"}>
                    <span style={{"width": "34%"}}></span>
                  </div>
                </div>
                
              
                <div className={"progress-row"}>
                  <div className={"progress-meta"}>
                    <span>
                      Khối 10–12
                    </span>
                    <span>
                      72 học viên · 29%
                    </span>
                  </div>
                  <div className={"progress green"}>
                    <span style={{"width": "29%"}}></span>
                  </div>
                </div>
                
              
                <div style={{"paddingTop": "12px", "color": "var(--text-desc)", "fontSize": "10px"}}>
                  Tỷ lệ duy trì học viên 
                  <strong style={{"float": "right", "color": "var(--green)"}}>
                    96,2%
                  </strong>
                </div>
                
            
              </article>
              
          
            </div>
            
          
            <div className={"grid-2"}>
              
            
              <article className={"card"}>
                <h2 className={"card-title"}>
                  Học phí quá hạn 
                  <span className={"tag red"}>
                    5 khoản cần xử lý
                  </span>
                </h2>
                <div className={"table-wrap"}>
                  <table>
                    <thead>
                      <tr>
                        <th>
                          HỌC VIÊN
                        </th>
                        <th>
                          LỚP
                        </th>
                        <th>
                          SỐ TIỀN
                        </th>
                        <th>
                          QUÁ HẠN
                        </th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      
              
                      <tr>
                        <td>
                          <div className={"table-name"}>
                            <span className={"mini-avatar"}>
                              MA
                            </span>
                            <strong>
                              Nguyễn Minh Anh
                            </strong>
                          </div>
                        </td>
                        <td>
                          Toán 5A
                        </td>
                        <td>
                          <strong>
                            4.800.000đ
                          </strong>
                        </td>
                        <td>
                          <span className={"tag red"}>
                            8 ngày
                          </span>
                        </td>
                        <td>
                          <button className={"button small"} data-action={"remind"}>
                            Nhắc phí
                          </button>
                        </td>
                      </tr>
                      
              
                      <tr>
                        <td>
                          <div className={"table-name"}>
                            <span className={"mini-avatar"}>
                              HN
                            </span>
                            <strong>
                              Trần Hoàng Nam
                            </strong>
                          </div>
                        </td>
                        <td>
                          Toán 12A
                        </td>
                        <td>
                          <strong>
                            4.200.000đ
                          </strong>
                        </td>
                        <td>
                          <span className={"tag red"}>
                            6 ngày
                          </span>
                        </td>
                        <td>
                          <button className={"button small"} data-action={"remind"}>
                            Nhắc phí
                          </button>
                        </td>
                      </tr>
                      
              
                      <tr>
                        <td>
                          <div className={"table-name"}>
                            <span className={"mini-avatar"}>
                              LB
                            </span>
                            <strong>
                              Lê Bảo Ngọc
                            </strong>
                          </div>
                        </td>
                        <td>
                          Toán 8B
                        </td>
                        <td>
                          <strong>
                            3.800.000đ
                          </strong>
                        </td>
                        <td>
                          <span className={"tag red"}>
                            3 ngày
                          </span>
                        </td>
                        <td>
                          <button className={"button small"} data-action={"remind"}>
                            Nhắc phí
                          </button>
                        </td>
                      </tr>
                      
            
                    </tbody>
                  </table>
                </div>
              </article>
              
            
              <div className={"stack"}>
                
              
                <article className={"card"}>
                  <h2 className={"card-title"}>
                    Kỳ lương chờ duyệt 
                    <span className={"tag"}>
                      Tháng 10
                    </span>
                  </h2>
                  <div className={"list-row"}>
                    <div className={"list-main"}>
                      <strong>
                        12 phiếu lương giáo viên
                      </strong>
                      <small>
                        Hạn duyệt 31/10/2026
                      </small>
                    </div>
                    <button className={"button small"} data-action={"review"}>
                      Duyệt
                    </button>
                  </div>
                </article>
                
              
                <article className={"card"}>
                  <h2 className={"card-title"}>
                    Lớp học sắp tới 
                    <span className={"muted"}>
                      Hôm nay
                    </span>
                  </h2>
                  <div className={"list-row"}>
                    <div className={"list-main"}>
                      <strong>
                        18:00 · Toán 9A
                      </strong>
                      <small>
                        GV Nguyễn Thu Hà · Phòng 201
                      </small>
                    </div>
                    <span className={"tag green"}>
                      Đúng lịch
                    </span>
                  </div>
                  <div className={"list-row"}>
                    <div className={"list-main"}>
                      <strong>
                        19:30 · Toán 12A
                      </strong>
                      <small>
                        GV Trần Văn Anh · Phòng 203
                      </small>
                    </div>
                    <span className={"tag blue"}>
                      Còn 40 phút
                    </span>
                  </div>
                </article>
                
            
              </div>
              
          
            </div>
            
        
          </section>
          
        
<section className={`tab-panel${canViewAdminModules && activeTab === "crm" ? " active" : ""}`} id={"admin-crm"} data-react-visible={canViewAdminModules && activeTab === "crm"}>
            {activeTab === "crm" && <CrmModule role={activeRole} notify={setToastMessage} />}
          </section>
          
        
<section className={`tab-panel${canViewAdminModules && activeTab === "education" ? " active" : ""}`} id={"admin-education"} data-react-visible={canViewAdminModules && activeTab === "education"}>
            {activeTab === "education" && <EducationModule role={activeRole} notify={setToastMessage} />}
          </section>
          
        
<section className={`tab-panel${canViewAdminModules && activeTab === "hr" ? " active" : ""}`} id={"admin-hr"} data-react-visible={canViewAdminModules && activeTab === "hr"}>
            {activeTab === "hr" && <HrModule role={activeRole} notify={setToastMessage} />}
          </section>
          
        
<section className={`tab-panel${canViewAdminModules && activeTab === "finance" ? " active" : ""}`} id={"admin-finance"} data-react-visible={canViewAdminModules && activeTab === "finance"}>
            
          
            <div className={"page-heading"}>
              <div>
                <h1>
                  Tài chính &amp; Kế toán
                </h1>
                <p>
                  Quản lý dòng tiền, thu chi và công nợ của trung tâm.
                </p>
              </div>
              <div className={"actions"}>
                <button className={"button"} data-action={"create-expense"}>
                  <i className={"fa-solid fa-minus"}></i>
                   Tạo phiếu chi
                </button>
                <button className={"button primary"} data-action={"create-income"}>
                  <i className={"fa-solid fa-plus"}></i>
                   Tạo phiếu thu
                </button>
              </div>
            </div>
            
          
            <div className={"subnav"} aria-label={"Phân hệ tài chính"}>
              <button className={"button active"} data-finance-tab={"cashflow"}>
                Báo cáo Dòng tiền
              </button>
              <button className={"button"} data-finance-tab={"income"}>
                Quản lý Thu
              </button>
              <button className={"button"} data-finance-tab={"expense"}>
                Quản lý Chi
              </button>
              <button className={"button"} data-finance-tab={"debt"}>
                Công nợ
              </button>
            </div>
            
          
<div className={`tab-panel${canViewAdminModules && activeTab === "finance" && financeTab === "cashflow" ? " active" : ""}`} id={"finance-cashflow"} data-react-visible={canViewAdminModules && activeTab === "finance" && financeTab === "cashflow"}>
              <div className={"kpi-grid"}>
                <article className={"card kpi"}>
                  <div className={"kpi-label"}>
                    Tổng Thu
                  </div>
                  <div className={"kpi-value"} style={{"color": "var(--green)"}}>
                    350M
                  </div>
                  <div className={"kpi-note"}>
                    Học phí và dịch vụ tháng này
                  </div>
                </article>
                <article className={"card kpi"}>
                  <div className={"kpi-label"}>
                    Tổng Chi
                  </div>
                  <div className={"kpi-value"} style={{"color": "var(--red)"}}>
                    120M
                  </div>
                  <div className={"kpi-note"}>
                    Chi hoạt động, lương và vận hành
                  </div>
                </article>
                <article className={"card kpi"}>
                  <div className={"kpi-label"}>
                    Lợi nhuận gộp
                  </div>
                  <div className={"kpi-value"}>
                    230M
                  </div>
                  <div className={"kpi-note"}>
                    Chênh lệch giữa thu và chi
                  </div>
                </article>
                <article className={"card kpi"}>
                  <div className={"kpi-label"}>
                    Công nợ cần thu
                  </div>
                  <div className={"kpi-value"} style={{"color": "#d97706"}}>
                    45M
                  </div>
                  <div className={"kpi-note warn"}>
                    Cần thu từ phụ huynh và đối tác
                  </div>
                </article>
              </div>
              <article className={"card"} style={{"marginBottom": "16px"}}>
                <h2 className={"card-title"}>
                  Cân đối Thu – Chi 6 tháng gần nhất 
                  <span className={"muted"}>
                    Đơn vị: triệu đồng
                  </span>
                </h2>
                <div className={"chart-wrap"}>
                  <canvas id={"finance-chart"} aria-label={"Biểu đồ Thu Chi sáu tháng"}></canvas>
                </div>
              </article>
              <article className={"card"}>
                <h2 className={"card-title"}>
                  Lịch sử giao dịch gần đây 
                  <button className={"button small"} data-action={"export"}>
                    <i className={"fa-solid fa-download"}></i>
                     Xuất danh sách
                  </button>
                </h2>
                <div className={"table-wrap"}>
                  <table>
                    <thead>
                      <tr>
                        <th>
                          NGÀY GIAO DỊCH
                        </th>
                        <th>
                          LOẠI
                        </th>
                        <th>
                          HẠNG MỤC
                        </th>
                        <th>
                          SỐ TIỀN
                        </th>
                        <th>
                          NGƯỜI PHỤ TRÁCH
                        </th>
                        <th>
                          TRẠNG THÁI
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          28/10/2026
                        </td>
                        <td>
                          <span className={"tag green"}>
                            Thu
                          </span>
                        </td>
                        <td>
                          Học phí tháng 10 · Toán 5A
                        </td>
                        <td>
                          <strong>
                            4.800.000đ
                          </strong>
                        </td>
                        <td>
                          Nguyễn Thu Hà
                        </td>
                        <td>
                          Đã xác nhận
                        </td>
                      </tr>
                      <tr>
                        <td>
                          27/10/2026
                        </td>
                        <td>
                          <span className={"tag red"}>
                            Chi
                          </span>
                        </td>
                        <td>
                          Lương giáo viên tháng 10
                        </td>
                        <td>
                          <strong>
                            28.000.000đ
                          </strong>
                        </td>
                        <td>
                          Trần Minh Quân
                        </td>
                        <td>
                          Đã xác nhận
                        </td>
                      </tr>
                      <tr>
                        <td>
                          26/10/2026
                        </td>
                        <td>
                          <span className={"tag green"}>
                            Thu
                          </span>
                        </td>
                        <td>
                          Học phí tháng 10 · Toán 9A
                        </td>
                        <td>
                          <strong>
                            5.200.000đ
                          </strong>
                        </td>
                        <td>
                          Lê Thị Bình
                        </td>
                        <td>
                          Đã xác nhận
                        </td>
                      </tr>
                      <tr>
                        <td>
                          25/10/2026
                        </td>
                        <td>
                          <span className={"tag red"}>
                            Chi
                          </span>
                        </td>
                        <td>
                          Văn phòng phẩm
                        </td>
                        <td>
                          <strong>
                            1.250.000đ
                          </strong>
                        </td>
                        <td>
                          Nguyễn Thu Hà
                        </td>
                        <td>
                          Đã xác nhận
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </article>
            </div>
            
          
<div className={`tab-panel${canViewAdminModules && activeTab === "finance" && financeTab === "income" ? " active" : ""}`} id={"finance-income"} data-react-visible={canViewAdminModules && activeTab === "finance" && financeTab === "income"}>
              <article className={"card"}>
                <h2 className={"card-title"}>
                  Quản lý Thu 
                  <button className={"button primary small"} data-action={"create-income"}>
                    <i className={"fa-solid fa-plus"}></i>
                     Tạo phiếu thu
                  </button>
                </h2>
                <p style={{"color": "var(--text-desc)"}}>
                  Tổng thu tháng 10: 
                  <strong style={{"color": "var(--green)"}}>
                    350.000.000đ
                  </strong>
                </p>
                <div className={"table-wrap"}>
                  <table>
                    <thead>
                      <tr>
                        <th>
                          MÃ PHIẾU
                        </th>
                        <th>
                          NGÀY
                        </th>
                        <th>
                          HẠNG MỤC
                        </th>
                        <th>
                          NGƯỜI NỘP
                        </th>
                        <th>
                          SỐ TIỀN
                        </th>
                        <th>
                          TRẠNG THÁI
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          PT-1028
                        </td>
                        <td>
                          28/10/2026
                        </td>
                        <td>
                          Học phí tháng 10
                        </td>
                        <td>
                          Nguyễn Minh Anh
                        </td>
                        <td>
                          <strong>
                            4.800.000đ
                          </strong>
                        </td>
                        <td>
                          <span className={"tag green"}>
                            Đã thu
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          PT-1026
                        </td>
                        <td>
                          26/10/2026
                        </td>
                        <td>
                          Học phí tháng 10
                        </td>
                        <td>
                          Trần Hoàng Nam
                        </td>
                        <td>
                          <strong>
                            4.200.000đ
                          </strong>
                        </td>
                        <td>
                          <span className={"tag green"}>
                            Đã thu
                          </span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </article>
            </div>
            
          
<div className={`tab-panel${canViewAdminModules && activeTab === "finance" && financeTab === "expense" ? " active" : ""}`} id={"finance-expense"} data-react-visible={canViewAdminModules && activeTab === "finance" && financeTab === "expense"}>
              <article className={"card"}>
                <h2 className={"card-title"}>
                  Quản lý Chi 
                  <button className={"button primary small"} data-action={"create-expense"}>
                    <i className={"fa-solid fa-plus"}></i>
                     Tạo phiếu chi
                  </button>
                </h2>
                <p style={{"color": "var(--text-desc)"}}>
                  Tổng chi tháng 10: 
                  <strong style={{"color": "var(--red)"}}>
                    120.000.000đ
                  </strong>
                </p>
                <div className={"table-wrap"}>
                  <table>
                    <thead>
                      <tr>
                        <th>
                          MÃ PHIẾU
                        </th>
                        <th>
                          NGÀY
                        </th>
                        <th>
                          HẠNG MỤC
                        </th>
                        <th>
                          NGƯỜI NHẬN
                        </th>
                        <th>
                          SỐ TIỀN
                        </th>
                        <th>
                          TRẠNG THÁI
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          PC-1027
                        </td>
                        <td>
                          27/10/2026
                        </td>
                        <td>
                          Lương giáo viên
                        </td>
                        <td>
                          Trần Văn Anh
                        </td>
                        <td>
                          <strong>
                            28.000.000đ
                          </strong>
                        </td>
                        <td>
                          <span className={"tag green"}>
                            Đã chi
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          PC-1025
                        </td>
                        <td>
                          25/10/2026
                        </td>
                        <td>
                          Văn phòng phẩm
                        </td>
                        <td>
                          Nhà sách Tiến Thọ
                        </td>
                        <td>
                          <strong>
                            1.250.000đ
                          </strong>
                        </td>
                        <td>
                          <span className={"tag green"}>
                            Đã chi
                          </span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </article>
            </div>
            
          
<div className={`tab-panel${canViewAdminModules && activeTab === "finance" && financeTab === "debt" ? " active" : ""}`} id={"finance-debt"} data-react-visible={canViewAdminModules && activeTab === "finance" && financeTab === "debt"}>
              <article className={"card"}>
                <h2 className={"card-title"}>
                  Công nợ cần thu 
                  <span className={"tag red"}>
                    45.000.000đ
                  </span>
                </h2>
                <div className={"table-wrap"}>
                  <table>
                    <thead>
                      <tr>
                        <th>
                          HỌC VIÊN
                        </th>
                        <th>
                          LỚP
                        </th>
                        <th>
                          HẠN ĐÓNG
                        </th>
                        <th>
                          SỐ TIỀN
                        </th>
                        <th>
                          TÌNH TRẠNG
                        </th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <strong>
                            Nguyễn Minh Anh
                          </strong>
                        </td>
                        <td>
                          Toán 5A
                        </td>
                        <td>
                          20/10/2026
                        </td>
                        <td>
                          4.800.000đ
                        </td>
                        <td>
                          <span className={"tag red"}>
                            Quá hạn 8 ngày
                          </span>
                        </td>
                        <td>
                          <button className={"button small"} data-action={"remind"}>
                            Nhắc phí
                          </button>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <strong>
                            Trần Hoàng Nam
                          </strong>
                        </td>
                        <td>
                          Toán 12A
                        </td>
                        <td>
                          22/10/2026
                        </td>
                        <td>
                          4.200.000đ
                        </td>
                        <td>
                          <span className={"tag red"}>
                            Quá hạn 6 ngày
                          </span>
                        </td>
                        <td>
                          <button className={"button small"} data-action={"remind"}>
                            Nhắc phí
                          </button>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <strong>
                            Lê Bảo Ngọc
                          </strong>
                        </td>
                        <td>
                          Toán 8B
                        </td>
                        <td>
                          25/10/2026
                        </td>
                        <td>
                          3.800.000đ
                        </td>
                        <td>
                          <span className={"tag"}>
                            Quá hạn 3 ngày
                          </span>
                        </td>
                        <td>
                          <button className={"button small"} data-action={"remind"}>
                            Nhắc phí
                          </button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </article>
            </div>
            
        
          </section>
          
        
<section className={`tab-panel${canViewAdminModules && activeTab === "support" ? " active" : ""}`} id={"admin-support"} data-react-visible={canViewAdminModules && activeTab === "support"}>
            {activeTab === "support" && <SupportModule role={activeRole} notify={setToastMessage} me={session?.name || "Quản lý cơ sở"} />}
          </section>
          
        
<section className={`tab-panel${canViewAdminModules && activeTab === "reports" ? " active" : ""}`} id={"admin-reports"} data-react-visible={canViewAdminModules && activeTab === "reports"}>
            <div className={"page-heading"}>
              <div>
                <h1>
                  Tổng quan Báo cáo
                </h1>
                <p>
                  Báo cáo hoạt động và chất lượng đào tạo toàn trung tâm.
                </p>
              </div>
              <div className={"actions"}>
                <button className={"button"} data-action={"export"}>
                  <i className={"fa-solid fa-file-excel"}></i>
                   Xuất báo cáo
                </button>
              </div>
            </div>
            <div className={"kpi-grid"}>
              <article className={"card kpi"}>
                <div className={"kpi-label"}>
                  Học viên đang theo học
                </div>
                <div className={"kpi-value"}>
                  450
                </div>
                <div className={"kpi-note"}>
                  Tăng 12% so với kỳ trước
                </div>
              </article>
              <article className={"card kpi"}>
                <div className={"kpi-label"}>
                  Tổng số lớp mở
                </div>
                <div className={"kpi-value"}>
                  32
                </div>
                <div className={"kpi-note"}>
                  14 học sinh bình quân
                </div>
              </article>
              <article className={"card kpi"}>
                <div className={"kpi-label"}>
                  Hiệu suất lấp đầy
                </div>
                <div className={"kpi-value"}>
                  85%
                </div>
                <div className={"kpi-note"}>
                  Tỷ lệ tốt trong kỳ
                </div>
              </article>
              <article className={"card kpi"}>
                <div className={"kpi-label"}>
                  Tỷ lệ thu phí đúng hạn
                </div>
                <div className={"kpi-value"}>
                  92%
                </div>
                <div className={"kpi-note"}>
                  Tăng 3% so với quý trước
                </div>
              </article>
            </div>
            <div className={"grid-2"}>
              <article className={"card"}>
                <h2 className={"card-title"}>
                  Tăng trưởng học viên &amp; doanh thu
                </h2>
                <div className={"chart-wrap"}>
                  <canvas id={"growth-chart"} aria-label={"Biểu đồ tăng trưởng"}></canvas>
                </div>
              </article>
              <article className={"card"}>
                <h2 className={"card-title"}>
                  Phân bổ học viên theo khóa học
                </h2>
                <div className={"chart-wrap donut"}>
                  <canvas id={"course-chart"} aria-label={"Biểu đồ tròn phân bổ khóa học"}></canvas>
                </div>
              </article>
            </div>
            <article className={"card"}>
              <h2 className={"card-title"}>
                Đánh giá chất lượng lớp học &amp; giáo viên 
                <span className={"tag"}>
                  Học kỳ I
                </span>
              </h2>
              <div className={"table-wrap"}>
                <table>
                  <thead>
                    <tr>
                      <th>
                        KHÓA HỌC
                      </th>
                      <th>
                        LỚP HỌC
                      </th>
                      <th>
                        GIÁO VIÊN
                      </th>
                      <th>
                        SĨ SỐ
                      </th>
                      <th>
                        CHUYÊN CẦN
                      </th>
                      <th>
                        ĐIỂM TB
                      </th>
                      <th>
                        THU PHÍ
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        Toán Tiểu học
                      </td>
                      <td>
                        Lớp 5A
                      </td>
                      <td>
                        Nguyễn Thu Hà
                      </td>
                      <td>
                        18
                      </td>
                      <td>
                        92%
                      </td>
                      <td>
                        8,4
                      </td>
                      <td>
                        <span className={"tag green"}>
                          98%
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        Luyện thi vào 10
                      </td>
                      <td>
                        Lớp 9A
                      </td>
                      <td>
                        Trần Văn Anh
                      </td>
                      <td>
                        15
                      </td>
                      <td>
                        96%
                      </td>
                      <td>
                        8,8
                      </td>
                      <td>
                        <span className={"tag green"}>
                          100%
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        Toán THCS
                      </td>
                      <td>
                        Lớp 8B
                      </td>
                      <td>
                        Lê Thị Bình
                      </td>
                      <td>
                        16
                      </td>
                      <td>
                        88%
                      </td>
                      <td>
                        7,9
                      </td>
                      <td>
                        <span className={"tag"}>
                          91%
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </article>
          </section>
          
        
<section className={`tab-panel${canViewAdminModules && activeTab === "settings" ? " active" : ""}`} id={"admin-settings"} data-react-visible={canViewAdminModules && activeTab === "settings"}>
            <div className={"page-heading"}>
              <div>
                <h1>
                  Cài đặt hệ thống
                </h1>
                <p>
                  Thiết lập thông tin trung tâm và năm học.
                </p>
              </div>
              <button type="button" className={"button"} onClick={() => { resetStore(); setToastMessage('Đã khôi phục dữ liệu demo của CRM, Học vụ, Nhân sự và CSKH.') }}>
                <i className={"fa-solid fa-rotate-left"} aria-hidden="true"></i>
                Khôi phục dữ liệu demo
              </button>
            </div>
            <div className={"grid-equal"}>
              <article className={"card"}>
                <h2 className={"card-title"}>
                  Thông tin trung tâm
                </h2>
                <div className={"fact"}>
                  <small>
                    Tên trung tâm
                  </small>
                  <strong>
                    HÒA MA TOÁN · Trung tâm Toán học
                  </strong>
                </div>
                <div className={"fact"} style={{"marginTop": "16px"}}>
                  <small>
                    Cơ sở hiện tại
                  </small>
                  <strong>
                    Cơ sở 1 · Số 20 Nguyễn Chí Thanh, Hà Nội
                  </strong>
                </div>
                <div className={"fact"} style={{"marginTop": "16px"}}>
                  <small>
                    Năm học
                  </small>
                  <strong>
                    2026 – 2027
                  </strong>
                </div>
              </article>
              <article className={"card"}>
                <h2 className={"card-title"}>
                  Tùy chọn thông báo
                </h2>
                <div className={"list-row"}>
                  <div className={"list-main"}>
                    <strong>
                      Nhắc học phí đến hạn
                    </strong>
                    <small>
                      Gửi thông báo trước hạn 3 ngày
                    </small>
                  </div>
                  <span className={"tag green"}>
                    Đang bật
                  </span>
                </div>
                <div className={"list-row"}>
                  <div className={"list-main"}>
                    <strong>
                      Báo cáo hoạt động tuần
                    </strong>
                    <small>
                      Gửi vào sáng thứ Hai
                    </small>
                  </div>
                  <span className={"tag green"}>
                    Đang bật
                  </span>
                </div>
                <button className={"button"} style={{"marginTop": "16px"}} data-action={"save-settings"}>
                  Lưu cài đặt
                </button>
              </article>
            </div>
          </section>
          
      
        </div>
        

      
        <div className={`role-view${activeRole === "manager" ? " active" : ""}`} id={"role-manager"} data-react-visible={activeRole === "manager"}>
          
        
<section className={`tab-panel${activeRole === "manager" && activeTab === "home" ? " active" : ""}`} id={"manager-home"} data-react-visible={activeRole === "manager" && activeTab === "home"}>
            <div className={"page-heading"}>
              <div>
                <h1>
                  Trang chủ · Cơ sở Nguyễn Chí Thanh
                </h1>
                <p>
                  Tổng quan hoạt động cơ sở trong ngày hôm nay.
                </p>
              </div>
              <button className={"button primary"} data-action={"add-student"}>
                <i className={"fa-solid fa-plus"}></i>
                 Thêm học viên
              </button>
            </div>
            <div className={"kpi-grid"}>
              <article className={"card kpi"}>
                <div className={"kpi-label"}>
                  Học viên tại cơ sở
                </div>
                <div className={"kpi-value"}>
                  248
                </div>
                <div className={"kpi-note"}>
                  12 học viên mới tháng này
                </div>
              </article>
              <article className={"card kpi"}>
                <div className={"kpi-label"}>
                  Lớp đang hoạt động
                </div>
                <div className={"kpi-value"}>
                  18
                </div>
                <div className={"kpi-note"}>
                  4 lớp có thể tuyển thêm
                </div>
              </article>
              <article className={"card kpi"}>
                <div className={"kpi-label"}>
                  Giáo viên
                </div>
                <div className={"kpi-value"}>
                  12
                </div>
                <div className={"kpi-note"}>
                  10 có lịch dạy hôm nay
                </div>
              </article>
              <article className={"card kpi"}>
                <div className={"kpi-label"}>
                  Thu học phí tháng này
                </div>
                <div className={"kpi-value"}>
                  92%
                </div>
                <div className={"kpi-note warn"}>
                  8 khoản còn chờ thu
                </div>
              </article>
            </div>
            <div className={"grid-2"}>
              <article className={"card"}>
                <h2 className={"card-title"}>
                  KHỐI CẦN XỬ LÝ 
                  <span className={"tag red"}>
                    <i className={"fa-solid fa-triangle-exclamation"}></i>
                     3 cảnh báo
                  </span>
                </h2>
                <div className={"notice"}>
                  <strong>
                    <i className={"fa-solid fa-money-bill-wave"}></i>
                     Học phí quá hạn · 5 học viên
                  </strong>
                  <p>
                    Tổng công nợ 18.600.000đ. Cần liên hệ phụ huynh và cập nhật trạng thái thu phí.
                  </p>
                </div>
                <div className={"notice"}>
                  <strong>
                    <i className={"fa-regular fa-calendar-xmark"}></i>
                     Trùng lịch phòng · 2 lớp
                  </strong>
                  <p>
                    Toán 8B và Toán 9A cùng sử dụng phòng 201 lúc 18:00 thứ Tư.
                  </p>
                </div>
                <div className={"notice"}>
                  <strong>
                    <i className={"fa-solid fa-user-clock"}></i>
                     Thiếu giáo viên xác nhận · 1 ca
                  </strong>
                  <p>
                    Lớp Toán 5A lúc 16:30 hôm nay chưa xác nhận giáo viên phụ trách.
                  </p>
                </div>
              </article>
              <div className={"stack"}>
                <article className={"card"}>
                  <h2 className={"card-title"}>
                    Thao tác nhanh
                  </h2>
                  <div className={"quick-actions"}>
                    <button className={"quick-action"} data-action={"add-student"}>
                      <i className={"fa-solid fa-user-plus"}></i>
                      <span>
                        Thêm học viên
                      </span>
                    </button>
                    <button className={"quick-action"} data-action={"add-class"}>
                      <i className={"fa-solid fa-chalkboard"}></i>
                      <span>
                        Tạo lớp học
                      </span>
                    </button>
                    <button className={"quick-action"} data-action={"attendance"}>
                      <i className={"fa-solid fa-clipboard-check"}></i>
                      <span>
                        Điểm danh
                      </span>
                    </button>
                    <button className={"quick-action"} data-action={"export"}>
                      <i className={"fa-solid fa-file-export"}></i>
                      <span>
                        Xuất báo cáo
                      </span>
                    </button>
                  </div>
                </article>
                <article className={"card"}>
                  <h2 className={"card-title"}>
                    Nhật ký hoạt động 
                    <span className={"muted"}>
                      Hôm nay
                    </span>
                  </h2>
                  <div className={"list-row"}>
                    <span className={"mini-avatar"}>
                      <img src={"https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=96&h=96&fit=crop&crop=faces"} alt={"Nguyễn Thu Hà"} style={{"width": "100%", "height": "100%", "objectFit": "cover", "borderRadius": "50%"}} />
                    </span>
                    <div className={"list-main"}>
                      <strong>
                        Nguyễn Thu Hà cập nhật điểm danh lớp 5A
                      </strong>
                      <small>
                        08:25 · Học vụ
                      </small>
                    </div>
                  </div>
                  <div className={"list-row"}>
                    <span className={"mini-avatar"}>
                      <img src={"https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=96&h=96&fit=crop&crop=faces"} alt={"Nhân viên tài chính"} style={{"width": "100%", "height": "100%", "objectFit": "cover", "borderRadius": "50%"}} />
                    </span>
                    <div className={"list-main"}>
                      <strong>
                        Đã ghi nhận học phí của Lê Bảo Nam
                      </strong>
                      <small>
                        08:12 · Tài chính
                      </small>
                    </div>
                  </div>
                  <div className={"list-row"}>
                    <span className={"mini-avatar"}>
                      <img src={"https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=96&h=96&fit=crop&crop=faces"} alt={"Trần Văn Anh"} style={{"width": "100%", "height": "100%", "objectFit": "cover", "borderRadius": "50%"}} />
                    </span>
                    <div className={"list-main"}>
                      <strong>
                        Trần Văn Anh gửi đề xuất dạy bù
                      </strong>
                      <small>
                        07:48 · Nhân sự
                      </small>
                    </div>
                  </div>
                </article>
              </div>
            </div>
          </section>
          
        
<section className={`tab-panel${activeRole === "manager" && activeTab === "teachers" ? " active" : ""}`} id={"manager-teachers"} data-react-visible={activeRole === "manager" && activeTab === "teachers"}>
            <div className={"page-heading"}>
              <div>
                <h1>
                  Giáo viên cơ sở
                </h1>
                <p>
                  Danh sách giáo viên và lịch giảng dạy tại cơ sở.
                </p>
              </div>
              <button className={"button primary"} data-action={"add-employee"}>
                Thêm giáo viên
              </button>
            </div>
            <article className={"card"}>
              <div className={"table-wrap"}>
                <table>
                  <thead>
                    <tr>
                      <th>
                        GIÁO VIÊN
                      </th>
                      <th>
                        CHUYÊN MÔN
                      </th>
                      <th>
                        SỐ LỚP
                      </th>
                      <th>
                        LỊCH HÔM NAY
                      </th>
                      <th>
                        TRẠNG THÁI
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <div className={"table-name"}>
                          <span className={"mini-avatar"}>
                            NH
                          </span>
                          <strong>
                            Nguyễn Thu Hà
                          </strong>
                        </div>
                      </td>
                      <td>
                        Toán Tiểu học
                      </td>
                      <td>
                        4 lớp
                      </td>
                      <td>
                        16:30 · Toán 5A
                      </td>
                      <td>
                        <span className={"tag green"}>
                          Đang hoạt động
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <div className={"table-name"}>
                          <span className={"mini-avatar"}>
                            VA
                          </span>
                          <strong>
                            Trần Văn Anh
                          </strong>
                        </div>
                      </td>
                      <td>
                        Toán THCS
                      </td>
                      <td>
                        3 lớp
                      </td>
                      <td>
                        18:00 · Toán 9A
                      </td>
                      <td>
                        <span className={"tag green"}>
                          Đang hoạt động
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <div className={"table-name"}>
                          <span className={"mini-avatar"}>
                            LB
                          </span>
                          <strong>
                            Lê Thị Bình
                          </strong>
                        </div>
                      </td>
                      <td>
                        Toán tư duy
                      </td>
                      <td>
                        3 lớp
                      </td>
                      <td>
                        Không có lịch
                      </td>
                      <td>
                        <span className={"tag gray"}>
                          Nghỉ hôm nay
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </article>
          </section>
          
        
<section className={`tab-panel${activeRole === "manager" && activeTab === "students" ? " active" : ""}`} id={"manager-students"} data-react-visible={activeRole === "manager" && activeTab === "students"}>
            <div className={"page-heading"}>
              <div>
                <h1>
                  Học viên
                </h1>
                <p>
                  Danh sách học viên đang theo học tại cơ sở.
                </p>
              </div>
              <button className={"button primary"} data-action={"add-student"}>
                Thêm học viên
              </button>
            </div>
            <article className={"card"}>
              <div className={"table-wrap"}>
                <table>
                  <thead>
                    <tr>
                      <th>
                        HỌC VIÊN
                      </th>
                      <th>
                        LỚP ĐANG HỌC
                      </th>
                      <th>
                        PHỤ HUYNH
                      </th>
                      <th>
                        HỌC PHÍ
                      </th>
                      <th>
                        TRẠNG THÁI
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <strong>
                          Nguyễn Minh Anh
                        </strong>
                      </td>
                      <td>
                        Toán nâng cao 5A
                      </td>
                      <td>
                        Trần Minh Quân
                      </td>
                      <td>
                        <span className={"tag red"}>
                          Chưa đóng
                        </span>
                      </td>
                      <td>
                        Đang học
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          Lê Bảo Nam
                        </strong>
                      </td>
                      <td>
                        Luyện thi vào 10
                      </td>
                      <td>
                        Lê Thu Trang
                      </td>
                      <td>
                        <span className={"tag green"}>
                          Đã đóng
                        </span>
                      </td>
                      <td>
                        Đang học
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          Trần Thảo Chi
                        </strong>
                      </td>
                      <td>
                        Toán cơ bản lớp 3
                      </td>
                      <td>
                        Trần Hoài An
                      </td>
                      <td>
                        <span className={"tag green"}>
                          Đã đóng
                        </span>
                      </td>
                      <td>
                        Đang học
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </article>
          </section>
          
        
<section className={`tab-panel${activeRole === "manager" && activeTab === "courses" ? " active" : ""}`} id={"manager-courses"} data-react-visible={activeRole === "manager" && activeTab === "courses"}>
            <div className={"page-heading"}>
              <div>
                <h1>
                  Khóa học
                </h1>
                <p>
                  Chương trình đào tạo hiện có tại cơ sở.
                </p>
              </div>
              <button className={"button primary"} data-action={"add-class"}>
                Tạo khóa học
              </button>
            </div>
            <div className={"grid-3"}>
              <article className={"card"}>
                <span className={"tag"}>
                  Tiểu học
                </span>
                <h3>
                  Toán tư duy
                </h3>
                <p>
                  Rèn luyện tư duy logic và nền tảng toán học.
                  <br />
                  8 lớp · 96 học viên
                </p>
                <div className={"progress"}>
                  <span style={{"width": "82%"}}></span>
                </div>
              </article>
              <article className={"card"}>
                <span className={"tag blue"}>
                  THCS
                </span>
                <h3>
                  Toán nâng cao
                </h3>
                <p>
                  Củng cố kiến thức, phát triển năng lực giải toán.
                  <br />
                  6 lớp · 84 học viên
                </p>
                <div className={"progress blue"}>
                  <span style={{"width": "76%"}}></span>
                </div>
              </article>
              <article className={"card"}>
                <span className={"tag green"}>
                  Luyện thi
                </span>
                <h3>
                  Luyện thi vào 10
                </h3>
                <p>
                  Ôn tập chuyên sâu theo chương trình mới.
                  <br />
                  4 lớp · 68 học viên
                </p>
                <div className={"progress green"}>
                  <span style={{"width": "93%"}}></span>
                </div>
              </article>
            </div>
          </section>
          
        
<section className={`tab-panel${activeRole === "manager" && activeTab === "schedule" ? " active" : ""}`} id={"manager-schedule"} data-react-visible={activeRole === "manager" && activeTab === "schedule"}>
            <div className={"page-heading"}>
              <div>
                <h1>
                  Lịch khóa biểu
                </h1>
                <p>
                  Lịch giảng dạy tuần 26/10 – 01/11/2026.
                </p>
              </div>
            </div>
            <div className={"card"}>
              <div className={"week-grid"}>
                <div className={"week-day"}>
                  <h4>
                    THỨ 2
                  </h4>
                  <div className={"lesson"}>
                    <strong>
                      16:30 · Toán 5A
                    </strong>
                    Phòng 201 · Cô Hà
                  </div>
                  <div className={"lesson blue"}>
                    <strong>
                      18:00 · Toán 8B
                    </strong>
                    Phòng 202 · Thầy Anh
                  </div>
                </div>
                <div className={"week-day"}>
                  <h4>
                    THỨ 3
                  </h4>
                  <div className={"lesson blue"}>
                    <strong>
                      17:00 · Toán 9A
                    </strong>
                    Phòng 203 · Thầy Anh
                  </div>
                </div>
                <div className={"week-day"}>
                  <h4>
                    THỨ 4
                  </h4>
                  <div className={"lesson"}>
                    <strong>
                      18:00 · Toán 8B
                    </strong>
                    Phòng 201 · Cần xếp lại
                  </div>
                  <div className={"lesson blue"}>
                    <strong>
                      18:00 · Toán 9A
                    </strong>
                    Phòng 201 · Trùng phòng
                  </div>
                </div>
                <div className={"week-day"}>
                  <h4>
                    THỨ 5
                  </h4>
                  <div className={"lesson"}>
                    <strong>
                      16:30 · Toán 5A
                    </strong>
                    Phòng 201 · Cô Hà
                  </div>
                </div>
                <div className={"week-day"}>
                  <h4>
                    THỨ 6
                  </h4>
                  <div className={"lesson blue"}>
                    <strong>
                      18:00 · Toán 9A
                    </strong>
                    Phòng 203 · Thầy Anh
                  </div>
                </div>
                <div className={"week-day"}>
                  <h4>
                    THỨ 7
                  </h4>
                  <div className={"lesson"}>
                    <strong>
                      09:00 · Toán tư duy 3
                    </strong>
                    Phòng 202 · Cô Bình
                  </div>
                </div>
                <div className={"week-day"}>
                  <h4>
                    CHỦ NHẬT
                  </h4>
                  <span className={"tag gray"}>
                    Không có lịch
                  </span>
                </div>
              </div>
            </div>
          </section>
          
        
<section className={`tab-panel${activeRole === "manager" && activeTab === "fees" ? " active" : ""}`} id={"manager-fees"} data-react-visible={activeRole === "manager" && activeTab === "fees"}>
            <div className={"page-heading"}>
              <div>
                <h1>
                  Học phí cơ sở
                </h1>
                <p>
                  Đối soát học phí và theo dõi các khoản cần thu.
                </p>
              </div>
              <button className={"button"} data-action={"export"}>
                Xuất danh sách
              </button>
            </div>
            <div className={"kpi-grid"}>
              <article className={"card kpi"}>
                <div className={"kpi-label"}>
                  Đã thu tháng này
                </div>
                <div className={"kpi-value"}>
                  228M
                </div>
                <div className={"kpi-note"}>
                  92% kế hoạch
                </div>
              </article>
              <article className={"card kpi"}>
                <div className={"kpi-label"}>
                  Chưa thu
                </div>
                <div className={"kpi-value"}>
                  18,6M
                </div>
                <div className={"kpi-note warn"}>
                  5 khoản quá hạn
                </div>
              </article>
              <article className={"card kpi"}>
                <div className={"kpi-label"}>
                  Chờ đối soát
                </div>
                <div className={"kpi-value"}>
                  3
                </div>
                <div className={"kpi-note"}>
                  Giao dịch chuyển khoản
                </div>
              </article>
              <article className={"card kpi"}>
                <div className={"kpi-label"}>
                  Miễn giảm
                </div>
                <div className={"kpi-value"}>
                  6,2M
                </div>
                <div className={"kpi-note"}>
                  4 học viên
                </div>
              </article>
            </div>
            <article className={"card"}>
              <h2 className={"card-title"}>
                Học phí cần xử lý
              </h2>
              <div className={"table-wrap"}>
                <table>
                  <thead>
                    <tr>
                      <th>
                        HỌC VIÊN
                      </th>
                      <th>
                        LỚP
                      </th>
                      <th>
                        HẠN ĐÓNG
                      </th>
                      <th>
                        SỐ TIỀN
                      </th>
                      <th>
                        TRẠNG THÁI
                      </th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <strong>
                          Nguyễn Minh Anh
                        </strong>
                      </td>
                      <td>
                        Toán 5A
                      </td>
                      <td>
                        20/10/2026
                      </td>
                      <td>
                        4.800.000đ
                      </td>
                      <td>
                        <span className={"tag red"}>
                          Quá hạn
                        </span>
                      </td>
                      <td>
                        <button className={"button small"} data-action={"remind"}>
                          Nhắc phí
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          Trần Hoàng Nam
                        </strong>
                      </td>
                      <td>
                        Toán 12A
                      </td>
                      <td>
                        22/10/2026
                      </td>
                      <td>
                        4.200.000đ
                      </td>
                      <td>
                        <span className={"tag red"}>
                          Quá hạn
                        </span>
                      </td>
                      <td>
                        <button className={"button small"} data-action={"remind"}>
                          Nhắc phí
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </article>
          </section>
          
        
<section className={`tab-panel${activeRole === "manager" && activeTab === "reports" ? " active" : ""}`} id={"manager-reports"} data-react-visible={activeRole === "manager" && activeTab === "reports"}>
            <div className={"page-heading"}>
              <div>
                <h1>
                  Báo cáo cơ sở
                </h1>
                <p>
                  Chỉ số vận hành và kết quả đào tạo tại cơ sở.
                </p>
              </div>
              <button className={"button"} data-action={"export"}>
                Xuất báo cáo
              </button>
            </div>
            <div className={"kpi-grid"}>
              <article className={"card kpi"}>
                <div className={"kpi-label"}>
                  Học viên
                </div>
                <div className={"kpi-value"}>
                  248
                </div>
                <div className={"kpi-note"}>
                  Tăng 12% tháng này
                </div>
              </article>
              <article className={"card kpi"}>
                <div className={"kpi-label"}>
                  Số lớp
                </div>
                <div className={"kpi-value"}>
                  18
                </div>
                <div className={"kpi-note"}>
                  15 lớp đang tuyển sinh
                </div>
              </article>
              <article className={"card kpi"}>
                <div className={"kpi-label"}>
                  Hiệu suất lấp đầy
                </div>
                <div className={"kpi-value"}>
                  85%
                </div>
                <div className={"kpi-note"}>
                  Mục tiêu 90%
                </div>
              </article>
              <article className={"card kpi"}>
                <div className={"kpi-label"}>
                  Thu đúng hạn
                </div>
                <div className={"kpi-value"}>
                  92%
                </div>
                <div className={"kpi-note"}>
                  Tăng 3% tháng trước
                </div>
              </article>
            </div>
            <article className={"card"}>
              <h2 className={"card-title"}>
                Đánh giá chất lượng lớp học
              </h2>
              <div className={"table-wrap"}>
                <table>
                  <thead>
                    <tr>
                      <th>
                        LỚP
                      </th>
                      <th>
                        GIÁO VIÊN
                      </th>
                      <th>
                        SĨ SỐ
                      </th>
                      <th>
                        CHUYÊN CẦN
                      </th>
                      <th>
                        ĐIỂM TRUNG BÌNH
                      </th>
                      <th>
                        THU PHÍ
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <strong>
                          Toán nâng cao 5A
                        </strong>
                      </td>
                      <td>
                        Nguyễn Thu Hà
                      </td>
                      <td>
                        18/20
                      </td>
                      <td>
                        92%
                      </td>
                      <td>
                        8,4
                      </td>
                      <td>
                        98%
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          Luyện thi vào 10
                        </strong>
                      </td>
                      <td>
                        Trần Văn Anh
                      </td>
                      <td>
                        15/15
                      </td>
                      <td>
                        96%
                      </td>
                      <td>
                        8,8
                      </td>
                      <td>
                        100%
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          Toán cơ bản 3A
                        </strong>
                      </td>
                      <td>
                        Lê Thị Bình
                      </td>
                      <td>
                        12/16
                      </td>
                      <td>
                        88%
                      </td>
                      <td>
                        7,9
                      </td>
                      <td>
                        91%
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </article>
          </section>
          
      
        </div>
        

      
        <div className={`role-view${activeRole === "teacher" ? " active" : ""}`} id={"role-teacher"} data-react-visible={activeRole === "teacher"}>
          
        
<section className={`tab-panel${activeRole === "teacher" && activeTab === "dashboard" ? " active" : ""}`} id={"teacher-dashboard"} data-react-visible={activeRole === "teacher" && activeTab === "dashboard"}>
            <div className={"page-heading"}>
              <div>
                <h1>
                  Dashboard giáo viên
                </h1>
                <p>
                  Lịch dạy và hoạt động giảng dạy tuần này.
                </p>
              </div>
              <button className={"button"} data-action={"export"}>
                <i className={"fa-solid fa-download"}></i>
                 Xuất lịch dạy
              </button>
            </div>
            <article className={"card"} style={{"marginBottom": "16px"}}>
              <div className={"profile-card"}>
                <div className={"avatar large"}>
                  NH
                </div>
                <div>
                  <h2 style={{"margin": "0 0 6px", "fontSize": "17px"}}>
                    Nguyễn Thu Hà
                  </h2>
                  <span className={"tag"}>
                    Giáo viên Toán
                  </span>
                  <div className={"profile-facts"}>
                    <div className={"fact"}>
                      <small>
                        Ngày sinh
                      </small>
                      <strong>
                        12/08/1992
                      </strong>
                    </div>
                    <div className={"fact"}>
                      <small>
                        Cơ sở giảng dạy
                      </small>
                      <strong>
                        Nguyễn Chí Thanh, Hà Nội
                      </strong>
                    </div>
                    <div className={"fact"}>
                      <small>
                        Email
                      </small>
                      <strong>
                        ha.nguyen@hoamatoan.vn
                      </strong>
                    </div>
                    <div className={"fact"}>
                      <small>
                        Thâm niên
                      </small>
                      <strong>
                        5 năm · Giáo viên chính thức
                      </strong>
                    </div>
                  </div>
                </div>
              </div>
            </article>
            <article className={"card"} style={{"marginBottom": "16px"}}>
              <h2 className={"card-title"}>
                BẢNG MA TRẬN LỊCH DẠY 
                <span className={"muted"}>
                  Tuần 26/10 – 01/11
                </span>
              </h2>
              <div className={"table-wrap"}>
                <div className={"matrix"}>
                  <div className={"matrix-cell heading"}>
                    CA HỌC
                  </div>
                  <div className={"matrix-cell heading"}>
                    THỨ 2
                  </div>
                  <div className={"matrix-cell heading"}>
                    THỨ 3
                  </div>
                  <div className={"matrix-cell heading"}>
                    THỨ 4
                  </div>
                  <div className={"matrix-cell heading"}>
                    THỨ 5
                  </div>
                  <div className={"matrix-cell heading"}>
                    THỨ 6
                  </div>
                  <div className={"matrix-cell heading"}>
                    THỨ 7
                  </div>
                  <div className={"matrix-cell heading"}>
                    CHỦ NHẬT
                  </div>
                  
          
                  <div className={"matrix-cell period"}>
                    Ca 1
                    <br />
                    08:00–10:00
                  </div>
                  <div className={"matrix-cell"}></div>
                  <div className={"matrix-cell"}>
                    <div className={"matrix-lesson blue"}>
                      <strong>
                        Gia sư Toán
                      </strong>
                      Minh Anh · Online
                    </div>
                  </div>
                  <div className={"matrix-cell"}></div>
                  <div className={"matrix-cell"}></div>
                  <div className={"matrix-cell"}></div>
                  <div className={"matrix-cell"}>
                    <div className={"matrix-lesson"}>
                      <strong>
                        Toán 5B
                      </strong>
                      Phòng 102
                    </div>
                  </div>
                  <div className={"matrix-cell"}></div>
                  
          
                  <div className={"matrix-cell period"}>
                    Ca 2
                    <br />
                    14:00–16:00
                  </div>
                  <div className={"matrix-cell"}>
                    <div className={"matrix-lesson"}>
                      <strong>
                        Toán 5A
                      </strong>
                      Phòng 102
                    </div>
                  </div>
                  <div className={"matrix-cell"}></div>
                  <div className={"matrix-cell"}>
                    <div className={"matrix-lesson blue"}>
                      <strong>
                        Ôn Toán · Linh
                      </strong>
                      Online
                    </div>
                  </div>
                  <div className={"matrix-cell"}></div>
                  <div className={"matrix-cell"}>
                    <div className={"matrix-lesson"}>
                      <strong>
                        Toán 5B
                      </strong>
                      Phòng 104
                    </div>
                  </div>
                  <div className={"matrix-cell"}></div>
                  <div className={"matrix-cell"}></div>
                  
          
                  <div className={"matrix-cell period"}>
                    Ca 3
                    <br />
                    16:00–18:00
                  </div>
                  <div className={"matrix-cell"}>
                    <div className={"matrix-lesson"}>
                      <strong>
                        Toán Logic 6B
                      </strong>
                      Phòng 203
                    </div>
                  </div>
                  <div className={"matrix-cell"}></div>
                  <div className={"matrix-cell"}>
                    <div className={"matrix-lesson blue"}>
                      <strong>
                        Gia sư Toán
                      </strong>
                      Phòng 201
                    </div>
                  </div>
                  <div className={"matrix-cell"}>
                    <div className={"matrix-lesson"}>
                      <strong>
                        Toán 7A
                      </strong>
                      Phòng 204
                    </div>
                  </div>
                  <div className={"matrix-cell"}></div>
                  <div className={"matrix-cell"}>
                    <div className={"matrix-lesson blue"}>
                      <strong>
                        Ôn Toán · Nam
                      </strong>
                      Online
                    </div>
                  </div>
                  <div className={"matrix-cell"}>
                    <div className={"matrix-lesson"}>
                      <strong>
                        Toán nâng cao
                      </strong>
                      Phòng 201
                    </div>
                  </div>
                  
          
                  <div className={"matrix-cell period"}>
                    Ca 4
                    <br />
                    18:00–20:00
                  </div>
                  <div className={"matrix-cell"}></div>
                  <div className={"matrix-cell"}>
                    <div className={"matrix-lesson"}>
                      <strong>
                        Toán 7B
                      </strong>
                      Phòng 202
                    </div>
                  </div>
                  <div className={"matrix-cell"}></div>
                  <div className={"matrix-cell"}>
                    <div className={"matrix-lesson blue"}>
                      <strong>
                        Gia sư Toán
                      </strong>
                      Online
                    </div>
                  </div>
                  <div className={"matrix-cell"}>
                    <div className={"matrix-lesson"}>
                      <strong>
                        Toán 8A
                      </strong>
                      Phòng 203
                    </div>
                  </div>
                  <div className={"matrix-cell"}></div>
                  <div className={"matrix-cell"}></div>
                </div>
              </div>
            </article>
            <div className={"grid-equal"}>
              <article className={"card"}>
                <h2 className={"card-title"}>
                  Tóm tắt công việc hôm nay
                </h2>
                <div className={"list-row"}>
                  <div className={"list-main"}>
                    <strong>
                      Ca dạy tiếp theo · Toán 5A
                    </strong>
                    <small>
                      16:00 – 18:00 · Phòng 102 · 18 học sinh
                    </small>
                  </div>
                  <span className={"tag blue"}>
                    Sắp tới
                  </span>
                </div>
                <div className={"list-row"}>
                  <div className={"list-main"}>
                    <strong>
                      Chấm bài tập về nhà
                    </strong>
                    <small>
                      Lớp Toán Logic 6B · 12 bài chưa chấm
                    </small>
                  </div>
                  <span className={"tag"}>
                    Cần làm
                  </span>
                </div>
              </article>
              <article className={"card"}>
                <h2 className={"card-title"}>
                  Lớp đang phụ trách 
                  <button className={"button small"} data-open-tab={"teacher-classes"}>
                    Xem tất cả
                  </button>
                </h2>
                <div className={"list-row"}>
                  <div className={"list-main"}>
                    <strong>
                      Toán nâng cao 5A
                    </strong>
                    <small>
                      18 học sinh · Thứ 2, 16:00
                    </small>
                  </div>
                  <span className={"tag green"}>
                    Đang học
                  </span>
                </div>
                <div className={"list-row"}>
                  <div className={"list-main"}>
                    <strong>
                      Toán Logic 6B
                    </strong>
                    <small>
                      12 học sinh · Thứ 2, 18:00
                    </small>
                  </div>
                  <span className={"tag green"}>
                    Đang học
                  </span>
                </div>
              </article>
            </div>
          </section>
          
        
<section className={`tab-panel${activeRole === "teacher" && activeTab === "classes" ? " active" : ""}`} id={"teacher-classes"} data-react-visible={activeRole === "teacher" && activeTab === "classes"}>
            <div className={"page-heading"}>
              <div>
                <h1>
                  Lớp học đang phụ trách
                </h1>
                <p>
                  Theo dõi sĩ số, lịch học sắp tới và tiến độ lớp.
                </p>
              </div>
              <button className={"button"}>
                <i className={"fa-solid fa-filter"}></i>
                 Lọc lớp
              </button>
            </div>
            <div className={"class-grid"}>
              
          
              <article className={"card class-card"}>
                <span className={"tag"}>
                  Lớp tiêu chuẩn
                </span>
                <h3>
                  Toán nâng cao 10A
                </h3>
                <p>
                  <i className={"fa-regular fa-calendar"}></i>
                   Buổi học tiếp theo: Thứ 2, 14:00 – 15:30
                  <br />
                  <i className={"fa-solid fa-users"}></i>
                   Sĩ số: 8/12 học sinh
                </p>
                <div className={"progress-meta"}>
                  <span>
                    Tỷ lệ lấp đầy
                  </span>
                  <span>
                    75%
                  </span>
                </div>
                <div className={"progress"}>
                  <span style={{"width": "75%"}}></span>
                </div>
                <div className={"class-footer"}>
                  <button className={"button small"} data-action={"attendance"}>
                    Điểm danh
                  </button>
                  <button className={"button primary small"} data-action={"students"}>
                    Học sinh
                  </button>
                </div>
              </article>
              
          
              <article className={"card class-card"}>
                <span className={"tag blue"}>
                  Gia sư 1–1
                </span>
                <h3>
                  Gia sư Toán · Tuấn Anh
                </h3>
                <p>
                  <i className={"fa-regular fa-calendar"}></i>
                   Buổi học tiếp theo: Thứ 3, 18:00 – 19:30
                  <br />
                  <i className={"fa-solid fa-users"}></i>
                   Sĩ số: 1/1 học sinh
                </p>
                <div className={"progress-meta"}>
                  <span>
                    Tỷ lệ lấp đầy
                  </span>
                  <span>
                    100%
                  </span>
                </div>
                <div className={"progress blue"}>
                  <span style={{"width": "100%"}}></span>
                </div>
                <div className={"class-footer"}>
                  <button className={"button small"} data-action={"attendance"}>
                    Điểm danh
                  </button>
                  <button className={"button primary small"} data-action={"students"}>
                    Học sinh
                  </button>
                </div>
              </article>
              
          
              <article className={"card class-card"}>
                <span className={"tag"}>
                  Lớp tiêu chuẩn
                </span>
                <h3>
                  Toán Logic 11B
                </h3>
                <p>
                  <i className={"fa-regular fa-calendar"}></i>
                   Buổi học tiếp theo: Thứ 6, 08:30 – 10:00
                  <br />
                  <i className={"fa-solid fa-users"}></i>
                   Sĩ số: 6/12 học sinh
                </p>
                <div className={"progress-meta"}>
                  <span>
                    Tỷ lệ lấp đầy
                  </span>
                  <span>
                    50%
                  </span>
                </div>
                <div className={"progress green"}>
                  <span style={{"width": "50%"}}></span>
                </div>
                <div className={"class-footer"}>
                  <button className={"button small"} data-action={"attendance"}>
                    Điểm danh
                  </button>
                  <button className={"button primary small"} data-action={"students"}>
                    Học sinh
                  </button>
                </div>
              </article>
              
          
              <article className={"card class-card"}>
                <span className={"tag"}>
                  Lớp tiêu chuẩn
                </span>
                <h3>
                  Toán 5A
                </h3>
                <p>
                  <i className={"fa-regular fa-calendar"}></i>
                   Buổi học tiếp theo: Thứ 5, 16:00 – 18:00
                  <br />
                  <i className={"fa-solid fa-users"}></i>
                   Sĩ số: 18/20 học sinh
                </p>
                <div className={"progress-meta"}>
                  <span>
                    Tỷ lệ lấp đầy
                  </span>
                  <span>
                    90%
                  </span>
                </div>
                <div className={"progress"}>
                  <span style={{"width": "90%"}}></span>
                </div>
                <div className={"class-footer"}>
                  <button className={"button small"} data-action={"attendance"}>
                    Điểm danh
                  </button>
                  <button className={"button primary small"} data-action={"students"}>
                    Học sinh
                  </button>
                </div>
              </article>
              
          
              <article className={"card class-card"}>
                <span className={"tag"}>
                  Luyện thi
                </span>
                <h3>
                  Luyện thi TSA
                </h3>
                <p>
                  <i className={"fa-regular fa-calendar"}></i>
                   Buổi học tiếp theo: Thứ 4, 18:00 – 20:00
                  <br />
                  <i className={"fa-solid fa-users"}></i>
                   Sĩ số: 12/12 học sinh
                </p>
                <div className={"progress-meta"}>
                  <span>
                    Tỷ lệ lấp đầy
                  </span>
                  <span>
                    100%
                  </span>
                </div>
                <div className={"progress"}>
                  <span style={{"width": "100%"}}></span>
                </div>
                <div className={"class-footer"}>
                  <button className={"button small"} data-action={"attendance"}>
                    Điểm danh
                  </button>
                  <button className={"button primary small"} data-action={"students"}>
                    Học sinh
                  </button>
                </div>
              </article>
              
          
              <article className={"card class-card"}>
                <span className={"tag blue"}>
                  Toán 11
                </span>
                <h3>
                  Toán nâng cao 11
                </h3>
                <p>
                  <i className={"fa-regular fa-calendar"}></i>
                   Buổi học tiếp theo: Thứ 7, 08:30 – 10:00
                  <br />
                  <i className={"fa-solid fa-users"}></i>
                   Sĩ số: 8/12 học sinh
                </p>
                <div className={"progress-meta"}>
                  <span>
                    Tỷ lệ lấp đầy
                  </span>
                  <span>
                    67%
                  </span>
                </div>
                <div className={"progress blue"}>
                  <span style={{"width": "67%"}}></span>
                </div>
                <div className={"class-footer"}>
                  <button className={"button small"} data-action={"attendance"}>
                    Điểm danh
                  </button>
                  <button className={"button primary small"} data-action={"students"}>
                    Học sinh
                  </button>
                </div>
              </article>
              
        
            </div>
          </section>
          
        
<section className={`tab-panel${activeRole === "teacher" && activeTab === "results" ? " active" : ""}`} id={"teacher-results"} data-react-visible={activeRole === "teacher" && activeTab === "results"}>
            <div className={"page-heading"}>
              <div>
                <h1>
                  Quản lý kết quả
                </h1>
                <p>
                  Cập nhật điểm số, điểm danh và nhận xét học tập.
                </p>
              </div>
              <button className={"button primary"} data-action={"save-results"}>
                Lưu kết quả
              </button>
            </div>
            <article className={"card"}>
              <h2 className={"card-title"}>
                Kết quả học tập · Toán nâng cao 5A
              </h2>
              <div className={"table-wrap"}>
                <table>
                  <thead>
                    <tr>
                      <th>
                        HỌC SINH
                      </th>
                      <th>
                        ĐIỂM DANH
                      </th>
                      <th>
                        ĐIỂM BTVN
                      </th>
                      <th>
                        ĐIỂM KIỂM TRA
                      </th>
                      <th>
                        NHẬN XÉT
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <strong>
                          Nguyễn Minh Anh
                        </strong>
                      </td>
                      <td>
                        <span className={"tag green"}>
                          Có mặt
                        </span>
                      </td>
                      <td>
                        9,5
                      </td>
                      <td>
                        8,8
                      </td>
                      <td>
                        Tích cực phát biểu, nắm bài tốt.
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          Lê Thu Hà
                        </strong>
                      </td>
                      <td>
                        <span className={"tag red"}>
                          Vắng có phép
                        </span>
                      </td>
                      <td>
                        —
                      </td>
                      <td>
                        —
                      </td>
                      <td>
                        Nghỉ ốm, cần bổ sung bài.
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          Phạm Minh Đức
                        </strong>
                      </td>
                      <td>
                        <span className={"tag green"}>
                          Có mặt
                        </span>
                      </td>
                      <td>
                        7,0
                      </td>
                      <td>
                        7,5
                      </td>
                      <td>
                        Cần hoàn thành bài tập đầy đủ hơn.
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </article>
          </section>
          
        
<section className={`tab-panel${activeRole === "teacher" && activeTab === "proposal" ? " active" : ""}`} id={"teacher-proposal"} data-react-visible={activeRole === "teacher" && activeTab === "proposal"}>
            <div className={"page-heading"}>
              <div>
                <h1>
                  Đề xuất dạy bù / dạy thay
                </h1>
                <p>
                  Gửi đề xuất để quản lý cơ sở xét duyệt lịch giảng dạy.
                </p>
              </div>
              <button className={"button primary"} data-action={"new-proposal"}>
                <i className={"fa-solid fa-plus"}></i>
                 Tạo đề xuất
              </button>
            </div>
            <article className={"card"}>
              <h2 className={"card-title"}>
                Đề xuất gần đây
              </h2>
              <div className={"table-wrap"}>
                <table>
                  <thead>
                    <tr>
                      <th>
                        LỚP HỌC
                      </th>
                      <th>
                        LOẠI ĐỀ XUẤT
                      </th>
                      <th>
                        NGÀY ĐỀ XUẤT
                      </th>
                      <th>
                        LÝ DO
                      </th>
                      <th>
                        TRẠNG THÁI
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <strong>
                          Toán nâng cao 10A
                        </strong>
                      </td>
                      <td>
                        Dạy bù
                      </td>
                      <td>
                        30/10/2026
                      </td>
                      <td>
                        Tham gia tập huấn chuyên môn
                      </td>
                      <td>
                        <span className={"tag"}>
                          Chờ duyệt
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>
                          Toán Logic 11B
                        </strong>
                      </td>
                      <td>
                        Dạy thay
                      </td>
                      <td>
                        25/10/2026
                      </td>
                      <td>
                        Đã bố trí giáo viên thay thế
                      </td>
                      <td>
                        <span className={"tag green"}>
                          Đã duyệt
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </article>
          </section>
          
      
        </div>
        

      
        <div className={`role-view${activeRole === "parent" ? " active" : ""} parent-view`} id={"role-parent"} data-react-visible={activeRole === "parent"}>
          
        
          <section className={`parent-only${activeRole === "parent" && parentView === "children" ? " active" : ""}`} id={"parent-children"} data-react-visible={activeRole === "parent" && parentView === "children"}>
            <div className={"page-heading"}>
              <div>
                <h1>
                  Danh sách con đang theo học
                </h1>
                <p>
                  Chọn hồ sơ để theo dõi lịch học, học phí và kết quả học tập.
                </p>
              </div>
            </div>
            <div className={"student-list"}>
              
          
              <button className={"student-choice"} data-select-child={"minh-anh"} type={"button"}>
                <span className={"avatar large"}>
                  MA
                </span>
                <span className={"student-choice-content"}>
                  <strong>
                    Nguyễn Minh Anh
                  </strong>
                  <span>
                    <i className={"fa-solid fa-book-open"}></i>
                     Lớp 5 · Toán nâng cao   ·   
                    <i className={"fa-solid fa-location-dot"}></i>
                     Cơ sở 1, Nguyễn Chí Thanh
                  </span>
                </span>
                <i className={"fa-solid fa-chevron-right"} style={{"color": "#94a3b8"}}></i>
              </button>
              
          
              <button className={"student-choice"} data-select-child={"bao-nam"} type={"button"}>
                <span className={"avatar large"} style={{"background": "#e0e7ff", "color": "#3730a3"}}>
                  BN
                </span>
                <span className={"student-choice-content"}>
                  <strong>
                    Lê Bảo Nam
                  </strong>
                  <span>
                    <i className={"fa-solid fa-book-open"}></i>
                     Lớp 9 · Luyện thi vào 10   ·   
                    <i className={"fa-solid fa-location-dot"}></i>
                     Cơ sở 1, Nguyễn Chí Thanh
                  </span>
                </span>
                <i className={"fa-solid fa-chevron-right"} style={{"color": "#94a3b8"}}></i>
              </button>
              
          
              <button className={"student-choice"} data-select-child={"thao-chi"} type={"button"}>
                <span className={"avatar large"} style={{"background": "#dcfce7", "color": "#15803d"}}>
                  TC
                </span>
                <span className={"student-choice-content"}>
                  <strong>
                    Trần Thảo Chi
                  </strong>
                  <span>
                    <i className={"fa-solid fa-book-open"}></i>
                     Lớp 3 · Toán cơ bản   ·   
                    <i className={"fa-solid fa-location-dot"}></i>
                     Cơ sở 1, Nguyễn Chí Thanh
                  </span>
                </span>
                <i className={"fa-solid fa-chevron-right"} style={{"color": "#94a3b8"}}></i>
              </button>
              
        
            </div>
          </section>
          
        
          <section className={`parent-only${activeRole === "parent" && parentView === "schedule" ? " active" : ""}`} id={"parent-schedule"} data-react-visible={activeRole === "parent" && parentView === "schedule"}>
            <div className={"page-heading"}>
              <div>
                <h1>
                  Hồ sơ học sinh
                </h1>
                <p>
                  Thông tin cá nhân và lịch học tuần này.
                </p>
              </div>
              <button className={"button"} data-parent-view={"children"}>
                <i className={"fa-solid fa-arrow-left"}></i>
                 Danh sách con
              </button>
            </div>
            <div className={"student-details"}>
              <article className={"card"}>
                <div className={"profile-card"}>
                  <div className={"avatar large"} id={"child-avatar"}>
                    {selectedChildInfo.avatar}
                  </div>
                  <div>
                    <h2 style={{"margin": "0 0 6px", "fontSize": "17px"}} id={"child-name"}>
                      {selectedChildInfo.name}
                    </h2>
                    <span className={"tag"}>
                      Đang theo học · Lớp 5
                    </span>
                  </div>
                </div>
                <div className={"profile-facts"}>
                  <div className={"fact"}>
                    <small>
                      Ngày sinh
                    </small>
                    <strong id={"child-birth"}>
                      {selectedChildInfo.birth}
                    </strong>
                  </div>
                  <div className={"fact"}>
                    <small>
                      Giới tính
                    </small>
                    <strong>
                      {selectedChildInfo.gender}
                    </strong>
                  </div>
                  <div className={"fact"}>
                    <small>
                      Lớp đang học
                    </small>
                    <strong id={"child-class"}>
                      {selectedChildInfo.grade}
                    </strong>
                  </div>
                  <div className={"fact"}>
                    <small>
                      Giáo viên
                    </small>
                    <strong>
                      Nguyễn Thu Hà
                    </strong>
                  </div>
                  <div className={"fact"} style={{"gridColumn": "1/-1"}}>
                    <small>
                      Cơ sở đang học
                    </small>
                    <strong>
                      Số nhà 20, ngõ 62 Nguyễn Chí Thanh, quận Đống Đa, Hà Nội.
                    </strong>
                  </div>
                </div>
              </article>
              <article className={"card"}>
                <h2 className={"card-title"}>
                  Thông tin phụ huynh 
                  <span className={"tag green"}>
                    Đã xác minh
                  </span>
                </h2>
                <div className={"fact"}>
                  <small>
                    Người giám hộ
                  </small>
                  <strong>
                    Trần Minh Quân
                  </strong>
                </div>
                <div className={"fact"} style={{"marginTop": "16px"}}>
                  <small>
                    Số điện thoại
                  </small>
                  <strong>
                    09xx xxx 128
                  </strong>
                </div>
                <div className={"fact"} style={{"marginTop": "16px"}}>
                  <small>
                    Email
                  </small>
                  <strong>
                    minhquan@example.com
                  </strong>
                </div>
                <div className={"fact"} style={{"marginTop": "16px"}}>
                  <small>
                    Thời gian đào tạo
                  </small>
                  <strong>
                    12 tháng · Khóa hè + Thu
                  </strong>
                </div>
              </article>
            </div>
            <article className={"card"}>
              <h2 className={"card-title"}>
                Lịch học tuần này 
                <span className={"muted"}>
                  26/10 – 01/11/2026
                </span>
              </h2>
              <div className={"week-grid"}>
                <div className={"week-day"}>
                  <h4>
                    THỨ 2
                  </h4>
                  <div className={"lesson"}>
                    <strong>
                      Toán 5A
                    </strong>
                    GV Nguyễn Thu Hà
                    <br />
                    16:00 – 18:00
                  </div>
                </div>
                <div className={"week-day"}>
                  <h4>
                    THỨ 3
                  </h4>
                  <span className={"tag gray"}>
                    Không có lịch
                  </span>
                </div>
                <div className={"week-day"}>
                  <h4>
                    THỨ 4
                  </h4>
                  <div className={"lesson blue"}>
                    <strong>
                      Gia sư Toán
                    </strong>
                    GV Lê Hoàng An
                    <br />
                    18:00 – 19:00
                  </div>
                </div>
                <div className={"week-day"}>
                  <h4>
                    THỨ 5
                  </h4>
                  <span className={"tag gray"}>
                    Không có lịch
                  </span>
                </div>
                <div className={"week-day"}>
                  <h4>
                    THỨ 6
                  </h4>
                  <div className={"lesson"}>
                    <strong>
                      Toán 5A
                    </strong>
                    GV Nguyễn Thu Hà
                    <br />
                    16:00 – 18:00
                  </div>
                </div>
                <div className={"week-day"}>
                  <h4>
                    THỨ 7
                  </h4>
                  <span className={"tag gray"}>
                    Không có lịch
                  </span>
                </div>
                <div className={"week-day"}>
                  <h4>
                    CHỦ NHẬT
                  </h4>
                  <div className={"lesson blue"}>
                    <strong>
                      Giải đề Toán
                    </strong>
                    GV Nguyễn Thu Hà
                    <br />
                    09:00 – 10:30
                  </div>
                </div>
              </div>
            </article>
          </section>
          
        
          <section className={`parent-only${activeRole === "parent" && parentView === "fees" ? " active" : ""}`} id={"parent-fees"} data-react-visible={activeRole === "parent" && parentView === "fees"}>
            <div className={"page-heading"}>
              <div>
                <h1>
                  Quản lý học phí
                </h1>
                <p>
                  Học phí tháng 10/2026 · 
                  <span id={"fee-child-name"}>
                    {selectedChildInfo.name}
                  </span>
                </p>
              </div>
            </div>
            <div className={"grid-2"}>
              <div>
                <article className={"fee-highlight"} style={{"marginBottom": "16px"}}>
                  <div>
                    <small>
                      Học phí cần đóng · Tháng 10/2026
                    </small>
                    <h2>
                      2.500.000 VNĐ
                    </h2>
                    <small>
                      <i className={"fa-regular fa-clock"}></i>
                       Hạn thanh toán: 10/11/2026
                    </small>
                  </div>
                  <button className={"button"} data-action={"vietqr"}>
                    <i className={"fa-solid fa-qrcode"}></i>
                     Thanh toán VietQR
                  </button>
                </article>
                <article className={"card"}>
                  <h2 className={"card-title"}>
                    Chi tiết học phí hiện tại
                  </h2>
                  <div className={"list-row"}>
                    <div className={"list-main"}>
                      Số buổi học dự kiến
                    </div>
                    <strong>
                      12 buổi
                    </strong>
                  </div>
                  <div className={"list-row"}>
                    <div className={"list-main"}>
                      Đơn giá
                    </div>
                    <strong>
                      200.000 VNĐ/buổi
                    </strong>
                  </div>
                  <div className={"list-row"}>
                    <div className={"list-main"}>
                      Khấu trừ · Nghỉ có phép tháng trước
                    </div>
                    <strong style={{"color": "var(--green)"}}>
                      − 200.000 VNĐ
                    </strong>
                  </div>
                  <div className={"list-row"}>
                    <div className={"list-main"}>
                      Phụ phí tài liệu
                    </div>
                    <strong>
                      100.000 VNĐ
                    </strong>
                  </div>
                  <div className={"list-row"}>
                    <strong>
                      Tổng cộng cần thanh toán
                    </strong>
                    <strong style={{"color": "#c2410c"}}>
                      2.500.000 VNĐ
                    </strong>
                  </div>
                </article>
              </div>
              <article className={"card"}>
                <h2 className={"card-title"}>
                  Lịch sử thanh toán
                </h2>
                <div className={"list-row"}>
                  <div className={"list-main"}>
                    <strong>
                      Tháng 09/2026
                    </strong>
                    <small>
                      Ngày giao dịch: 10/09/2026
                    </small>
                  </div>
                  <div className={"list-value"}>
                    2.400.000 VNĐ
                    <br />
                    <span className={"tag green"}>
                      Đã thanh toán
                    </span>
                  </div>
                </div>
                <div className={"list-row"}>
                  <div className={"list-main"}>
                    <strong>
                      Tháng 08/2026
                    </strong>
                    <small>
                      Ngày giao dịch: 12/08/2026
                    </small>
                  </div>
                  <div className={"list-value"}>
                    2.600.000 VNĐ
                    <br />
                    <span className={"tag green"}>
                      Đã thanh toán
                    </span>
                  </div>
                </div>
                <button className={"button"} style={{"width": "100%", "marginTop": "17px"}} data-action={"payment-history"}>
                  Xem tất cả lịch sử
                </button>
              </article>
            </div>
          </section>
          
        
          <section className={`parent-only${activeRole === "parent" && parentView === "results" ? " active" : ""}`} id={"parent-results"} data-react-visible={activeRole === "parent" && parentView === "results"}>
            <div className={"page-heading"}>
              <div>
                <h1>
                  Kết quả học tập
                </h1>
                <p>
                  Theo dõi chuyên cần, điểm số và nhận xét của giáo viên.
                </p>
              </div>
              <span className={"tag"}>
                Học kỳ I · 2026–2027
              </span>
            </div>
            <div className={"grid-equal"}>
              <article className={"card"}>
                <h2 className={"card-title"}>
                  Thống kê chuyên cần
                </h2>
                <div style={{"display": "flex", "alignItems": "center", "gap": "20px"}}>
                  <div className={"attendance-ring"}>
                    <strong>
                      94%
                    </strong>
                  </div>
                  <div>
                    <strong>
                      Toán nâng cao 5A
                    </strong>
                    <p style={{"color": "var(--text-desc)", "fontSize": "11px", "lineHeight": "1.9"}}>
                      Có mặt: 18 buổi
                      <br />
                      Vắng mặt: 1 buổi
                      <br />
                      Đi muộn: 0 buổi
                    </p>
                    <strong style={{"color": "var(--green)"}}>
                      Rất tốt
                    </strong>
                  </div>
                </div>
              </article>
              <article className={"card"}>
                <h2 className={"card-title"}>
                  Phổ điểm theo tháng
                </h2>
                <div className={"chart-wrap short"}>
                  <canvas id={"parent-score-chart"} aria-label={"Biểu đồ phổ điểm theo tháng"}></canvas>
                </div>
              </article>
            </div>
            <article className={"card"}>
              <h2 className={"card-title"}>
                Nhận xét lớp Toán nâng cao 5A 
                <span className={"tag"}>
                  GV: Nguyễn Thu Hà
                </span>
              </h2>
              <div className={"table-wrap"}>
                <table>
                  <thead>
                    <tr>
                      <th>
                        STT
                      </th>
                      <th>
                        NGÀY HỌC
                      </th>
                      <th>
                        ĐIỂM DANH
                      </th>
                      <th>
                        ĐIỂM BTVN
                      </th>
                      <th>
                        NHẬN XÉT
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        1
                      </td>
                      <td>
                        15/10/2026
                      </td>
                      <td>
                        <span className={"tag green"}>
                          Có mặt
                        </span>
                      </td>
                      <td>
                        <strong>
                          9,0
                        </strong>
                      </td>
                      <td>
                        Làm bài tốt, cần chú ý trình bày cẩn thận hơn.
                      </td>
                    </tr>
                    <tr>
                      <td>
                        2
                      </td>
                      <td>
                        18/10/2026
                      </td>
                      <td>
                        <span className={"tag green"}>
                          Có mặt
                        </span>
                      </td>
                      <td>
                        <strong>
                          8,5
                        </strong>
                      </td>
                      <td>
                        Tiếp thu bài nhanh, tích cực phát biểu.
                      </td>
                    </tr>
                    <tr>
                      <td>
                        3
                      </td>
                      <td>
                        22/10/2026
                      </td>
                      <td>
                        <span className={"tag red"}>
                          Vắng có phép
                        </span>
                      </td>
                      <td>
                        —
                      </td>
                      <td>
                        Đã gửi bài học bù qua ứng dụng.
                      </td>
                    </tr>
                    <tr>
                      <td>
                        4
                      </td>
                      <td>
                        25/10/2026
                      </td>
                      <td>
                        <span className={"tag green"}>
                          Có mặt
                        </span>
                      </td>
                      <td>
                        <strong>
                          9,5
                        </strong>
                      </td>
                      <td>
                        Hoàn thành tốt bài tập vận dụng.
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </article>
          </section>
          
      
        </div>
        
    
      </main>
      
  
    </div>
    
  
    <button className={`ai-launcher${session ? "" : " hidden"}`} id={"ai-launcher"} type={"button"} aria-label={aiOpen ? "Đóng trợ lý AI" : "Mở trợ lý AI"} aria-expanded={aiOpen} aria-controls={"ai-panel"}>
      
    
      <i className={"fa-solid fa-wand-magic-sparkles"} aria-hidden={"true"}></i>
      <span className={"ai-launcher-label"}>
        Trợ lý Hòa Ma AI
      </span>
      
  
    </button>
    
  
    <section className={"ai-panel"} id={"ai-panel"} role={"dialog"} aria-label={"Trợ lý Hòa Ma AI"} hidden={!aiOpen}>
      
    
      <header className={"ai-header"}>
        
      
        <span className={"ai-mark"}>
          <i className={"fa-solid fa-wand-magic-sparkles"} aria-hidden={"true"}></i>
        </span>
        
      
        <div className={"ai-title"}>
          <strong>
            Trợ lý Hòa Ma AI 
            <span className={"tag"} style={{"padding": "2px 6px", "fontSize": "8px"}}>
              DEMO
            </span>
          </strong>
          <small id={"ai-role-label"}>
            Tư vấn theo vai trò của bạn
          </small>
        </div>
        
      
        <button className={"ai-clear"} id={"ai-clear"} type={"button"} aria-label={"Bắt đầu hội thoại mới"} title={"Hội thoại mới"}>
          <i className={"fa-solid fa-rotate-right"}></i>
        </button>
        
      
        <button className={"ai-close"} id={"ai-close"} type={"button"} aria-label={"Đóng trợ lý"}>
          <i className={"fa-solid fa-xmark"}></i>
        </button>
        
    
      </header>
      
    
      <div className={"ai-scope"} id={"ai-scope-note"}>
        Trợ lý sử dụng câu trả lời mô phỏng và dữ liệu mẫu đang có trên trang.
      </div>
      
    
      <div className={"ai-messages"} id={"ai-messages"} role={"log"} aria-live={"polite"} aria-relevant={"additions"}>{aiMessages.map((message, index) => <div className={`ai-message${message.sender === "user" ? " user" : ""}`} key={`${index}-${message.sender}`}>{message.text}</div>)}{aiPending && <div className={"ai-message typing"}>Trợ lý đang phản hồi...</div>}</div>
      
    
      <div className={"ai-suggestions"} id={"ai-suggestions"} aria-label={"Câu hỏi gợi ý"}>
        {["Tóm tắt tình hình", "Khoản học phí cần ưu tiên?", "Gợi ý việc cần xử lý"].map(prompt => (
          <button className={"ai-suggestion"} type={"button"} key={prompt} onClick={() => {
            setAiInput(prompt)
            window.setTimeout(() => rootRef.current?.querySelector("#ai-form")?.requestSubmit(), 0)
          }}>{prompt}</button>
        ))}
      </div>
      
    
      <form className={"ai-compose"} id={"ai-form"}>
        
      
        <textarea id={"ai-input"} name={"question"} rows={"1"} maxLength={"500"} aria-label={"Nhập câu hỏi"} placeholder={"Hỏi trợ lý theo vai trò của bạn..."} value={aiInput} onChange={handleChange}></textarea>
        
      
        <button className={"ai-send"} id={"ai-send"} type={"submit"} aria-label={"Gửi câu hỏi"}>
          <i className={"fa-solid fa-arrow-up"}></i>
        </button>
        
    
      </form>
      
    
      <div className={"ai-disclaimer"}>
        Bản demo chạy cục bộ, không kết nối mô hình AI hay gửi dữ liệu ra ngoài.
        <br />
        Không nhập thông tin cá nhân nhạy cảm của học sinh.
      </div>
      
  
    </section>
    
  
    <div className={`toast${toastMessage ? " show" : ""}`} id={"toast"} role={"status"} aria-live={"polite"}>{toastMessage}</div>
    
  
    </div>
  )
}

export default Dashboard
