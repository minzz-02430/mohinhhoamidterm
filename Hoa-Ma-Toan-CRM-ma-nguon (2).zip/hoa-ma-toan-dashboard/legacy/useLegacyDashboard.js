import { useEffect, useRef, useState } from 'react'
import { answerChat } from '../modules/store'

const demoAccounts = [
  { username: 'admin', password: '123456', email: 'admin@hoamatoan.vn', role: 'admin', name: 'Nguyễn Thu Hà' },
  { username: 'quanly', password: '123456', email: 'quanly@hoamatoan.vn', role: 'manager', name: 'Trần Minh Quân' },
  { username: 'giaovien', password: '123456', email: 'giaovien@hoamatoan.vn', role: 'teacher', name: 'Nguyễn Thu Hà' },
  { username: 'phuhuynh', password: '123456', email: 'phuhuynh@hoamatoan.vn', role: 'parent', name: 'Trần Minh Quân' },
]
const roleTitles = { admin: 'Ban giám đốc', manager: 'Quản lý cơ sở', teacher: 'Giáo viên', parent: 'Phụ huynh' }
const roleAvatars = { admin: 'QT', manager: 'QL', teacher: 'NH', parent: 'TQ' }
const roleFirstTab = { admin: 'dashboard', manager: 'dashboard', teacher: 'dashboard' }
const roleNavigation = {
  admin: [
    ['dashboard', 'Dashboard tổng quan', 'fa-table-columns'], ['crm', 'CRM', 'fa-address-book'],
    ['education', 'Học vụ & Đào tạo', 'fa-book-open'], ['hr', 'Quản lý nhân sự', 'fa-users'],
    ['finance', 'Tài chính & Kế toán', 'fa-wallet'], ['support', 'Chăm sóc khách hàng', 'fa-headset'],
    ['reports', 'Báo cáo', 'fa-chart-pie'], ['settings', 'Cài đặt', 'fa-gear'],
  ],
  manager: [
    ['dashboard', 'Dashboard tổng quan', 'fa-table-columns'], ['crm', 'CRM', 'fa-address-book'],
    ['education', 'Học vụ & Đào tạo', 'fa-book-open'], ['hr', 'Quản lý nhân sự', 'fa-users'],
    ['finance', 'Tài chính & Kế toán', 'fa-wallet'], ['support', 'Chăm sóc khách hàng', 'fa-headset'],
    ['reports', 'Báo cáo', 'fa-chart-pie'], ['settings', 'Cài đặt', 'fa-gear'],
  ],
  teacher: [
    ['dashboard', 'Dashboard', 'fa-table-columns'], ['classes', 'Lớp học', 'fa-chalkboard'],
    ['results', 'Quản lý kết quả', 'fa-square-poll-vertical'],
    ['proposal', 'Đề xuất dạy bù/thay', 'fa-calendar-plus'],
  ],
  parent: [
    ['schedule', 'Lịch học của con', 'fa-calendar-days'],
    ['results', 'Kết quả', 'fa-chart-line'],
    ['fees', 'Học phí', 'fa-receipt'],
    ['children', 'Danh sách con', 'fa-children'],
  ],
}
const accountsStorageKey = 'hoa-ma-toan-demo-accounts-v1'
const sessionStorageKey = 'hoa-ma-toan-demo-session-v1'
const activeRoleStorageKey = 'hoa-ma-toan-demo-active-role-v1'
const children = {
  'minh-anh': { name: 'Nguyễn Minh Anh', avatar: 'MA', birth: '15/08/2012', grade: 'Toán nâng cao 5A', gender: 'Nữ' },
  'bao-nam': { name: 'Lê Bảo Nam', avatar: 'BN', birth: '22/03/2010', grade: 'Luyện thi vào 10', gender: 'Nam' },
  'thao-chi': { name: 'Trần Thảo Chi', avatar: 'TC', birth: '04/11/2014', grade: 'Toán cơ bản lớp 3', gender: 'Nữ' },
}

function loadAccounts() {
  try {
    const saved = JSON.parse(window.localStorage.getItem(accountsStorageKey) || '[]')
    if (!Array.isArray(saved)) throw new TypeError('Danh sách tài khoản demo không hợp lệ.')
    return [...demoAccounts, ...saved.filter(account =>
      account && typeof account.username === 'string'
      && !demoAccounts.some(demo => demo.username === account.username.toLowerCase()),
    )]
  } catch (error) {
    console.error('Không thể đọc tài khoản demo đã lưu:', error)
    return [...demoAccounts]
  }
}

function loadSession(accounts) {
  try {
    const saved = JSON.parse(window.localStorage.getItem(sessionStorageKey) || 'null')
    return saved ? accounts.find(account =>
      account.username === saved.username && account.role === saved.role,
    ) || null : null
  } catch (error) {
    console.error('Không thể khôi phục phiên demo:', error)
    window.localStorage.removeItem(sessionStorageKey)
    return null
  }
}

export default function useLegacyDashboard() {
  const [accounts, setAccounts] = useState(loadAccounts)
  const [session, setSession] = useState(() => loadSession(loadAccounts()))
  const [activeRole, setActiveRole] = useState(() => {
    try {
      const savedRole = window.localStorage.getItem(activeRoleStorageKey)
      return roleTitles[savedRole] ? savedRole : loadSession(loadAccounts())?.role || 'admin'
    } catch (error) {
      console.error('Không thể khôi phục vai trò demo:', error)
      return loadSession(loadAccounts())?.role || 'admin'
    }
  })
  const [activeTab, setActiveTab] = useState(() => {
    const role = loadSession(loadAccounts())?.role || 'admin'
    return roleFirstTab[role]
  })
  const [parentView, setParentView] = useState('schedule')
  const [authView, setAuthView] = useState('login')
  const [toastMessage, setToastMessage] = useState('')
  const [authMessages, setAuthMessages] = useState({})
  const [loginRole, setLoginRole] = useState('admin')
  const [loginUsername, setLoginUsername] = useState('admin')
  const [loginPassword, setLoginPassword] = useState('123456')
  const [showPassword, setShowPassword] = useState(false)
  const [rememberLogin, setRememberLogin] = useState(false)
  const [resetAccount, setResetAccount] = useState(null)
  const [selectedChild, setSelectedChild] = useState('minh-anh')
  const [financeTab, setFinanceTab] = useState('cashflow')
  const [aiOpen, setAiOpen] = useState(false)
  const [aiInput, setAiInput] = useState('')
  const [aiMessages, setAiMessages] = useState([])
  const [aiPending, setAiPending] = useState(false)
  const aiTimer = useRef(null)

  useEffect(() => {
    if (!toastMessage) return undefined
    const timer = window.setTimeout(() => setToastMessage(''), 2800)
    return () => window.clearTimeout(timer)
  }, [toastMessage])

  useEffect(() => () => window.clearTimeout(aiTimer.current), [])

  function showToast(message) {
    setToastMessage(message)
  }

  function setAuthMessage(key, message, success = false) {
    setAuthMessages(current => ({ ...current, [key]: { message, success } }))
  }

  function showAuthView(view) {
    setAuthView(view)
    setAuthMessages({})
  }

  function changeRole(role) {
    if (!roleTitles[role]) return
    setActiveRole(role)
    setActiveTab(roleFirstTab[role] || 'dashboard')
    if (role === 'parent') setParentView('children')
    try {
      window.localStorage.setItem(activeRoleStorageKey, role)
    } catch (error) {
      console.error('Không thể lưu vai trò demo:', error)
      showToast('Vai trò đã đổi trong phiên này nhưng không thể lưu vào trình duyệt.')
    }
  }

  function handleClick(event) {
    const target = event.target.closest('button')
    if (!target || !event.currentTarget.contains(target)) return

    if (target.dataset.authView) {
      showAuthView(target.dataset.authView)
      return
    }
    if (target.hasAttribute('data-toggle-password')) {
      setShowPassword(current => !current)
      return
    }
    if (target.dataset.key) {
      setActiveTab(target.dataset.key)
      if (target.dataset.key === 'finance') setFinanceTab('cashflow')
      return
    }
    if (target.dataset.parentView) {
      setParentView(target.dataset.parentView)
      return
    }
    if (target.dataset.selectChild) {
      setSelectedChild(target.dataset.selectChild)
      setParentView('schedule')
      return
    }
    if (target.dataset.financeTab) {
      setFinanceTab(target.dataset.financeTab)
      return
    }
    if (target.id === 'btn-logout') {
      setSession(null)
      window.localStorage.removeItem(sessionStorageKey)
      window.localStorage.removeItem(activeRoleStorageKey)
      setLoginPassword('')
      setAuthView('login')
      return
    }
    if (target.id === 'notification-button') {
      showToast('Bạn có 3 thông báo mới cần xem.')
      return
    }
    if (target.id === 'ai-launcher') {
      setAiOpen(open => !open)
      if (!aiMessages.length) {
        setAiMessages([{ sender: 'assistant', text: 'Xin chào! Mình là trợ lý Hòa Ma, trực 24/7. Bạn có thể xin nghỉ, đổi lớp, hỏi học phí hoặc gửi phản ánh; mình sẽ trả lời và tạo yêu cầu cho cơ sở.' }])
      }
      return
    }
    if (target.id === 'ai-close') {
      setAiOpen(false)
      return
    }
    if (target.id === 'ai-clear') {
      window.clearTimeout(aiTimer.current)
      setAiPending(false)
      setAiMessages([{ sender: 'assistant', text: 'Hội thoại mới đã sẵn sàng. Bạn cần xin nghỉ, đổi lớp, hỏi học phí hay gửi phản ánh?' }])
      return
    }

    const action = target.dataset.action
    if (!action) return
    const messages = {
      'add-student': 'Đã mở biểu mẫu thêm học viên (bản demo).',
      'add-lead': 'Đã mở biểu mẫu khách hàng tiềm năng (bản demo).',
      'add-class': 'Đã mở biểu mẫu tạo lớp học (bản demo).',
      'add-employee': 'Đã mở biểu mẫu thêm nhân sự (bản demo).',
      'add-ticket': 'Đã mở biểu mẫu yêu cầu hỗ trợ (bản demo).',
      review: 'Đã ghi nhận yêu cầu xem xét kỳ lương.',
      remind: 'Đã gửi nhắc học phí đến phụ huynh (bản demo).',
      'create-income': 'Đã mở biểu mẫu tạo phiếu thu.',
      'create-expense': 'Đã mở biểu mẫu tạo phiếu chi.',
      attendance: 'Đã mở danh sách điểm danh lớp học.',
      students: 'Đang mở danh sách học sinh của lớp.',
      'save-results': 'Kết quả học tập đã được lưu trên bản demo.',
      'new-proposal': 'Đã mở biểu mẫu đề xuất dạy bù / dạy thay.',
      'save-settings': 'Cài đặt đã được lưu trên bản demo.',
      'payment-history': 'Đang hiển thị toàn bộ lịch sử thanh toán.',
      vietqr: 'VietQR bản demo: vui lòng xác nhận thông tin thanh toán với trung tâm.',
      export: 'Xuất CSV sẽ được nối với dữ liệu thật khi tích hợp API.',
    }
    showToast(messages[action] || 'Thao tác đã được ghi nhận.')
  }

  function handleChange(event) {
    const target = event.target
    if (target.id === 'login-role') {
      setLoginRole(target.value)
      const account = demoAccounts.find(item => item.role === target.value)
      if (account) {
        setLoginUsername(account.username)
        setLoginPassword(account.password)
      }
    } else if (target.id === 'role-selector') {
      changeRole(target.value)
      setSession(current => current ? { ...current, role: target.value } : current)
    } else if (target.id === 'remember-login') {
      setRememberLogin(target.checked)
    } else if (target.id === 'login-username') {
      setLoginUsername(target.value)
    } else if (target.id === 'login-password') {
      setLoginPassword(target.value)
    } else if (target.id === 'ai-input') {
      setAiInput(target.value)
    }
  }

  function handleSubmit(event) {
    const form = event.target
    if (!form.matches('form')) return
    event.preventDefault()
    const value = id => form.querySelector(`#${id}`)?.value || ''

    if (form.id === 'login-form') {
      const account = accounts.find(item =>
        item.username.toLowerCase() === value('login-username').trim().toLowerCase()
        && item.password === value('login-password')
        && item.role === loginRole,
      )
      if (!account) {
        setAuthMessage('login', 'Thông tin đăng nhập hoặc vai trò chưa chính xác. Vui lòng kiểm tra và thử lại.')
        return
      }
      setSession(account)
      changeRole(account.role)
      setAuthMessage('login', '')
      try {
        if (rememberLogin) {
          window.localStorage.setItem(sessionStorageKey, JSON.stringify({
            username: account.username,
            role: account.role,
          }))
        } else {
          window.localStorage.removeItem(sessionStorageKey)
        }
      } catch (error) {
        console.error('Không thể lưu phiên demo:', error)
        showToast('Đã đăng nhập, nhưng trình duyệt không cho phép ghi nhớ phiên.')
      }
      return
    }

    if (form.id === 'register-form') {
      const username = value('register-username').trim().toLowerCase()
      const email = value('register-email').trim().toLowerCase()
      if (accounts.some(account => account.username.toLowerCase() === username)) {
        setAuthMessage('register', 'Tên đăng nhập đã được sử dụng. Hãy chọn tên khác.')
        return
      }
      if (accounts.some(account => account.email.toLowerCase() === email)) {
        setAuthMessage('register', 'Email này đã được liên kết với một tài khoản.')
        return
      }
      if (value('register-password') !== value('register-confirm')) {
        setAuthMessage('register', 'Mật khẩu xác nhận chưa khớp.')
        return
      }
      const account = {
        username,
        email,
        password: value('register-password'),
        role: value('register-role'),
        name: value('register-name').trim(),
      }
      const nextAccounts = [...accounts, account]
      try {
        window.localStorage.setItem(accountsStorageKey, JSON.stringify(nextAccounts.filter(item =>
          !demoAccounts.some(demo => demo.username === item.username),
        )))
        setAccounts(nextAccounts)
        setLoginUsername(username)
        setLoginRole(account.role)
        setLoginPassword('')
        setAuthMessage('login', 'Tạo tài khoản demo thành công. Hãy đăng nhập bằng mật khẩu vừa đăng ký.', true)
        setAuthView('login')
        form.reset()
      } catch (error) {
        console.error('Không thể lưu tài khoản demo:', error)
        setAuthMessage('register', 'Không thể lưu tài khoản trong trình duyệt này.')
      }
      return
    }

    if (form.id === 'forgot-form') {
      const account = accounts.find(item =>
        item.username.toLowerCase() === value('forgot-username').trim().toLowerCase()
        && item.email.toLowerCase() === value('forgot-email').trim().toLowerCase(),
      )
      if (!account) {
        setAuthMessage('forgot', 'Không tìm thấy tài khoản khớp với tên đăng nhập và email này.')
        return
      }
      setResetAccount(account.username)
      setAuthMessage('reset', `Đã xác minh ${account.username}. Hãy tạo mật khẩu mới.`)
      setAuthView('reset')
      return
    }

    if (form.id === 'reset-form') {
      if (!resetAccount) {
        setAuthMessage('reset', 'Phiên xác minh đã hết. Vui lòng xác minh tài khoản lại.')
        setAuthView('forgot')
        return
      }
      if (value('reset-password') !== value('reset-confirm')) {
        setAuthMessage('reset', 'Mật khẩu xác nhận chưa khớp.')
        return
      }
      const updatedAccounts = accounts.map(account => account.username === resetAccount
        ? { ...account, password: value('reset-password') }
        : account)
      try {
        window.localStorage.setItem(accountsStorageKey, JSON.stringify(updatedAccounts.filter(item =>
          !demoAccounts.some(demo => demo.username === item.username),
        )))
        setAccounts(updatedAccounts)
        setLoginUsername(resetAccount)
        setLoginPassword('')
        setResetAccount(null)
        setAuthMessage('login', 'Đã cấp mật khẩu mới trong bản demo. Vui lòng đăng nhập.', true)
        setAuthView('login')
      } catch (error) {
        console.error('Không thể cập nhật mật khẩu demo:', error)
        setAuthMessage('reset', 'Không thể lưu mật khẩu mới trong trình duyệt này.')
      }
      return
    }

    if (form.id === 'ai-form') submitAIQuestion(value('ai-input'))
  }

  function submitAIQuestion(question) {
    const text = String(question || '').trim()
    if (!text || aiPending) return
    setAiInput('')
    setAiPending(true)
    setAiMessages(current => [...current, { sender: 'user', text }])
    aiTimer.current = window.setTimeout(() => {
      // Chatbot trả lời từ cơ sở tri thức và tự tạo ticket CSKH khi cần người xử lý.
      const { reply, ticket } = answerChat(text, session?.name ? `${session.name} (chatbot)` : undefined)
      setAiMessages(current => [...current, { sender: 'assistant', text: reply }])
      if (ticket) showToast(`Chatbot đã tạo yêu cầu ${ticket.id} trong phân hệ CSKH.`)
      setAiPending(false)
    }, 420)
  }

  function handleKeyDown(event) {
    if (event.key === 'Enter' && event.target.id === 'ai-input' && !event.shiftKey) {
      event.preventDefault()
      submitAIQuestion(event.target.value)
    } else if (event.key === 'Escape') {
      setAiOpen(false)
    } else if (event.key === 'Enter' && event.target.id === 'global-search' && event.target.value.trim()) {
      showToast(`Đang tìm kiếm: ${event.target.value.trim()}`)
    }
  }

  return {
    roleTitles, roleAvatars, roleNavigation,
    accounts, session, activeRole, activeTab, parentView, authView, toastMessage,
    authMessages, loginRole, loginUsername, loginPassword, showPassword,
    rememberLogin, selectedChild, selectedChildInfo: children[selectedChild],
    financeTab, aiOpen, aiInput, aiMessages, aiPending,
    setAiInput, setAiOpen, setAiMessages, setAiPending, setShowPassword,
    setActiveRole, setActiveTab, setParentView, setFinanceTab, setToastMessage,
    handleClick, handleChange, handleSubmit, handleKeyDown,
  }
}
