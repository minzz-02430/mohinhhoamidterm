import { useEffect, useMemo, useState } from 'react'
import {
  ArrowRight,
  ArrowUpRight,
  Bell,
  BookOpenCheck,
  CalendarDays,
  Check,
  ChevronDown,
  CircleAlert,
  Clock3,
  GraduationCap,
  LayoutDashboard,
  LogOut,
  Mail,
  MapPin,
  MessageCircle,
  Menu,
  MoreHorizontal,
  Phone,
  Plus,
  Search,
  Settings2,
  Users,
  Wallet,
  X,
} from 'lucide-react'
import { getMyChildrenReports } from './api/reports'
import { loginWithPassword, registerAccount } from './api/auth'
import { getCurrentMonthRevenue } from './api/finance'
import Dashboard from './components/Dashboard'
import {
  createSupportRequest,
  getPendingSupportRequests,
  updateSupportRequestStatus,
} from './api/support'
import './App.css'

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000/api/v1'

const navigation = [
  { id: 'overview', label: 'Vận hành ngày', icon: LayoutDashboard },
  { id: 'teachers', label: 'Giáo viên cơ sở', icon: GraduationCap },
  { id: 'students', label: 'Học viên cơ sở', icon: Users },
  { id: 'schedule', label: 'Xếp lịch học', icon: CalendarDays },
  { id: 'tuition', label: 'Thu học phí', icon: Wallet },
  { id: 'support', label: 'Yêu cầu hỗ trợ', icon: MessageCircle },
]

const managerNavigation = [
  { id: 'overview', label: 'Tổng quan vận hành', icon: LayoutDashboard },
  { id: 'leads', label: 'Leads tuyển sinh', icon: Users },
  { id: 'contracts', label: 'Hợp đồng', icon: Wallet },
  { id: 'staff-tasks', label: 'Giao việc nhân viên', icon: Check },
  { id: 'support', label: 'Duyệt yêu cầu hỗ trợ', icon: MessageCircle },
]

const adminNavigation = [
  { id: 'overview', label: 'Tổng quan hệ thống', icon: LayoutDashboard },
  { id: 'leads', label: 'Leads tuyển sinh', icon: Users },
  { id: 'contracts', label: 'Hợp đồng', icon: Wallet },
  { id: 'staff-tasks', label: 'Giao việc nhân viên', icon: Check },
  { id: 'support', label: 'Duyệt yêu cầu hỗ trợ', icon: MessageCircle },
]

const teacherNavigation = [
  { id: 'overview', label: 'Lịch dạy học', icon: CalendarDays },
  { id: 'grades', label: 'Điểm danh & Nhận xét', icon: GraduationCap },
  { id: 'classes', label: 'Danh sách lớp phụ trách', icon: BookOpenCheck },
]

const parentNavigation = [
  { id: 'children', label: 'Tổng quan con học', icon: Users },
  { id: 'schedule', label: 'Lịch học của con', icon: CalendarDays },
  { id: 'feedback', label: 'Nhận xét của gia sư', icon: GraduationCap },
  { id: 'payments', label: 'Đóng học phí', icon: Wallet },
  { id: 'support', label: 'Khiếu nại / Yêu cầu', icon: MessageCircle },
]

const demoRoles = {
  branchManager: {
    name: 'Nguyễn Minh Long',
    initials: 'ML',
    title: 'Quản lý cơ sở',
    staffCode: '',
    branch: 'Cơ sở 1 - Nguyễn Chí Thanh',
  },
  director: {
    name: 'Nguyễn Minh Anh',
    initials: 'MA',
    title: 'Ban giám đốc',
    staffCode: '',
    branch: 'Toàn hệ thống',
  },
  teacher: {
    name: 'Trần Quốc Bảo',
    initials: 'TB',
    title: 'Giáo viên Toán',
    staffCode: 'GV-024',
    branch: 'Cơ sở 1 - Nguyễn Chí Thanh',
  },
  parent: {
    name: 'Nguyễn Minh Quân',
    initials: 'NQ',
    title: 'Phụ huynh học sinh',
    staffCode: '',
    branch: '',
  },
}

const roleTitles = {
  admin: 'Ban giám đốc',
  manager: 'Quản lý cơ sở',
  sales: 'Nhân viên kinh doanh',
  accountant: 'Kế toán',
  tutor: 'Gia sư',
  parent: 'Phụ huynh',
  student: 'Học sinh',
}

const demoAccounts = [
  { label: 'Quản lý cơ sở', email: 'manager@trungtam.com' },
  { label: 'Ban giám đốc', email: 'admin@trungtam.com' },
  { label: 'Phụ huynh', email: 'demo.parent.huong@hoamatoan.vn' },
  { label: 'Gia sư', email: 'demo.tutor.long@hoamatoan.vn' },
  { label: 'Kinh doanh', email: 'demo.sales@hoamatoan.vn' },
]

function getViewRole(userRole) {
  if (userRole === 'parent') return 'parent'
  if (userRole === 'tutor') return 'teacher'
  if (userRole === 'admin') return 'director'
  if (userRole === 'manager') return 'branchManager'
  if (['sales', 'accountant'].includes(userRole)) return 'branchManager'
  return null
}

const roleNavigation = {
  branchManager: managerNavigation,
  director: adminNavigation,
  teacher: teacherNavigation,
  parent: parentNavigation,
}

const weekDays = (() => {
  const today = new Date()
  const monday = new Date(today)
  monday.setDate(today.getDate() - ((today.getDay() + 6) % 7))
  return Array.from({ length: 7 }, (_, index) => {
    const date = new Date(monday)
    date.setDate(monday.getDate() + index)
    return {
      label: ['Thứ 2', 'Thứ 3', 'Thứ 4', 'Thứ 5', 'Thứ 6', 'Thứ 7', 'Chủ nhật'][index],
      date: new Intl.DateTimeFormat('vi-VN', { day: '2-digit', month: '2-digit' }).format(date),
      isToday: date.toDateString() === today.toDateString(),
    }
  })
})()

const teacherScheduleSeed = [
  { id: 'lesson-1', day: 0, shift: 2, time: '16:00 – 17:30', name: 'Toán nâng cao 9A', room: 'P. 203', color: 'orange' },
  { id: 'lesson-2', day: 1, shift: 1, time: '14:00 – 15:30', name: 'Luyện thi TSA', room: 'P. 301', color: 'blue' },
  { id: 'lesson-3', day: 2, shift: 2, time: '16:00 – 17:30', name: 'Toán nâng cao 9B', room: 'P. 202', color: 'yellow' },
  { id: 'lesson-4', day: 3, shift: 3, time: '18:00 – 19:30', name: 'Toán tư duy 8A', room: 'P. 203', color: 'blue' },
  { id: 'lesson-5', day: 4, shift: 1, time: '14:00 – 15:30', name: 'Toán nâng cao 9A', room: 'P. 203', color: 'orange' },
  { id: 'lesson-6', day: 5, shift: 0, time: '08:00 – 09:30', name: 'Luyện thi TSA', room: 'P. 301', color: 'yellow' },
]

const teacherClassesSeed = [
  { name: 'Toán nâng cao 9A', students: 18, room: 'Phòng 203', schedule: 'Thứ 2, 16:00', color: 'orange' },
  { name: 'Luyện thi TSA', students: 14, room: 'Phòng 301', schedule: 'Thứ 3, 14:00', color: 'blue' },
  { name: 'Toán nâng cao 9B', students: 16, room: 'Phòng 202', schedule: 'Thứ 4, 16:00', color: 'yellow' },
]

const todayLabel = new Intl.DateTimeFormat('vi-VN', {
  weekday: 'long',
  day: 'numeric',
  month: 'long',
}).format(new Date())

const formatLessonDate = value => {
  const date = String(value ?? '').slice(0, 10)
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(date)
  return match ? `${match[3]}/${match[2]}/${match[1]}` : value
}

const initialAlerts = [
  {
    id: 'tuition',
    category: 'Công nợ học phí',
    title: 'Học phí quá hạn trên 30 ngày',
    detail: '12 học viên · Tổng cần thu 18.600.000đ',
    level: 'critical',
    icon: Wallet,
    action: 'Xem công nợ',
    destination: 'tuition',
  },
  {
    id: 'room',
    category: 'Lịch học',
    title: '4 lớp có nguy cơ trùng lịch phòng',
    detail: 'Phòng 201 · Thứ 4, ca 2',
    level: 'warning',
    icon: CalendarDays,
    action: 'Kiểm tra lịch',
    destination: 'schedule',
  },
  {
    id: 'teacher',
    category: 'Nhân sự',
    title: 'Giáo viên gửi đề xuất nghỉ',
    detail: 'Cô Lan · Thứ 6, ngày 30/10',
    level: 'warning',
    icon: GraduationCap,
    action: 'Xem đề xuất',
    destination: 'teachers',
  },
]

const activitySeed = [
  {
    initials: 'TL',
    name: 'Cô Lan',
    action: 'vừa điểm danh lớp',
    subject: 'Toán nâng cao 9A',
    time: '5 phút trước',
    color: 'orange',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&h=120&fit=crop&crop=faces',
  },
  {
    initials: 'TH',
    name: 'Thầy Hùng',
    action: 'cập nhật kết quả bài kiểm tra',
    subject: 'Đại số · Lớp 8B',
    time: '18 phút trước',
    color: 'blue',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&h=120&fit=crop&crop=faces',
  },
  {
    initials: 'NV',
    name: 'Tư vấn viên Mai',
    action: 'vừa ghi nhận học viên mới',
    subject: 'Luyện thi TSA',
    time: '42 phút trước',
    color: 'green',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&h=120&fit=crop&crop=faces',
  },
]

const kpiSeed = [
  {
    label: 'Giáo viên active',
    value: '18',
    caption: '16 đang dạy trong tuần này',
    icon: GraduationCap,
    color: 'orange',
    trend: '+2',
    trendDirection: 'up',
  },
  {
    label: 'Lớp đang chạy',
    value: '12',
    caption: 'Trong 14 lớp tại cơ sở',
    icon: BookOpenCheck,
    color: 'blue',
    trend: 'Ổn định',
    trendDirection: 'neutral',
  },
  {
    label: 'Học viên',
    value: '286',
    caption: 'Đang theo học tại cơ sở',
    icon: Users,
    color: 'green',
    trend: '+12',
    trendDirection: 'up',
  },
  {
    label: 'Doanh thu tháng này',
    value: '86.450.000đ',
    caption: 'So với tháng trước',
    icon: Wallet,
    color: 'violet',
    trend: '+8,2%',
    trendDirection: 'up',
  },
]

const pageDescriptions = {
  teachers: 'Theo dõi đội ngũ giáo viên và các đề xuất cần xử lý tại cơ sở.',
  students: 'Quản lý danh sách học viên đang theo học tại cơ sở.',
  schedule: 'Sắp xếp lớp học, phòng học và lịch học bù.',
  tuition: 'Theo dõi các khoản học phí và tình trạng thanh toán.',
  classes: 'Xem danh sách lớp và sĩ số học viên đang phụ trách.',
  grades: 'Theo dõi kết quả kiểm tra và tiến độ học tập của học viên.',
  proposals: 'Gửi đề xuất dạy bù hoặc đổi lịch đến quản lý cơ sở.',
}

function Logo() {
  return (
    <a className="brand" href="#overview" aria-label="Hòa Ma Toán, trang chủ">
      <span className="brand-mark">H<span>M</span></span>
      <span className="brand-copy">
        <strong>HÒA MA TOÁN</strong>
        <small>Hệ thống quản lý trung tâm</small>
      </span>
    </a>
  )
}

function Header({ role, user, onSignOut, onToggleSidebar, onSearch, searchValue, onOpenNotifications }) {
  const [roleMenuOpen, setRoleMenuOpen] = useState(false)
  const demoProfile = demoRoles[role]
  const profile = {
    ...demoProfile,
    name: user.name || user.email,
    title: roleTitles[user.role] || 'Tài khoản',
    initials: (user.name || user.email).split(/\s+/).slice(-2).map(part => part[0]).join('').toUpperCase(),
  }
  const isTeacher = role === 'teacher'
  const isParent = role === 'parent'
  const isDirector = role === 'director'
  const avatarImage = isTeacher
    ? 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=96&h=96&fit=crop&crop=faces'
    : isParent
      ? 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=96&h=96&fit=crop&crop=faces'
      : 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=96&h=96&fit=crop&crop=faces'

  return (
    <header className={`topbar${isParent ? ' parent-topbar' : ''}`}>
      <button
        className="icon-button mobile-menu-button"
        type="button"
        aria-label="Mở menu"
        onClick={onToggleSidebar}
      >
        <Menu size={19} />
      </button>
      <Logo />

      {isParent ? (
        <div className="parent-header-greeting">
          Xin chào, <strong>{profile.name}</strong>
          <span>Chúc gia đình một ngày thật vui.</span>
        </div>
      ) : <div className="header-context">
        <span className="school-year">
          <CalendarDays size={15} />
          <span>Năm học <strong>2026–2027</strong></span>
        </span>
        <span className="context-divider" />
        <span className="branch-context">
          {isTeacher ? <GraduationCap size={15} /> : <MapPin size={15} />}
          <span>
            <small>{isTeacher ? `Mã giáo viên · ${profile.staffCode}` : isDirector ? 'Phạm vi quản lý' : 'Cơ sở đang quản lý'}</small>
            <strong>{profile.branch}</strong>
          </span>
          {!isTeacher && <ChevronDown size={14} />}
        </span>
      </div>}

      {!isParent && <label className="topbar-search">
        <Search size={17} aria-hidden="true" />
        <input
          type="search"
          value={searchValue}
          onChange={event => onSearch(event.target.value)}
          placeholder={isTeacher ? 'Tìm lớp phụ trách...' : 'Tìm cảnh báo...'}
          aria-label={isTeacher ? 'Tìm lớp phụ trách' : 'Tìm cảnh báo'}
        />
        <kbd>⌘ K</kbd>
      </label>}

      <button
        className="icon-button notification-button"
        type="button"
        aria-label="Thông báo"
        onClick={onOpenNotifications}
      >
        <Bell size={18} />
        <span className="notification-dot" />
      </button>

      <span className="topbar-divider" />
      <div className="profile-menu-wrap">
        <button
          className="profile-button"
          type="button"
          aria-label={`Tài khoản ${profile.name}`}
          aria-expanded={roleMenuOpen}
          onClick={() => setRoleMenuOpen(open => !open)}
        >
          <span className={`profile-avatar${isTeacher ? ' teacher' : ''}${isParent ? ' parent' : ''}`}>
            <img
              src={avatarImage}
              alt=""
              onError={event => {
                event.currentTarget.style.display = 'none'
                event.currentTarget.parentElement.textContent = profile.initials
              }}
            />
          </span>
          <span className="profile-copy">
            <strong>{profile.name}</strong>
            <small>{profile.title}</small>
          </span>
          <ChevronDown className="profile-chevron" size={15} />
        </button>
        {roleMenuOpen && (
          <div className="role-menu account-menu">
            <span className="role-menu-label">PHIÊN ĐĂNG NHẬP</span>
            <p className="account-menu-email">{user.email}</p>
            <button className="account-signout" type="button" onClick={onSignOut}>
              <LogOut size={15} /> Đăng xuất
            </button>
          </div>
        )}
      </div>
    </header>
  )
}

function ParentTopNav({ activeItem, onNavigate }) {
  return (
    <nav className="parent-topnav" aria-label="Điều hướng phụ huynh">
      <div className="parent-topnav-inner">
        <span className="parent-nav-caption">CỔNG THÔNG TIN GIA ĐÌNH</span>
        <div className="parent-nav-links">
          {parentNavigation.map(({ id, label, icon: Icon }) => (
            <button
              className={`parent-nav-link${activeItem === id || (id === 'children' && activeItem === 'child-detail') ? ' is-active' : ''}`}
              key={id}
              type="button"
              onClick={() => onNavigate(id)}
              aria-current={activeItem === id ? 'page' : undefined}
            >
              <Icon size={16} strokeWidth={1.8} /> {label}
            </button>
          ))}
        </div>
        <span className="parent-nav-schoolyear"><CalendarDays size={14} /> Năm học 2026–2027</span>
      </div>
    </nav>
  )
}

function Sidebar({ role, userRole, activeItem, onNavigate, isOpen, onClose }) {
  const items = (roleNavigation[role] ?? []).filter(item =>
    item.id !== 'support' || ['admin', 'manager'].includes(userRole),
  )
  const isTeacher = role === 'teacher'
  const isDirector = role === 'director'

  return (
    <>
      <button
        className={`sidebar-backdrop${isOpen ? ' is-visible' : ''}`}
        type="button"
        aria-label="Đóng menu"
        onClick={onClose}
      />
      <aside className={`sidebar${isOpen ? ' is-open' : ''}`}>
        <div className="sidebar-heading">
          <span>KHÔNG GIAN LÀM VIỆC</span>
          <button type="button" className="sidebar-close icon-button" onClick={onClose} aria-label="Đóng menu">
            <X size={18} />
          </button>
        </div>
        <nav className="navigation" aria-label={isTeacher ? 'Điều hướng giáo viên' : isDirector ? 'Điều hướng ban giám đốc' : 'Điều hướng quản lý cơ sở'}>
          {items.map(({ id, label, icon: Icon }) => (
            <button
              className={`nav-item${activeItem === id ? ' is-active' : ''}`}
              type="button"
              key={id}
              onClick={() => onNavigate(id)}
              aria-current={activeItem === id ? 'page' : undefined}
            >
              <Icon size={18} strokeWidth={1.8} />
              <span>{label}</span>
              {id === 'overview' && <span className={`nav-indicator${isTeacher ? ' teacher' : ''}`} />}
            </button>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <div className={`branch-card${isTeacher ? ' teacher-branch-card' : ''}`}>
            <span className="branch-card-icon">{isTeacher ? <GraduationCap size={16} /> : isDirector ? <LayoutDashboard size={16} /> : <MapPin size={16} />}</span>
            <span>
              <small>{isTeacher ? 'HỒ SƠ GIÁO VIÊN' : isDirector ? 'PHẠM VI QUẢN LÝ' : 'CƠ SỞ CỦA BẠN'}</small>
              <strong>{isTeacher ? `Mã GV · ${demoRoles.teacher.staffCode}` : isDirector ? 'Toàn hệ thống' : 'Nguyễn Chí Thanh'}</strong>
            </span>
            <span className="branch-online" title={isTeacher ? 'Hồ sơ đang hoạt động' : isDirector ? 'Toàn hệ thống' : 'Cơ sở đang hoạt động'} />
          </div>
          <button className="settings-link" type="button">
            <Settings2 size={17} />
            <span>Cài đặt cá nhân</span>
          </button>
          <p className="sidebar-version">HÒA MA TOÁN <span>·</span> Phiên bản 1.0</p>
        </div>
      </aside>
    </>
  )
}

function TeacherDashboard({ onCreateProposal, searchValue, teacherSchedule = [], teacherClasses = [] }) {
  const query = searchValue.trim().toLocaleLowerCase('vi')
  const visibleClasses = (teacherClasses ?? []).filter(item =>
    `${item.name} ${item.room} ${item.schedule}`.toLocaleLowerCase('vi').includes(query),
  )
  const scheduleBySlot = Array.from({ length: 4 }, (_, shift) =>
    Array.from({ length: 7 }, (_, day) =>
      (teacherSchedule ?? []).find(item => item.day === day && item.shift === shift),
    ),
  )

  return (
    <div className="teacher-dashboard">
      <div className="teacher-page-heading">
        <div>
          <div className="breadcrumb">
            <span>Không gian giáo viên</span><span className="breadcrumb-slash">/</span><strong>Lịch dạy của tôi</strong>
          </div>
          <h1>Xin chào, thầy Bảo <span className="wave" aria-hidden="true">✦</span></h1>
          <p>Chúc thầy một ngày dạy học thật nhiều cảm hứng.</p>
        </div>
        <button className="secondary-button teacher-proposal-button" type="button" onClick={onCreateProposal}>
          <Clock3 size={16} /> Đề xuất đổi lịch
        </button>
      </div>

      <section className="teacher-profile-card surface-card" aria-label="Thông tin giáo viên">
        <div className="teacher-profile-main">
          <span className="teacher-profile-avatar">TB</span>
          <span className="teacher-profile-name">
            <small>HỒ SƠ GIÁO VIÊN</small>
            <strong>Trần Quốc Bảo</strong>
            <span>Giáo viên Toán <i /> Mã GV-024</span>
          </span>
        </div>
        <div className="teacher-profile-facts">
          <div><span>Giới tính</span><strong>Nam</strong></div>
          <div><span>Ngày sinh</span><strong>12/08/1992</strong></div>
          <div><span>Cơ sở đang dạy</span><strong><MapPin size={14} /> Nguyễn Chí Thanh</strong></div>
        </div>
        <span className="teacher-status"><span /> Đang giảng dạy</span>
      </section>

      <section className="teacher-schedule-card surface-card" aria-label="Thời khóa biểu tuần">
        <div className="teacher-schedule-header">
          <div>
            <span className="section-eyebrow">THỜI KHÓA BIỂU</span>
            <h2>Lịch dạy trong tuần</h2>
            <p>Các lớp và ca dạy được phân công cho thầy.</p>
          </div>
          <div className="teacher-week-control">
            <span className="teacher-week-label"><CalendarDays size={15} /> Tuần hiện tại</span>
            <span className="teacher-current-week">Năm học 2026–2027</span>
          </div>
        </div>

        <div className="schedule-legend" aria-label="Chú giải môn học">
          <span><i className="legend-dot orange" /> Toán nâng cao</span>
          <span><i className="legend-dot blue" /> Luyện thi TSA</span>
          <span><i className="legend-dot yellow" /> Toán tư duy</span>
        </div>

        <div className="teacher-calendar-scroll">
          <div className="teacher-calendar">
            <div className="calendar-corner">CA HỌC</div>
            {weekDays.map((day, index) => (
              <div className={`calendar-day-heading${day.isToday ? ' is-today' : ''}`} key={day.label}>
                <strong>{day.label}</strong>
                <span>{day.date}</span>
                {day.isToday && <i>Hôm nay</i>}
                {index !== 5 && index !== 6 && !day.isToday && <i className="day-spacer" aria-hidden="true">·</i>}
              </div>
            ))}
            {scheduleBySlot.map((slot, shift) => (
              <div className="calendar-row" key={`shift-${shift + 1}`}>
                <div className="calendar-shift"><strong>Ca {shift + 1}</strong><span>{['08–10h', '14–15h30', '16–17h30', '18–19h30'][shift]}</span></div>
                {slot.map((lesson, day) => (
                  <div className={`calendar-cell${weekDays[day].isToday ? ' is-today' : ''}`} key={`${shift}-${day}`}>
                    {lesson && (
                      <article className={`lesson-card ${lesson.color}`}>
                        <strong>{lesson.time}</strong>
                        <span>{lesson.name}</span>
                        <small><MapPin size={11} /> {lesson.room}</small>
                      </article>
                    )}
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
        <div className="schedule-footnote"><Clock3 size={14} /> Thời khóa biểu được cập nhật theo phân công mới nhất của trung tâm.</div>
      </section>

      <section className="teacher-classes-section" aria-label="Các lớp đang phụ trách">
        <div className="teacher-classes-heading">
          <div><span className="section-eyebrow">PHÂN CÔNG GIẢNG DẠY</span><h2>Lớp đang phụ trách</h2></div>
          <button className="text-button" type="button">Xem tất cả <ArrowRight size={15} /></button>
        </div>
        <div className="teacher-classes-grid">
          {visibleClasses.length > 0 ? visibleClasses.map(item => (
            <article className="teacher-class-card surface-card" key={item.name}>
              <div className="teacher-class-top">
                <span className={`teacher-class-icon ${item.color}`}><BookOpenCheck size={17} /></span>
                <span className="class-status"><i /> Đang học</span>
              </div>
              <h3>{item.name}</h3>
              <span className="teacher-class-course">Chương trình Toán · Năm học 2026–2027</span>
              <div className="teacher-class-meta">
                <span><Users size={14} /><strong>{item.students}</strong> học viên</span>
                <span><MapPin size={14} />{item.room}</span>
              </div>
              <div className="teacher-class-footer"><Clock3 size={13} /> {item.schedule} <ArrowRight size={14} /></div>
            </article>
          )) : (
            <p className="teacher-class-empty">Không tìm thấy lớp phụ trách phù hợp.</p>
          )}
        </div>
      </section>
    </div>
  )
}

function ParentDashboard({ activeItem, selectedChildId, onOpenChild, onBackToChildren }) {
  const [token] = useState(() => window.localStorage.getItem('token') || '')
  const [reports, setReports] = useState([])
  const [supportType, setSupportType] = useState('complaint')
  const [supportDescription, setSupportDescription] = useState('')
  const [supportStatus, setSupportStatus] = useState({ loading: false, error: '', success: '' })
  const [reportsLoading, setReportsLoading] = useState(Boolean(token))
  const [reportsError, setReportsError] = useState(
    token ? '' : 'Chưa tìm thấy token đăng nhập. Vui lòng đăng nhập lại để xem báo cáo.',
  )
  const children = useMemo(() => {
    const records = new Map()
    reports.forEach(report => {
      const id = String(report.student_id)
      const current = records.get(id) || {
        id,
        name: report.student_name,
        subject: report.subject,
        className: report.class_name,
        reports: [],
      }
      current.reports.push(report)
      records.set(id, current)
    })

    return Array.from(records.values()).map((child, index) => {
      const presentCount = child.reports.filter(report => report.attendance_status === 'present').length
      return {
        ...child,
        initials: child.name.trim().split(/\s+/).slice(-2).map(part => part[0]).join('').toUpperCase(),
        tone: index % 2 === 0 ? 'orange' : 'blue',
        presentCount,
        attendance: child.reports.length
          ? `${Math.round((presentCount / child.reports.length) * 100)}%`
          : '—',
      }
    })
  }, [reports])
  const selectedChild = children.find(child => child.id === selectedChildId)

  async function submitSupportRequest(event) {
    event.preventDefault()
    setSupportStatus({ loading: true, error: '', success: '' })

    try {
      await createSupportRequest(token, supportType, supportDescription)
      setSupportDescription('')
      setSupportStatus({ loading: false, error: '', success: 'Yêu cầu đã được gửi đến trung tâm.' })
    } catch (error) {
      setSupportStatus({
        loading: false,
        error: error.message || 'Không thể gửi yêu cầu hỗ trợ.',
        success: '',
      })
    }
  }

  useEffect(() => {
    if (!token) return undefined

    const controller = new AbortController()

    async function loadReports() {
      try {
        const result = await getMyChildrenReports(token, controller.signal)
        setReports(result)
      } catch (error) {
        if (error.name !== 'AbortError') {
          setReportsError(error.message || 'Không thể tải báo cáo học tập.')
        }
      } finally {
        if (!controller.signal.aborted) {
          setReportsLoading(false)
        }
      }
    }

    loadReports()
    return () => controller.abort()
  }, [token])

  if (activeItem === 'child-detail' && selectedChild) {
    return (
      <div className="parent-dashboard">
        <button className="parent-back-link" type="button" onClick={onBackToChildren}>
          <ArrowRight size={15} /> Danh sách con
        </button>
        <div className="parent-page-heading">
          <div>
            <span className="section-eyebrow">HỒ SƠ HỌC TẬP</span>
            <h1>Thông tin của {selectedChild.name}</h1>
            <p>Báo cáo điểm danh và nhận xét do giáo viên cập nhật.</p>
          </div>
          <span className={`child-avatar large ${selectedChild.tone}`}>{selectedChild.initials}</span>
        </div>

        <section className="child-detail-summary surface-card">
          <div className="child-summary-course">
            <span className={`child-course-icon ${selectedChild.tone}`}><BookOpenCheck size={20} /></span>
            <span><small>MÔN HỌC / LỚP</small><strong>{selectedChild.subject}</strong><span>{selectedChild.className}</span></span>
          </div>
          <div className="child-next-lesson"><CalendarDays size={16} /><span>SỐ BUỔI ĐÃ BÁO CÁO<strong>{selectedChild.reports.length} buổi học</strong></span></div>
        </section>

        <div className="child-detail-grid">
          <section className="surface-card child-detail-card attendance-detail">
            <div className="child-detail-title"><span className="child-detail-icon blue"><CalendarDays size={18} /></span><span><small>CHUYÊN CẦN</small><h2>Điểm danh</h2></span></div>
            <strong className="child-detail-metric">{selectedChild.attendance}</strong>
            <p>Tỷ lệ có mặt trong các buổi đã được báo cáo</p>
            <div className="attendance-progress"><span style={{ width: selectedChild.attendance }} /></div>
            <div className="attendance-last-row"><span><i className="attendance-dot present" />Có mặt</span><strong>{selectedChild.presentCount}</strong></div>
            <div className="attendance-last-row"><span><i className="attendance-dot upcoming" />Vắng mặt</span><strong>{selectedChild.reports.length - selectedChild.presentCount}</strong></div>
          </section>

          <section className="surface-card child-detail-card test-detail">
            <div className="child-detail-title"><span className="child-detail-icon orange"><GraduationCap size={18} /></span><span><small>NHẬN XÉT GIÁO VIÊN</small><h2>Báo cáo gần đây</h2></span></div>
            {selectedChild.reports.slice(0, 3).map(report => (
              <div className="test-detail-meta" key={report.report_id}>
                <span>{formatLessonDate(report.lesson_date)} · {report.attendance_status === 'present' ? 'Có mặt' : 'Vắng mặt'}</span>
                <strong>{report.tutor_comment || 'Chưa có nhận xét.'}</strong>
              </div>
            ))}
          </section>
        </div>
      </div>
    )
  }

  if (activeItem === 'payments') {
    return (
      <div className="parent-dashboard">
        <div className="parent-page-heading">
          <div><span className="section-eyebrow">THANH TOÁN</span><h1>Lịch sử đóng phí</h1><p>Theo dõi học phí của các con trong gia đình.</p></div>
        </div>
        <section className="surface-card parent-payments-card">
          <p className="parent-session-reports-state">
            Backend hiện chưa có API tra cứu lịch sử hóa đơn theo phụ huynh. Để tránh hiển thị giao dịch mẫu như dữ liệu thật, lịch sử học phí sẽ xuất hiện khi API này được bổ sung.
          </p>
        </section>
      </div>
    )
  }

  if (activeItem === 'contact') {
    return (
      <div className="parent-dashboard">
        <div className="parent-page-heading">
          <div><span className="section-eyebrow">CHÚNG TÔI LUÔN SẴN SÀNG HỖ TRỢ</span><h1>Liên hệ trung tâm</h1><p>Kết nối với đội ngũ Hòa Ma Toán khi gia đình cần hỗ trợ.</p></div>
        </div>
        <section className="surface-card contact-center-card">
          <span className="contact-center-mark"><GraduationCap size={25} /></span>
          <div><h2>Trung tâm Hòa Ma Toán</h2><p>Đội ngũ tư vấn sẵn sàng giải đáp về lịch học, lộ trình và học phí.</p></div>
          <a className="contact-option" href="tel:02473001234"><span><Phone size={17} /></span><small>HOTLINE</small><strong>024 7300 1234</strong></a>
          <a className="contact-option" href="mailto:hello@hoamatoan.vn"><span><Mail size={17} /></span><small>EMAIL</small><strong>hello@hoamatoan.vn</strong></a>
          <div className="contact-option"><span><MapPin size={17} /></span><small>GIỜ HỖ TRỢ</small><strong>08:00 – 20:00 · Thứ 2–Chủ nhật</strong></div>
        </section>
        <form className="support-request-form surface-card" onSubmit={submitSupportRequest}>
          <div>
            <span className="section-eyebrow">GỬI YÊU CẦU TRỰC TIẾP</span>
            <h2>Trung tâm có thể giúp gì cho gia đình?</h2>
          </div>
          <label>
            Nội dung cần hỗ trợ
            <select value={supportType} onChange={event => setSupportType(event.target.value)}>
              <option value="complaint">Góp ý / phản ánh</option>
              <option value="leave_request">Xin nghỉ học</option>
              <option value="class_change">Đổi lớp / lịch học</option>
            </select>
          </label>
          <label>
            Mô tả
            <textarea
              value={supportDescription}
              onChange={event => setSupportDescription(event.target.value)}
              maxLength={5000}
              required
              rows={4}
            />
          </label>
          <div className="support-request-footer">
            <span
              className={supportStatus.success ? 'is-success' : ''}
              role={supportStatus.error ? 'alert' : 'status'}
            >
              {supportStatus.error || supportStatus.success || `${supportDescription.length}/5000 ký tự`}
            </span>
            <button type="submit" disabled={supportStatus.loading || !supportDescription.trim()}>
              {supportStatus.loading ? 'Đang gửi...' : 'Gửi yêu cầu'}
            </button>
          </div>
        </form>
      </div>
    )
  }

  return (
    <div className="parent-dashboard">
      <div className="parent-page-heading">
        <div>
          <span className="section-eyebrow">KHÔNG GIAN GIA ĐÌNH</span>
          <h1>Hành trình học tập của các con</h1>
          <p>Chọn hồ sơ để xem lịch học, điểm số và học phí riêng của từng con.</p>
        </div>
        <span className="children-count"><Users size={16} /> {children.length} học viên</span>
      </div>

      <div className="parent-children-list">
        {children.map(child => (
          <article className="parent-child-card surface-card" key={child.id}>
            <span className={`child-avatar ${child.tone}`}>{child.initials}</span>
            <div className="child-card-main">
              <span className="child-card-grade">Học viên được liên kết <i /> Theo dữ liệu Backend</span>
              <h2>{child.name}</h2>
              <div className="child-card-course"><BookOpenCheck size={16} /><strong>{child.subject}</strong><span>·</span><span>{child.className}</span></div>
              <div className="child-card-branch"><MapPin size={15} /><span>{child.reports.length} báo cáo buổi học</span></div>
            </div>
            <div className="child-card-next">
              <small>TỶ LỆ CÓ MẶT</small>
              <strong><CalendarDays size={15} />{child.attendance}</strong>
              <span>{child.presentCount}/{child.reports.length} buổi có mặt</span>
            </div>
            <button className="child-card-open" type="button" onClick={() => onOpenChild(child.id)} aria-label={`Xem hồ sơ ${child.name}`}>
              <ArrowRight size={19} />
            </button>
          </article>
        ))}
      </div>
      <section className="surface-card parent-session-reports" aria-live="polite">
        <div className="parent-session-reports-heading">
          <div>
            <span className="section-eyebrow">CẬP NHẬT TỪ GIÁO VIÊN</span>
            <h2>Báo cáo buổi học</h2>
          </div>
          {!reportsLoading && !reportsError && (
            <span className="children-count">{reports.length} buổi học</span>
          )}
        </div>
        {reportsLoading ? (
          <p className="parent-session-reports-state" role="status">Đang tải dữ liệu báo cáo...</p>
        ) : reportsError ? (
          <p className="parent-session-reports-error" role="alert">{reportsError}</p>
        ) : reports.length === 0 ? (
          <p className="parent-session-reports-state">Chưa có báo cáo buổi học.</p>
        ) : (
          <div className="parent-session-report-list">
            {reports.map(report => (
              <article className="parent-session-report" key={report.report_id}>
                <div className="parent-session-report-main">
                  <strong>{report.student_name}</strong>
                  <span>{report.subject} · {report.class_name}</span>
                </div>
                <div className="parent-session-report-meta">
                  <span>{formatLessonDate(report.lesson_date)}{report.start_time ? ` · ${report.start_time.slice(0, 5)}` : ''}</span>
                  <span className={`parent-session-attendance${report.attendance_status === 'present' ? ' is-present' : ' is-absent'}`}>
                    {report.attendance_status === 'present' ? 'Có mặt' : 'Vắng mặt'}
                  </span>
                </div>
                {report.tutor_comment && (
                  <p className="parent-session-report-comment">{report.tutor_comment}</p>
                )}
              </article>
            ))}
          </div>
        )}
      </section>
      <div className="parent-help-note"><span><Users size={17} /></span><p><strong>Một tài khoản, mọi thông tin của gia đình.</strong><br />Hồ sơ, kết quả và học phí được hiển thị riêng theo từng học viên.</p></div>
    </div>
  )
}

function PageHeading({ onCreateStudent, user }) {
  const firstName = user?.name?.trim().split(/\s+/).at(-1) || 'bạn'
  return (
    <div className="page-heading">
      <div>
        <div className="breadcrumb">
          <span>Trung tâm</span><span className="breadcrumb-slash">/</span><strong>Vận hành ngày</strong>
        </div>
        <div className="greeting-row">
          <h1>Xin chào, {firstName} <span className="wave" aria-hidden="true">✦</span></h1>
        </div>
        <p>Chúc bạn một ngày làm việc hiệu quả. Đây là tình hình tại cơ sở hôm nay.</p>
      </div>
      <div className="heading-actions">
        <span className="today-label"><CalendarDays size={15} /> {todayLabel}</span>
        <button className="primary-button" type="button" onClick={onCreateStudent}>
          <Plus size={17} strokeWidth={2.2} />
          <span>Thêm học viên</span>
        </button>
      </div>
    </div>
  )
}

function KpiGrid({ kpis = [] }) {
  return (
    <section className="kpi-grid" aria-label="Chỉ số vận hành cơ sở">
      {kpis?.map(({ label, value, caption, icon: Icon, color, trend, trendDirection }) => (
        <article className="kpi-card" key={label}>
          <div className="kpi-card-top">
            <span className="kpi-label">{label}</span>
            <span className={`kpi-icon ${color}`}><Icon size={18} strokeWidth={1.8} /></span>
          </div>
          <div className="kpi-value-row">
            <strong className="kpi-value">{value}</strong>
            <span className={`kpi-trend ${trendDirection}`}>
              {trendDirection === 'up' ? <ArrowUpRight size={14} /> : null}
              {trend}
            </span>
          </div>
          <p className="kpi-caption">{caption}</p>
        </article>
      ))}
    </section>
  )
}

function SectionHeader({ eyebrow, title, description, action }) {
  return (
    <div className="section-header">
      <div>
        {eyebrow && <span className="section-eyebrow">{eyebrow}</span>}
        <h2>{title}</h2>
        {description && <p>{description}</p>}
      </div>
      {action}
    </div>
  )
}

function ActionItems({ alerts, onOpenAlert, searchValue }) {
  return (
    <section className="surface-card action-card" aria-label="Các cảnh báo cần xử lý">
      <SectionHeader
        eyebrow="ƯU TIÊN HÔM NAY"
        title="Cần xử lý"
        description="Những việc cần bạn lưu ý tại cơ sở."
        action={<span className="alert-count"><span>{alerts.length}</span> việc cần xử lý</span>}
      />
      <div className="alert-list">
        {alerts.length > 0 ? alerts.map(({ id, category, title, detail, level, icon: Icon, action, destination }) => (
          <article className={`alert-item ${level}`} key={id}>
            <span className="alert-icon"><Icon size={18} strokeWidth={1.8} /></span>
            <span className="alert-copy">
              <span className="alert-category">{category}</span>
              <strong>{title}</strong>
              <small>{detail}</small>
            </span>
            <button className="alert-action" type="button" onClick={() => onOpenAlert(destination)}>
              {action}<ArrowRight size={14} />
            </button>
          </article>
        )) : (
          searchValue.trim()
            ? <div className="empty-alerts"><span><Search size={17} /></span><div><strong>Không tìm thấy cảnh báo phù hợp</strong><small>Thử tìm theo học phí, lịch học hoặc nhân sự.</small></div></div>
            : <div className="empty-alerts"><span><Check size={18} /></span><div><strong>Không còn việc cần xử lý</strong><small>Bạn đã hoàn tất tất cả cảnh báo.</small></div></div>
        )}
      </div>
    </section>
  )
}

function QuickActions({ onCreateStudent, onScheduleMakeup, onCreateReceipt }) {
  return (
    <section className="surface-card quick-card" aria-label="Thao tác nhanh">
      <SectionHeader
        eyebrow="LỐI TẮT"
        title="Thao tác nhanh"
        description="Tiết kiệm thời gian cho công việc thường ngày."
      />
      <div className="quick-action-list">
        <button className="quick-action" type="button" onClick={onCreateStudent}>
          <span className="quick-icon orange"><Users size={18} strokeWidth={1.8} /></span>
          <span className="quick-copy"><strong>Thêm học viên</strong><small>Ghi danh học viên mới</small></span>
          <ArrowRight className="quick-arrow" size={16} />
        </button>
        <button className="quick-action" type="button" onClick={onScheduleMakeup}>
          <span className="quick-icon blue"><CalendarDays size={18} strokeWidth={1.8} /></span>
          <span className="quick-copy"><strong>Xếp lịch học bù</strong><small>Sắp xếp buổi học thay thế</small></span>
          <ArrowRight className="quick-arrow" size={16} />
        </button>
        <button className="quick-action" type="button" onClick={onCreateReceipt}>
          <span className="quick-icon green"><Wallet size={18} strokeWidth={1.8} /></span>
          <span className="quick-copy"><strong>Tạo phiếu thu</strong><small>Ghi nhận học phí tại cơ sở</small></span>
          <ArrowRight className="quick-arrow" size={16} />
        </button>
      </div>
    </section>
  )
}

function ActivityFeed({ activities = [], onViewAll }) {
  return (
    <section className="surface-card activity-card" aria-label="Nhật ký hoạt động">
      <SectionHeader
        eyebrow="CẬP NHẬT MỚI NHẤT"
        title="Nhật ký hoạt động"
        description="Theo dõi những thay đổi trong ngày tại cơ sở."
        action={<button className="icon-button more-button" type="button" aria-label="Tùy chọn nhật ký" onClick={onViewAll}><MoreHorizontal size={20} /></button>}
      />
      <div className="activity-list">
        {activities?.map(({ initials, name, action, subject, time, color, avatar }) => (
          <article className="activity-item" key={`${name}-${initials}-${time}`}>
            <span className={`activity-avatar ${color}`}>
              {avatar ? <img src={avatar} alt={name} onError={event => {
                event.currentTarget.style.display = 'none'
                event.currentTarget.parentElement.textContent = initials
              }} /> : initials}
            </span>
            <span className="activity-copy">
              <span><strong>{name}</strong> {action}</span>
              <small><BookOpenCheck size={13} /> {subject}</small>
            </span>
            <time>{time}</time>
          </article>
        ))}
      </div>
      <button className="activity-footer-link" type="button" onClick={onViewAll}>
        Xem toàn bộ nhật ký <ArrowRight size={15} />
      </button>
    </section>
  )
}

function BranchManagerDashboard({ alerts, kpis = [], activities = [], onOpenAlert, searchValue, user, onCreateStudent, onScheduleMakeup, onCreateReceipt, onViewActivity }) {
  return (
    <>
      <PageHeading user={user} onCreateStudent={onCreateStudent} />
      <KpiGrid kpis={kpis} />
      <div className="dashboard-grid">
        <ActionItems alerts={alerts} onOpenAlert={onOpenAlert} searchValue={searchValue} />
        <QuickActions
          onCreateStudent={onCreateStudent}
          onScheduleMakeup={onScheduleMakeup}
          onCreateReceipt={onCreateReceipt}
        />
      </div>
      <ActivityFeed activities={activities} onViewAll={onViewActivity} />
    </>
  )
}

function DirectorDashboard({ user, token }) {
  const [revenue, setRevenue] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    const controller = new AbortController()
    getCurrentMonthRevenue(token, controller.signal)
      .then(setRevenue)
      .catch(requestError => {
        if (requestError.name !== 'AbortError') {
          setError(requestError.message || 'Không thể tải doanh thu tháng này.')
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false)
      })
    return () => controller.abort()
  }, [token])

  const monthLabel = revenue?.month
    ? new Intl.DateTimeFormat('vi-VN', { month: 'long', year: 'numeric' })
      .format(new Date(`${revenue.month}-01T00:00:00`))
    : 'tháng hiện tại'
  const formattedRevenue = revenue
    ? new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND', maximumFractionDigits: 0 })
      .format(Number(revenue.totalRevenue))
    : null

  return (
    <div className="director-dashboard">
      <div className="page-heading">
        <div>
          <div className="breadcrumb">
            <span>Toàn hệ thống</span><span className="breadcrumb-slash">/</span><strong>Ban giám đốc</strong>
          </div>
          <h1>Xin chào, {user.name || user.email}</h1>
          <p>Tổng quan điều hành và chỉ số doanh thu được ghi nhận từ hệ thống.</p>
        </div>
      </div>
      <section className="kpi-grid" aria-label="Chỉ số toàn hệ thống">
        <article className="kpi-card">
          <div className="kpi-card-top">
            <span className="kpi-label">DOANH THU {monthLabel.toLocaleUpperCase('vi')}</span>
            <span className="kpi-icon green"><Wallet size={18} strokeWidth={1.8} /></span>
          </div>
          {loading ? (
            <p className="director-metric-state" role="status">Đang tải...</p>
          ) : error ? (
            <p className="director-metric-error" role="alert">{error}</p>
          ) : (
            <>
              <strong className="kpi-value">{formattedRevenue}</strong>
              <p className="kpi-caption">Tổng hóa đơn đã ghi nhận trong tháng</p>
            </>
          )}
        </article>
        <article className="kpi-card director-scope-card">
          <div className="kpi-card-top">
            <span className="kpi-label">PHẠM VI</span>
            <span className="kpi-icon blue"><LayoutDashboard size={18} strokeWidth={1.8} /></span>
          </div>
          <strong className="kpi-value">Toàn hệ thống</strong>
          <p className="kpi-caption">Đăng nhập với quyền Ban giám đốc</p>
        </article>
      </section>
      <p className="director-data-note">
        Các chỉ số vận hành khác sẽ hiển thị khi backend có API tổng hợp tương ứng; màn hình này không thay số liệu thật bằng dữ liệu mẫu.
      </p>
    </div>
  )
}

function SectionPlaceholder({ role, activeItem, onBack }) {
  const section = roleNavigation[role]?.find(item => item.id === activeItem)
  const Icon = section?.icon ?? CircleAlert

  return (
    <section className="section-placeholder surface-card">
      <span className="placeholder-icon"><Icon size={24} /></span>
      <p className="section-eyebrow">{role === 'teacher' ? 'KHÔNG GIAN GIÁO VIÊN' : 'QUẢN LÝ CƠ SỞ'}</p>
      <h1>{section?.label}</h1>
      <p>{pageDescriptions[activeItem]}</p>
      <span className="placeholder-note">Phân hệ này sẽ được triển khai ở bước tiếp theo.</span>
      <button type="button" className="primary-button" onClick={onBack}>
        Trở về vận hành ngày <ArrowRight size={16} />
      </button>
    </section>
  )
}

function Toast({ message, onClose }) {
  if (!message) return null
  return (
    <div className="toast" role="status">
      <span><Check size={16} /></span>
      <p>{message}</p>
      <button type="button" onClick={onClose} aria-label="Đóng thông báo"><X size={16} /></button>
    </div>
  )
}

function QuickActionDialog({ action, onClose, onSave }) {
  if (!action) return null

  const content = {
    student: {
      eyebrow: 'HỌC VIÊN CƠ SỞ',
      title: 'Thêm học viên mới',
      description: 'Ghi nhận thông tin ban đầu để bắt đầu lộ trình học Toán.',
      fields: [
        { label: 'Họ và tên học viên', placeholder: 'Ví dụ: Nguyễn Minh Anh' },
        { label: 'Khóa học quan tâm', placeholder: 'Ví dụ: Toán nâng cao 9' },
        { label: 'Số điện thoại phụ huynh', placeholder: 'Nhập số điện thoại', type: 'tel' },
      ],
      submit: 'Lưu học viên',
    },
    makeup: {
      eyebrow: 'XẾP LỊCH HỌC',
      title: 'Sắp xếp lịch học bù',
      description: 'Tạo lịch thay thế và thông báo đến học viên, giáo viên.',
      fields: [
        { label: 'Lớp học', placeholder: 'Ví dụ: Toán nâng cao 9A' },
        { label: 'Ngày học bù', placeholder: '', type: 'date' },
        { label: 'Ca học / Phòng học', placeholder: 'Ví dụ: Ca 2 · Phòng 201' },
      ],
      submit: 'Lưu lịch học bù',
    },
    receipt: {
      eyebrow: 'THU HỌC PHÍ',
      title: 'Tạo phiếu thu',
      description: 'Ghi nhận khoản học phí vừa thu tại cơ sở.',
      fields: [
        { label: 'Tên học viên', placeholder: 'Nhập tên học viên' },
        { label: 'Nội dung thu', placeholder: 'Ví dụ: Học phí tháng 11' },
        { label: 'Số tiền (đ)', placeholder: 'Ví dụ: 3.500.000', type: 'number' },
      ],
      submit: 'Tạo phiếu thu',
    },
    proposal: {
      eyebrow: 'ĐỀ XUẤT GIÁO VIÊN',
      title: 'Đề xuất dạy bù / đổi lịch',
      description: 'Gửi đề xuất để quản lý cơ sở xem xét và phản hồi.',
      fields: [
        { label: 'Lớp học', placeholder: 'Ví dụ: Toán nâng cao 9A' },
        { label: 'Loại đề xuất', placeholder: 'Ví dụ: Đổi lịch / Dạy bù' },
        { label: 'Lịch mong muốn', placeholder: 'Ví dụ: Thứ 5 · Ca 3' },
      ],
      submit: 'Gửi đề xuất',
    },
  }[action]

  if (!content) return null

  return (
    <div className="dialog-backdrop" onMouseDown={event => event.target === event.currentTarget && onClose()}>
      <section className="action-dialog" role="dialog" aria-modal="true" aria-labelledby="dialog-title">
        <button className="dialog-close icon-button" type="button" onClick={onClose} aria-label="Đóng biểu mẫu"><X size={18} /></button>
        <span className="section-eyebrow">{content.eyebrow}</span>
        <h2 id="dialog-title">{content.title}</h2>
        <p>{content.description}</p>
        <form onSubmit={event => { event.preventDefault(); onSave(content.title) }}>
          {content.fields.map(field => (
            <label className="form-field" key={field.label}>
              <span>{field.label}</span>
              <input type={field.type || 'text'} placeholder={field.placeholder} required />
            </label>
          ))}
          <div className="dialog-actions">
            <button className="secondary-button" type="button" onClick={onClose}>Hủy</button>
            <button className="primary-button" type="submit">{content.submit}</button>
          </div>
        </form>
      </section>
    </div>
  )
}

function AuthScreen({ onAuthenticated }) {
  const [mode, setMode] = useState('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [role, setRole] = useState('parent')
  const [error, setError] = useState('')
  const [pending, setPending] = useState(false)

  const submit = async event => {
    event.preventDefault()
    setError('')
    setPending(true)

    try {
      if (mode === 'register') {
        await registerAccount({ email, password, name, phone, role })
      }

      const session = await loginWithPassword({ email, password })
      onAuthenticated(session)
    } catch (requestError) {
      setError(requestError.message || 'Không thể đăng nhập. Vui lòng thử lại.')
    } finally {
      setPending(false)
    }
  }

  const fillAccount = account => {
    setMode('login')
    setEmail(account.email)
    setPassword('Demo123456!')
    setError('')
  }

  return (
    <main className="auth-page">
      <section className="auth-card">
        <Logo />
        <span className="section-eyebrow">CỔNG THÔNG TIN HỌC TẬP</span>
        <h1>{mode === 'login' ? 'Đăng nhập' : 'Tạo tài khoản'}</h1>
        <p className="auth-description">
          {mode === 'login'
            ? 'Đăng nhập bằng tài khoản Backend để xem đúng dữ liệu và chức năng theo vai trò.'
            : 'Đăng ký tài khoản phụ huynh, học sinh hoặc gia sư mới.'}
        </p>

        <form className="auth-form" onSubmit={submit}>
          {mode === 'register' && (
            <>
              <label className="form-field">
                <span>Họ và tên</span>
                <input autoComplete="name" value={name} onChange={event => setName(event.target.value)} required maxLength={120} />
              </label>
              <label className="form-field">
                <span>Vai trò</span>
                <select value={role} onChange={event => setRole(event.target.value)}>
                  <option value="parent">Phụ huynh</option>
                  <option value="student">Học sinh</option>
                  <option value="tutor">Gia sư</option>
                </select>
              </label>
              <label className="form-field">
                <span>Số điện thoại (không bắt buộc)</span>
                <input autoComplete="tel" value={phone} onChange={event => setPhone(event.target.value)} maxLength={30} />
              </label>
            </>
          )}
          <label className="form-field">
            <span>Email</span>
            <input
              autoComplete="email"
              type="email"
              value={email}
              onChange={event => setEmail(event.target.value)}
              required
              maxLength={254}
            />
          </label>
          <label className="form-field">
            <span>Mật khẩu</span>
            <input
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
              type="password"
              value={password}
              onChange={event => setPassword(event.target.value)}
              required
              minLength={mode === 'login' ? 1 : 8}
              maxLength={72}
            />
          </label>
          {error && <p className="auth-error" role="alert">{error}</p>}
          <button className="primary-button auth-submit" type="submit" disabled={pending}>
            {pending ? 'Đang xử lý...' : mode === 'login' ? 'Đăng nhập' : 'Tạo tài khoản và đăng nhập'}
            {!pending && <ArrowRight size={16} />}
          </button>
        </form>

        <div className="auth-mode-toggle">
          {mode === 'login' ? 'Chưa có tài khoản?' : 'Đã có tài khoản?'}{' '}
          <button type="button" onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setError('') }}>
            {mode === 'login' ? 'Đăng ký' : 'Đăng nhập'}
          </button>
        </div>

        {mode === 'login' && (
          <div className="demo-login-box">
            <strong>Điền nhanh tài khoản demo</strong>
            <p>Mật khẩu chung: <code>Demo123456!</code></p>
            <div className="demo-login-actions">
              {demoAccounts.map(account => (
                <button type="button" key={account.email} onClick={() => fillAccount(account)}>
                  {account.label}
                </button>
              ))}
            </div>
          </div>
        )}
        <p className="auth-api-note">Kết nối API: {import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000/api/v1'}</p>
      </section>
    </main>
  )
}

function UnsupportedRole({ role, onSignOut }) {
  return (
    <section className="section-placeholder surface-card">
      <span className="placeholder-icon"><CircleAlert size={24} /></span>
      <p className="section-eyebrow">TÀI KHOẢN ĐÃ ĐĂNG NHẬP</p>
      <h1>Chưa có dashboard cho vai trò này</h1>
      <p>Backend xác thực tài khoản với vai trò “{roleTitles[role] || role}”, nhưng React dashboard hiện chưa có màn hình tương ứng.</p>
      <button type="button" className="primary-button" onClick={onSignOut}>Đăng xuất</button>
    </section>
  )
}

function SupportInbox({ token }) {
  const [requests, setRequests] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    const controller = new AbortController()
    getPendingSupportRequests(token, controller.signal)
      .then(setRequests)
      .catch(requestError => {
        if (requestError.name !== 'AbortError') {
          setError(requestError.message || 'Không thể tải yêu cầu hỗ trợ.')
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false)
      })
    return () => controller.abort()
  }, [token])

  async function updateStatus(id, status) {
    try {
      await updateSupportRequestStatus(token, id, status)
      setError('')
      setRequests(current => current.filter(request => request.id !== id))
    } catch (requestError) {
      setError(requestError.message || 'Không thể cập nhật yêu cầu hỗ trợ.')
    }
  }

  return (
    <section className="support-inbox">
      <div className="parent-page-heading">
        <div>
          <span className="section-eyebrow">CHĂM SÓC KHÁCH HÀNG</span>
          <h1>Yêu cầu hỗ trợ</h1>
          <p>Tiếp nhận và cập nhật trạng thái yêu cầu từ phụ huynh, học sinh.</p>
        </div>
      </div>
      {loading ? (
        <p className="parent-session-reports-state" role="status">Đang tải yêu cầu...</p>
      ) : error ? (
        <p className="parent-session-reports-error" role="alert">{error}</p>
      ) : requests.length === 0 ? (
        <p className="parent-session-reports-state">Hiện không có yêu cầu đang chờ xử lý.</p>
      ) : (
        <div className="support-inbox-list">
          {requests.map(request => (
            <article className="support-inbox-item surface-card" key={request.id}>
              <div>
                <strong>{request.requester_name}</strong>
                <span>{request.type} · {new Date(request.created_at).toLocaleString('vi-VN')}</span>
                <p>{request.description}</p>
              </div>
              <div className="support-inbox-actions">
                <button type="button" onClick={() => updateStatus(request.id, 'processing')}>Đang xử lý</button>
                <button type="button" onClick={() => updateStatus(request.id, 'resolved')}>Đã giải quyết</button>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  )
}

function CurrentApp() {
  const [session, setSession] = useState(() => {
    try {
      const token = window.localStorage.getItem('token')
      const user = JSON.parse(window.localStorage.getItem('authUser') || 'null')
      return token && user && typeof user.role === 'string'
        ? { token, user }
        : null
    } catch {
      window.localStorage.removeItem('token')
      window.localStorage.removeItem('authUser')
      return null
    }
  })
  const [teacherSchedule, setTeacherSchedule] = useState(teacherScheduleSeed)
  const [teacherClasses, setTeacherClasses] = useState(teacherClassesSeed)
  const [kpis, setKpis] = useState(kpiSeed)
  const [activities, setActivities] = useState(activitySeed)
  const [activeItem, setActiveItem] = useState('overview')
  const [selectedChildId, setSelectedChildId] = useState(null)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [searchValue, setSearchValue] = useState('')
  const [dialogAction, setDialogAction] = useState('')
  const [toastMessage, setToastMessage] = useState('')
  const role = getViewRole(session?.user.role)

  useEffect(() => {
    const userRole = session?.user?.role
    const token = session?.token
    if (!userRole || !token) return undefined

    const buildHeaders = () => ({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    })

    const normalizeKpiData = payload => {
      if (Array.isArray(payload)) {
        return payload.map(item => ({
          ...item,
          value: String(item.value ?? item.total ?? item.amount ?? 0),
          caption: item.caption ?? 'Dữ liệu tính toán trực tiếp từ backend.',
          icon: item.icon ?? Users,
          color: item.color ?? 'blue',
          trend: item.trend ?? '—',
          trendDirection: item.trendDirection ?? 'neutral',
        }))
      }

      const source = payload && typeof payload === 'object' ? payload : {}
      const students = Number(source.total_students ?? source.students ?? source.student_count ?? 0)
      const classesCount = Number(source.total_classes ?? source.classes ?? source.class_count ?? 0)
      const contractValue = Number(source.total_contract_value ?? source.total_revenue ?? source.contract_total ?? source.total_amount ?? 0)

      return [
        {
          label: 'Học sinh đang hoạt động',
          value: String(students),
          caption: 'Tổng số học viên đang theo học',
          icon: Users,
          color: 'green',
          trend: '+0',
          trendDirection: 'up',
        },
        {
          label: 'Lớp đang hoạt động',
          value: String(classesCount),
          caption: 'Tổng số lớp đang vận hành',
          icon: BookOpenCheck,
          color: 'blue',
          trend: 'Ổn định',
          trendDirection: 'neutral',
        },
        {
          label: 'Doanh thu hợp đồng',
          value: new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND', maximumFractionDigits: 0 }).format(contractValue),
          caption: 'Tổng giá trị hợp đồng đã xác nhận',
          icon: Wallet,
          color: 'violet',
          trend: '+0%',
          trendDirection: 'up',
        },
      ]
    }

    if (userRole === 'tutor') {
      const controller = new AbortController()

      async function loadTutorData() {
        try {
          const [scheduleResponse, classesResponse] = await Promise.all([
            fetch(`${API_BASE_URL}/reports/tutor/schedules`, {
              headers: buildHeaders(),
              signal: controller.signal,
            }),
            fetch(`${API_BASE_URL}/reports/tutor/classes`, {
              headers: buildHeaders(),
              signal: controller.signal,
            }),
          ])

          if (!scheduleResponse.ok || !classesResponse.ok) {
            throw new Error('Không thể tải dữ liệu gia sư từ backend.')
          }

          const [scheduleResult, classesResult] = await Promise.all([
            scheduleResponse.json(),
            classesResponse.json(),
          ])

          setTeacherSchedule(Array.isArray(scheduleResult?.data) ? scheduleResult.data : teacherScheduleSeed)
          setTeacherClasses(Array.isArray(classesResult?.data) ? classesResult.data : teacherClassesSeed)
        } catch (error) {
          if (error.name !== 'AbortError') {
            setTeacherSchedule(teacherScheduleSeed)
            setTeacherClasses(teacherClassesSeed)
          }
        }
      }

      loadTutorData()
      return () => controller.abort()
    }

    if (userRole === 'admin' || userRole === 'manager') {
      const controller = new AbortController()

      async function loadAdminData() {
        try {
          const [kpisResponse, activitiesResponse] = await Promise.all([
            fetch(`${API_BASE_URL}/finance/dashboard/kpis`, {
              headers: buildHeaders(),
              signal: controller.signal,
            }),
            fetch(`${API_BASE_URL}/finance/dashboard/activities`, {
              headers: buildHeaders(),
              signal: controller.signal,
            }),
          ])

          if (!kpisResponse.ok || !activitiesResponse.ok) {
            throw new Error('Không thể tải dữ liệu dashboard từ backend.')
          }

          const [kpiResult, activityResult] = await Promise.all([
            kpisResponse.json(),
            activitiesResponse.json(),
          ])

          setKpis(normalizeKpiData(kpiResult?.data ?? kpiResult))
          setActivities(Array.isArray(activityResult?.data) ? activityResult.data : activitySeed)
        } catch (error) {
          if (error.name !== 'AbortError') {
            setKpis(kpiSeed)
            setActivities(activitySeed)
          }
        }
      }

      loadAdminData()
      return () => controller.abort()
    }

    return undefined
  }, [session])
  const alerts = useMemo(() => {
    const query = searchValue.trim().toLocaleLowerCase('vi')
    if (!query) return initialAlerts
    return initialAlerts.filter(alert =>
      `${alert.category} ${alert.title} ${alert.detail}`.toLocaleLowerCase('vi').includes(query),
    )
  }, [searchValue])

  const navigate = id => {
    setActiveItem(id)
    setSidebarOpen(false)
  }

  const signIn = nextSession => {
    window.localStorage.setItem('token', nextSession.token)
    window.localStorage.setItem('authUser', JSON.stringify(nextSession.user))
    setSession(nextSession)
    setActiveItem(getViewRole(nextSession.user.role) === 'parent' ? 'children' : 'overview')
    setSelectedChildId(null)
    setSearchValue('')
    setSidebarOpen(false)
  }

  const signOut = () => {
    window.localStorage.removeItem('token')
    window.localStorage.removeItem('authUser')
    setSession(null)
    setSelectedChildId(null)
    setActiveItem('overview')
  }

  const showToast = message => {
    setToastMessage(message)
    window.setTimeout(() => setToastMessage(''), 3500)
  }

  if (!session) {
    return <AuthScreen onAuthenticated={signIn} />
  }

  if (!role) {
    return <UnsupportedRole role={session.user.role} onSignOut={signOut} />
  }

  return (
    <div className="app-shell">
      <Header
        role={role}
        user={session.user}
        onSignOut={signOut}
        onToggleSidebar={() => setSidebarOpen(open => !open)}
        onSearch={setSearchValue}
        searchValue={searchValue}
        onOpenNotifications={() => showToast(role === 'parent' ? 'Bạn đang xem thông báo học tập mới nhất của gia đình.' : 'Bạn đang xem các thông báo mới nhất của cơ sở.')}
      />
      {role === 'parent' && <ParentTopNav activeItem={activeItem} onNavigate={navigate} />}
      <div className={`app-body${role === 'parent' ? ' parent-app-body' : ''}`}>
        {role !== 'parent' && <Sidebar
            role={role}
              userRole={session.user.role}
            activeItem={activeItem}
            onNavigate={navigate}
            isOpen={sidebarOpen}
            onClose={() => setSidebarOpen(false)}
          />}
        <main className={`main-content bg-slate-50 text-slate-800${role === 'parent' ? ' parent-main-content' : ''}`}>
          <div className="content-inner">
            {role === 'parent' ? (
              <ParentDashboard
                activeItem={activeItem}
                selectedChildId={selectedChildId}
                onOpenChild={id => {
                  setSelectedChildId(id)
                  navigate('child-detail')
                }}
                onBackToChildren={() => navigate('children')}
              />
            ) : role === 'teacher' && activeItem === 'overview' ? (
              <TeacherDashboard
                searchValue={searchValue}
                teacherSchedule={teacherSchedule}
                teacherClasses={teacherClasses}
                onCreateProposal={() => setDialogAction('proposal')}
              />
            ) : activeItem === 'support' && ['admin', 'manager'].includes(session.user.role) ? (
              <SupportInbox token={session.token} />
            ) : role === 'director' && activeItem === 'overview' ? (
              <DirectorDashboard user={session.user} token={session.token} />
            ) : activeItem === 'overview' ? (
              <BranchManagerDashboard
                alerts={alerts}
                kpis={kpis}
                activities={activities}
                user={session.user}
                onOpenAlert={navigate}
                searchValue={searchValue}
                onCreateStudent={() => setDialogAction('student')}
                onScheduleMakeup={() => setDialogAction('makeup')}
                onCreateReceipt={() => setDialogAction('receipt')}
                onViewActivity={() => showToast('Toàn bộ nhật ký hoạt động đã được cập nhật.')}
              />
            ) : (
              <SectionPlaceholder role={role} activeItem={activeItem} onBack={() => navigate('overview')} />
            )}
          </div>
        </main>
      </div>

      {role !== 'parent' && sidebarOpen && <span className="sr-only" aria-live="polite">Menu điều hướng đã mở</span>}
      <QuickActionDialog
        action={dialogAction}
        onClose={() => setDialogAction('')}
        onSave={title => {
          setDialogAction('')
          showToast(`Biểu mẫu “${title}” đã hoàn tất trong bản demo. Dữ liệu chưa được lưu vào hệ thống.`)
        }}
      />
      <Toast message={toastMessage} onClose={() => setToastMessage('')} />
    </div>
  )
}

function App() {
  return <Dashboard />
}

export default App