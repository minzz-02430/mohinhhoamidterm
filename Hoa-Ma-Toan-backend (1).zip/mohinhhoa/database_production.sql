CREATE DATABASE IF NOT EXISTS hoa_ma_toan_crm
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE hoa_ma_toan_crm;

-- Fresh-install schema for the CRM application.
-- Includes all 18 tables currently defined in db.dbml and the merged CRM,
-- finance, and flexible user-role definitions.
-- CREATE TABLE IF NOT EXISTS does not migrate or alter an existing table.

-- User accounts for administrators, tutors, students, parents, sales, and accountants.
CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  role VARCHAR(50) NOT NULL DEFAULT 'student',
  name VARCHAR(120) NOT NULL,
  username VARCHAR(254) NULL,
  email VARCHAR(254) NOT NULL,
  phone VARCHAR(30) NULL,
  branch VARCHAR(80) NULL,
  status ENUM('active', 'locked', 'pending') NOT NULL DEFAULT 'active',
  must_change_password TINYINT(1) NOT NULL DEFAULT 0,
  token_version INT UNSIGNED NOT NULL DEFAULT 0,
  password_hash VARCHAR(255) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_username (username),
  UNIQUE KEY uq_users_email (email),
  KEY idx_users_role (role),
  KEY idx_users_branch (branch)
) ENGINE=InnoDB COMMENT='System user accounts and authentication';

-- Student profile records.
CREATE TABLE IF NOT EXISTS students (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(120) NOT NULL,
  grade VARCHAR(30) NULL,
  branch VARCHAR(80) NULL,
  date_of_birth DATE NULL,
  notes TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_students_name (name)
) ENGINE=InnoDB COMMENT='Student profiles';

-- Many-to-many links between parent user accounts and student profiles.
CREATE TABLE IF NOT EXISTS parent_student (
  parent_id INT UNSIGNED NOT NULL,
  student_id INT UNSIGNED NOT NULL,
  relationship VARCHAR(40) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (parent_id, student_id),
  KEY idx_parent_student_student (student_id),
  CONSTRAINT fk_parent_student_parent
    FOREIGN KEY (parent_id) REFERENCES users (id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_parent_student_student
    FOREIGN KEY (student_id) REFERENCES students (id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Parent to student relationships';

-- Course catalog and standard course fees.
CREATE TABLE IF NOT EXISTS courses (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(120) NOT NULL,
  description TEXT NULL,
  fee DECIMAL(12,2) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT chk_courses_fee_nonnegative CHECK (fee >= 0)
) ENGINE=InnoDB COMMENT='Course catalog';

-- Classes belong to a course; teacher account may be unset or removed.
CREATE TABLE IF NOT EXISTS classes (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  course_id INT UNSIGNED NOT NULL,
  teacher_id INT UNSIGNED NULL,
  name VARCHAR(120) NOT NULL,
  description TEXT NULL,
  status ENUM('planned', 'active', 'paused', 'completed', 'cancelled')
    NOT NULL DEFAULT 'planned',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_classes_course (course_id),
  KEY idx_classes_teacher (teacher_id),
  KEY idx_classes_status (status),
  CONSTRAINT fk_classes_course
    FOREIGN KEY (course_id) REFERENCES courses (id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_classes_teacher
    FOREIGN KEY (teacher_id) REFERENCES users (id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Classes and assigned tutors';

-- Weekly recurring class schedules.
CREATE TABLE IF NOT EXISTS schedules (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  class_id INT UNSIGNED NOT NULL,
  day_of_week ENUM('monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday')
    NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  starts_on DATE NULL,
  ends_on DATE NULL,
  location VARCHAR(160) NULL,
  status ENUM('active', 'cancelled') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_schedules_class_day (class_id, day_of_week),
  CONSTRAINT chk_schedules_time CHECK (end_time > start_time),
  CONSTRAINT chk_schedules_date_range CHECK (ends_on IS NULL OR starts_on IS NULL OR ends_on >= starts_on),
  CONSTRAINT fk_schedules_class
    FOREIGN KEY (class_id) REFERENCES classes (id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Recurring weekly class schedules';

-- Student enrollment in classes.
CREATE TABLE IF NOT EXISTS enrollments (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  student_id INT UNSIGNED NOT NULL,
  class_id INT UNSIGNED NOT NULL,
  enrolled_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status ENUM('active', 'completed', 'withdrawn') NOT NULL DEFAULT 'active',
  PRIMARY KEY (id),
  UNIQUE KEY uq_enrollments_student_class (student_id, class_id),
  KEY idx_enrollments_class (class_id),
  KEY idx_enrollments_status (status),
  CONSTRAINT fk_enrollments_student
    FOREIGN KEY (student_id) REFERENCES students (id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_enrollments_class
    FOREIGN KEY (class_id) REFERENCES classes (id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Student class enrollments';

-- Per-student attendance and tutor session comments.
CREATE TABLE IF NOT EXISTS attendance_reports (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  enrollment_id INT UNSIGNED NOT NULL,
  schedule_id INT UNSIGNED NULL,
  lesson_date DATE NOT NULL,
  attendance_status ENUM('present', 'absent') NOT NULL,
  note VARCHAR(500) NULL,
  reported_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_attendance_enrollment_schedule_date (enrollment_id, schedule_id, lesson_date),
  KEY idx_attendance_schedule (schedule_id),
  KEY idx_attendance_reporter (reported_by),
  CONSTRAINT fk_attendance_enrollment
    FOREIGN KEY (enrollment_id) REFERENCES enrollments (id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_attendance_schedule
    FOREIGN KEY (schedule_id) REFERENCES schedules (id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_attendance_reporter
    FOREIGN KEY (reported_by) REFERENCES users (id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Per-session student attendance reports';

-- Assignments created for classes.
CREATE TABLE IF NOT EXISTS assignments (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  class_id INT UNSIGNED NOT NULL,
  created_by INT UNSIGNED NULL,
  title VARCHAR(160) NOT NULL,
  description TEXT NULL,
  due_at DATETIME NULL,
  status ENUM('draft', 'published', 'closed') NOT NULL DEFAULT 'published',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_assignments_class_status (class_id, status),
  KEY idx_assignments_due_at (due_at),
  CONSTRAINT fk_assignments_class
    FOREIGN KEY (class_id) REFERENCES classes (id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_assignments_creator
    FOREIGN KEY (created_by) REFERENCES users (id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Class assignments';

-- Student submissions and grading details for assignments.
CREATE TABLE IF NOT EXISTS assignment_submissions (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  assignment_id INT UNSIGNED NOT NULL,
  enrollment_id INT UNSIGNED NOT NULL,
  submitted_at DATETIME NULL,
  content TEXT NULL,
  score DECIMAL(5,2) NULL,
  feedback TEXT NULL,
  status ENUM('not_submitted', 'submitted', 'graded', 'late')
    NOT NULL DEFAULT 'not_submitted',
  graded_by INT UNSIGNED NULL,
  graded_at DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_assignment_submission (assignment_id, enrollment_id),
  KEY idx_submissions_enrollment (enrollment_id),
  KEY idx_submissions_grader (graded_by),
  CONSTRAINT chk_submission_score CHECK (score IS NULL OR (score >= 0 AND score <= 100)),
  CONSTRAINT fk_submissions_assignment
    FOREIGN KEY (assignment_id) REFERENCES assignments (id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_submissions_enrollment
    FOREIGN KEY (enrollment_id) REFERENCES enrollments (id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_submissions_grader
    FOREIGN KEY (graded_by) REFERENCES users (id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Assignment submissions and grading';

-- General academic grades and tutor feedback per enrollment.
CREATE TABLE IF NOT EXISTS grades (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  enrollment_id INT UNSIGNED NOT NULL,
  score DECIMAL(5,2) NULL,
  feedback TEXT NULL,
  recorded_by INT UNSIGNED NULL,
  recorded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_grades_enrollment (enrollment_id),
  KEY idx_grades_recorder (recorded_by),
  CONSTRAINT chk_grades_score CHECK (score IS NULL OR (score >= 0 AND score <= 100)),
  CONSTRAINT fk_grades_enrollment
    FOREIGN KEY (enrollment_id) REFERENCES enrollments (id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_grades_recorder
    FOREIGN KEY (recorded_by) REFERENCES users (id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Academic grades and feedback';

-- CRM prospect records.
CREATE TABLE IF NOT EXISTS leads (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  fullname VARCHAR(120) NOT NULL,
  phone VARCHAR(30) NULL,
  email VARCHAR(254) NULL,
  status ENUM('new', 'consulting', 'converted', 'cancelled')
    NOT NULL DEFAULT 'new',
  branch VARCHAR(80) NULL,
  assigned_to INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_leads_assigned_to (assigned_to),
  KEY idx_leads_status (status),
  CONSTRAINT fk_leads_assignee
    FOREIGN KEY (assigned_to) REFERENCES users (id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='CRM prospective customers and sales follow-up';

-- Student class enrollment contracts.
CREATE TABLE IF NOT EXISTS contracts (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  student_id INT UNSIGNED NOT NULL,
  class_id INT UNSIGNED NOT NULL,
  contract_code VARCHAR(80) NOT NULL,
  total_amount DECIMAL(12,2) NOT NULL,
  paid_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  payment_status ENUM('unpaid', 'partially_paid', 'paid') NOT NULL DEFAULT 'unpaid',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_contracts_contract_code (contract_code),
  KEY idx_contracts_student_id (student_id),
  KEY idx_contracts_class_id (class_id),
  KEY idx_contracts_payment_status (payment_status),
  CONSTRAINT chk_contracts_total_amount_nonnegative CHECK (total_amount >= 0),
  CONSTRAINT chk_contracts_paid_amount_nonnegative CHECK (paid_amount >= 0),
  CONSTRAINT fk_contracts_student
    FOREIGN KEY (student_id) REFERENCES students (id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_contracts_class
    FOREIGN KEY (class_id) REFERENCES classes (id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Student class contracts and payment status';

-- Invoice/payment records for contracts and the cashier who recorded them.
CREATE TABLE IF NOT EXISTS invoices (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  contract_id INT UNSIGNED NOT NULL,
  invoice_number VARCHAR(80) NOT NULL,
  amount_paid DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  payment_method ENUM('cash', 'bank_transfer', 'vietqr', 'other') NOT NULL,
  status ENUM('pending', 'awaiting', 'paid') NOT NULL DEFAULT 'pending',
  cashier_id INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_invoices_invoice_number (invoice_number),
  KEY idx_invoices_contract_id (contract_id),
  KEY idx_invoices_cashier_id (cashier_id),
  CONSTRAINT chk_invoices_amount_paid_nonnegative CHECK (amount_paid >= 0),
  CONSTRAINT fk_invoices_contract
    FOREIGN KEY (contract_id) REFERENCES contracts (id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_invoices_cashier
    FOREIGN KEY (cashier_id) REFERENCES users (id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Contract payment records and cashier details';

-- Payments recorded against invoices.
CREATE TABLE IF NOT EXISTS payments (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  invoice_id INT UNSIGNED NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  paid_at DATETIME NULL,
  method ENUM('cash', 'bank_transfer', 'vietqr', 'other') NOT NULL DEFAULT 'other',
  transaction_reference VARCHAR(120) NULL,
  status ENUM('pending', 'completed', 'failed', 'refunded') NOT NULL DEFAULT 'pending',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_payments_invoice (invoice_id),
  KEY idx_payments_status (status),
  UNIQUE KEY uq_payments_transaction_reference (transaction_reference),
  CONSTRAINT chk_payments_amount_nonnegative CHECK (amount >= 0),
  CONSTRAINT fk_payments_invoice
    FOREIGN KEY (invoice_id) REFERENCES invoices (id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Invoice payment history';

-- Customer service requests and their assignment/resolution workflow.
CREATE TABLE IF NOT EXISTS customer_requests (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  type ENUM('leave_request', 'class_change', 'complaint') NOT NULL,
  description TEXT NOT NULL,
  status ENUM('pending', 'processing', 'resolved') NOT NULL DEFAULT 'pending',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_customer_requests_user_id (user_id),
  KEY idx_customer_requests_status_created_at (status, created_at),
  CONSTRAINT fk_customer_requests_user
    FOREIGN KEY (user_id) REFERENCES users (id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='User requests and customer service workflow';

-- CRM and operations tasks assigned to an internal user.
CREATE TABLE IF NOT EXISTS tasks (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(160) NOT NULL,
  description TEXT NULL,
  due_date DATETIME NULL,
  status ENUM('pending', 'doing', 'completed', 'rejected') NOT NULL DEFAULT 'pending',
  priority ENUM('low', 'normal', 'high') NOT NULL DEFAULT 'normal',
  assigned_to INT UNSIGNED NULL,
  assigned_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_tasks_assigned_to (assigned_to),
  KEY idx_tasks_status_due_date (status, due_date),
  CONSTRAINT fk_tasks_assigned_to
    FOREIGN KEY (assigned_to) REFERENCES users (id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_tasks_assigned_by
    FOREIGN KEY (assigned_by) REFERENCES users (id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Assigned CRM and operations tasks';

-- Parent support tickets retained as a separate support workflow.
CREATE TABLE IF NOT EXISTS support_tickets (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  parent_id INT UNSIGNED NOT NULL,
  subject VARCHAR(160) NOT NULL,
  description TEXT NULL,
  status ENUM('open', 'in_progress', 'resolved', 'closed') NOT NULL DEFAULT 'open',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_support_tickets_parent (parent_id),
  KEY idx_support_tickets_status (status),
  CONSTRAINT fk_support_tickets_parent
    FOREIGN KEY (parent_id) REFERENCES users (id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Parent support ticket records';

-- Bổ sung theo bản audit 14/11/2026: OTP, thông báo, tin nhắn, nhật ký thao tác.
CREATE TABLE IF NOT EXISTS password_otps (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  code_hash VARCHAR(255) NOT NULL,
  expires_at DATETIME NOT NULL,
  attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_password_otps_user (user_id),
  CONSTRAINT fk_password_otps_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Mã OTP đặt lại mật khẩu (lưu dạng băm, hết hạn sau 5 phút)';

CREATE TABLE IF NOT EXISTS notifications (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  type VARCHAR(40) NOT NULL DEFAULT 'general',
  title VARCHAR(160) NOT NULL,
  body TEXT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_notifications_user_read (user_id, is_read),
  CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Thông báo theo từng người dùng';

CREATE TABLE IF NOT EXISTS threads (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(160) NOT NULL,
  created_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_threads_creator FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Hội thoại giữa phụ huynh, giáo viên và trung tâm';

CREATE TABLE IF NOT EXISTS thread_members (
  thread_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (thread_id, user_id),
  KEY idx_thread_members_user (user_id),
  CONSTRAINT fk_thread_members_thread FOREIGN KEY (thread_id) REFERENCES threads (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_thread_members_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Thành viên của hội thoại';

CREATE TABLE IF NOT EXISTS messages (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  thread_id INT UNSIGNED NOT NULL,
  sender_id INT UNSIGNED NULL,
  body TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_messages_thread (thread_id, id),
  CONSTRAINT fk_messages_thread FOREIGN KEY (thread_id) REFERENCES threads (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_messages_sender FOREIGN KEY (sender_id) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Tin nhắn trong hội thoại';

CREATE TABLE IF NOT EXISTS audit_log (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  action VARCHAR(255) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_audit_log_user (user_id),
  CONSTRAINT fk_audit_log_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Nhật ký thao tác: ai làm gì, khi nào';
