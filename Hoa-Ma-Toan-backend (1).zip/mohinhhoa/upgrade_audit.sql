-- Migration theo bản audit 14/11/2026 (Prompt 12): phân quyền theo cơ sở, khóa tài khoản, OTP, thông báo, tin nhắn, giao việc.
-- Chỉ chạy MỘT LẦN trên database đã tạo bằng database_production.sql phiên bản cũ. Sao lưu trước khi chạy.
-- Cài mới thì không cần file này: database_production.sql đã gồm các thay đổi dưới đây.
USE hoa_ma_toan_crm;

ALTER TABLE users
  ADD COLUMN branch VARCHAR(80) NULL AFTER phone,
  ADD COLUMN status ENUM('active', 'locked', 'pending') NOT NULL DEFAULT 'active' AFTER branch,
  ADD COLUMN must_change_password TINYINT(1) NOT NULL DEFAULT 0 AFTER status,
  ADD COLUMN token_version INT UNSIGNED NOT NULL DEFAULT 0 AFTER must_change_password,
  ADD KEY idx_users_branch (branch);

ALTER TABLE students ADD COLUMN branch VARCHAR(80) NULL AFTER grade, ADD KEY idx_students_branch (branch);
ALTER TABLE leads ADD COLUMN branch VARCHAR(80) NULL AFTER status, ADD KEY idx_leads_branch (branch);
ALTER TABLE invoices
  ADD COLUMN status ENUM('pending', 'awaiting', 'paid') NOT NULL DEFAULT 'pending' AFTER payment_method,
  ADD KEY idx_invoices_status (status);
ALTER TABLE tasks
  MODIFY COLUMN status ENUM('pending', 'doing', 'completed', 'rejected') NOT NULL DEFAULT 'pending',
  ADD COLUMN priority ENUM('low', 'normal', 'high') NOT NULL DEFAULT 'normal' AFTER status,
  ADD COLUMN assigned_by INT UNSIGNED NULL AFTER assigned_to,
  ADD KEY idx_tasks_assigned_by (assigned_by),
  ADD CONSTRAINT fk_tasks_assigned_by FOREIGN KEY (assigned_by) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE;

CREATE TABLE IF NOT EXISTS password_otps (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  code_hash VARCHAR(255) NOT NULL,
  expires_at DATETIME NOT NULL,
  attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_password_otps_user (user_id),
  CONSTRAINT fk_password_otps_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Mã OTP đặt lại mật khẩu (lưu dạng băm, hết hạn sau 5 phút)';

CREATE TABLE IF NOT EXISTS notifications (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  type VARCHAR(40) NOT NULL DEFAULT 'general',
  title VARCHAR(160) NOT NULL,
  body TEXT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_notifications_user_read (user_id, is_read),
  CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Thông báo theo từng người dùng';

CREATE TABLE IF NOT EXISTS threads (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(160) NOT NULL,
  created_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_threads_creator FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Hội thoại giữa phụ huynh, giáo viên và trung tâm';

CREATE TABLE IF NOT EXISTS thread_members (
  thread_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (thread_id, user_id),
  KEY idx_thread_members_user (user_id),
  CONSTRAINT fk_thread_members_thread FOREIGN KEY (thread_id) REFERENCES threads (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_thread_members_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Thành viên của hội thoại';

CREATE TABLE IF NOT EXISTS messages (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  thread_id INT UNSIGNED NOT NULL,
  sender_id INT UNSIGNED NULL,
  body TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_messages_thread (thread_id, id),
  CONSTRAINT fk_messages_thread FOREIGN KEY (thread_id) REFERENCES threads (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_messages_sender FOREIGN KEY (sender_id) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Tin nhắn trong hội thoại';

CREATE TABLE IF NOT EXISTS audit_log (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  action VARCHAR(255) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_audit_log_user (user_id),
  CONSTRAINT fk_audit_log_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB COMMENT='Nhật ký thao tác: ai làm gì, khi nào';
