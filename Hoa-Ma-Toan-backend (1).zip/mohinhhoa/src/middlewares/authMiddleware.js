const jwt = require('jsonwebtoken');
const { pool } = require('../config/db');

const ACCESS_COOKIE = 'hmt_access';
const REFRESH_COOKIE = 'hmt_refresh';
const INVALID_TOKEN = { status: 'error', message: 'Token không hợp lệ hoặc đã hết hạn' };

function readCookie(req, name) {
  const header = req.get('cookie') || '';
  const pair = header.split(';').map((part) => part.trim()).find((part) => part.startsWith(`${name}=`));
  return pair ? decodeURIComponent(pair.slice(name.length + 1)) : null;
}

// Token nhận từ header Bearer (client API) hoặc cookie httpOnly (trình duyệt).
async function authenticateToken(req, res, next) {
  const bearerMatch = req.get('authorization')?.trim().match(/^Bearer\s+(\S+)$/i);
  const token = bearerMatch?.[1] || readCookie(req, ACCESS_COOKIE);

  if (!token) {
    return res.status(401).json({
      status: 'error',
      message: 'Yêu cầu token Bearer hợp lệ để truy cập tài nguyên này',
    });
  }

  const secret = process.env.JWT_SECRET;
  if (!secret) {
    const error = new Error('JWT_SECRET is not configured');
    error.statusCode = 500;
    return next(error);
  }

  let payload;
  try {
    payload = jwt.verify(token, secret);
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError) {
      return res.status(403).json(INVALID_TOKEN);
    }
    return next(error);
  }

  if (typeof payload === 'string' || payload.type === 'refresh') {
    return res.status(403).json(INVALID_TOKEN);
  }

  const id = payload.id ?? payload.userId ?? payload.sub;
  const validId = (typeof id === 'string' && id.length > 0)
    || (typeof id === 'number' && Number.isFinite(id));

  if (!validId) {
    return res.status(403).json(INVALID_TOKEN);
  }

  try {
    // Vai trò, cơ sở và trạng thái luôn đọc lại từ DB, không tin giá trị nằm trong token.
    const [users] = await pool.execute(
      'SELECT id, email, role, branch, status, token_version FROM users WHERE id = ? LIMIT 1',
      [id],
    );
    const user = users[0];

    if (!user || typeof user.email !== 'string'
      || typeof user.role !== 'string' || user.role.length === 0) {
      return res.status(403).json(INVALID_TOKEN);
    }
    if (user.status === 'locked') {
      return res.status(403).json({ status: 'error', message: 'Tài khoản đã bị khóa' });
    }
    // Đăng xuất hoặc đổi mật khẩu tăng token_version nên mọi token cũ mất hiệu lực.
    if ((payload.tv ?? 0) !== (user.token_version ?? 0)) {
      return res.status(403).json(INVALID_TOKEN);
    }

    req.user = { id: user.id, email: user.email, role: user.role, branch: user.branch ?? null };
    return next();
  } catch (error) {
    return next(error);
  }
}

function requireRoles(...allowedRoles) {
  const allowedRoleSet = new Set(allowedRoles);

  return (req, res, next) => {
    try {
      if (!req.user) {
        return res.status(401).json({
          status: 'error',
          message: 'Bạn cần đăng nhập để truy cập tài nguyên này',
        });
      }

      if (!allowedRoleSet.has(req.user.role)) {
        return res.status(403).json({
          status: 'error',
          message: 'Bạn không có quyền truy cập tính năng này',
        });
      }

      return next();
    } catch (error) {
      return next(error);
    }
  };
}

// Giới hạn dữ liệu theo cơ sở: admin xem mọi cơ sở (có thể lọc bằng ?branch=), vai trò khác bị khóa vào cơ sở của mình.
function scopeToBranch(req, res, next) {
  const asked = typeof req.query.branch === 'string' && req.query.branch.trim() ? req.query.branch.trim() : null;

  if (req.user.role === 'admin') {
    req.branchScope = asked;
    return next();
  }
  if (req.user.role !== 'parent' && !req.user.branch) {
    return res.status(403).json({ status: 'error', message: 'Tài khoản chưa được gán cơ sở' });
  }
  if (asked && asked !== req.user.branch) {
    return res.status(403).json({ status: 'error', message: 'Bạn không có quyền xem dữ liệu của cơ sở khác' });
  }

  req.branchScope = req.user.branch;
  return next();
}

module.exports = {
  ACCESS_COOKIE,
  REFRESH_COOKIE,
  authenticateToken,
  readCookie,
  requireRole: requireRoles,
  requireRoles,
  scopeToBranch,
};
