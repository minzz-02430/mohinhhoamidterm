const authService = require('./authService');
const { ACCESS_COOKIE, REFRESH_COOKIE, readCookie } = require('../../middlewares/authMiddleware');

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PUBLIC_ROLES = new Set(['parent']);

function validateEmail(email) {
  return typeof email === 'string'
    && email.length <= 254
    && EMAIL_PATTERN.test(email.trim());
}

function validateRegistration(body) {
  const { email, password, name, phone, role } = body;

  if (!validateEmail(email)) {
    return 'Email không hợp lệ';
  }

  if (typeof password !== 'string'
    || Buffer.byteLength(password, 'utf8') < 8
    || Buffer.byteLength(password, 'utf8') > 72) {
    return 'Mật khẩu phải có ít nhất 8 ký tự và không vượt quá 72 byte';
  }

  if (typeof name !== 'string' || name.trim().length === 0 || name.trim().length > 120) {
    return 'Họ tên phải có từ 1 đến 120 ký tự';
  }

  if (phone !== undefined
    && phone !== null
    && (typeof phone !== 'string' || phone.trim().length > 30)) {
    return 'Số điện thoại không hợp lệ';
  }

  if (role === 'admin') {
    return 'Không thể đăng ký tài khoản quản trị viên qua API công khai';
  }

  if (typeof role !== 'string' || !PUBLIC_ROLES.has(role)) {
    return 'Đăng ký công khai chỉ dành cho phụ huynh; tài khoản nhân sự do Ban giám đốc cấp';
  }

  return null;
}

async function register(req, res, next) {
  const validationError = validateRegistration(req.body ?? {});

  if (validationError) {
    const statusCode = req.body?.role === 'admin' ? 403 : 400;
    return res.status(statusCode).json({
      status: 'error',
      message: validationError,
    });
  }

  try {
    const user = await authService.register({
      email: req.body.email.trim().toLowerCase(),
      password: req.body.password,
      name: req.body.name.trim(),
      phone: req.body.phone?.trim() || null,
      role: req.body.role,
    });

    return res.status(201).json({
      status: 'success',
      message: 'Đăng ký tài khoản thành công',
      data: { user },
    });
  } catch (error) {
    return next(error);
  }
}

async function login(req, res, next) {
  const { email, password } = req.body ?? {};

  if (!validateEmail(email) || typeof password !== 'string' || password.length === 0) {
    return res.status(400).json({
      status: 'error',
      message: 'Email hoặc mật khẩu không hợp lệ',
    });
  }

  try {
    const result = await authService.login({
      email: email.trim().toLowerCase(),
      password,
    });

    setAuthCookies(res, result);
    return res.status(200).json({
      status: 'success',
      message: 'Đăng nhập thành công',
      data: { token: result.token, user: result.user },
    });
  } catch (error) {
    return next(error);
  }
}

// Cookie httpOnly + SameSite=Strict: JavaScript trên trang không đọc được token và trang khác không gửi kèm được.
function setAuthCookies(res, { token, refreshToken }) {
  const base = { httpOnly: true, sameSite: 'strict', secure: process.env.NODE_ENV === 'production', path: '/api/v1' };
  res.cookie(ACCESS_COOKIE, token, { ...base, maxAge: 15 * 60 * 1000 });
  res.cookie(REFRESH_COOKIE, refreshToken, { ...base, maxAge: 7 * 24 * 60 * 60 * 1000 });
}

function clearAuthCookies(res) {
  res.clearCookie(ACCESS_COOKIE, { path: '/api/v1' });
  res.clearCookie(REFRESH_COOKIE, { path: '/api/v1' });
}

async function refresh(req, res, next) {
  try {
    const tokens = await authService.refresh(readCookie(req, REFRESH_COOKIE) || req.body?.refreshToken || '');
    setAuthCookies(res, tokens);
    return res.status(200).json({ status: 'success', data: { token: tokens.token } });
  } catch (error) {
    return next(error);
  }
}

async function logout(req, res, next) {
  try {
    await authService.logout(req.user.id);
    clearAuthCookies(res);
    return res.status(200).json({ status: 'success', message: 'Đã đăng xuất' });
  } catch (error) {
    return next(error);
  }
}

async function changePassword(req, res, next) {
  try {
    const tokens = await authService.changePassword(req.user.id, req.body?.currentPassword, req.body?.newPassword);
    setAuthCookies(res, tokens);
    return res.status(200).json({ status: 'success', message: 'Đã đổi mật khẩu', data: { token: tokens.token } });
  } catch (error) {
    return next(error);
  }
}

async function forgot(req, res, next) {
  if (!validateEmail(req.body?.email)) {
    return res.status(400).json({ status: 'error', message: 'Email không hợp lệ' });
  }
  try {
    await authService.requestOtp(req.body.email.trim().toLowerCase());
    return res.status(200).json({ status: 'success', message: 'Nếu email có tài khoản, mã OTP đã được gửi và có hiệu lực 5 phút' });
  } catch (error) {
    return next(error);
  }
}

async function verifyOtp(req, res, next) {
  if (!validateEmail(req.body?.email)) {
    return res.status(400).json({ status: 'error', message: 'Email không hợp lệ' });
  }
  try {
    await authService.resetWithOtp(req.body.email.trim().toLowerCase(), req.body.code, req.body.newPassword);
    return res.status(200).json({ status: 'success', message: 'Đã đặt lại mật khẩu' });
  } catch (error) {
    return next(error);
  }
}

module.exports = { register, login, refresh, logout, changePassword, forgot, verifyOtp };
