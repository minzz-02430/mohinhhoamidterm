const salesService = require('./salesService');

const LEAD_STATUSES = new Set(['new', 'consulting', 'converted', 'cancelled']);

function isPositiveInteger(value) {
  return Number.isSafeInteger(value) && value > 0;
}

function validateLead(body) {
  const { fullname, phone, email, status, assignedTo } = body;

  if (typeof fullname !== 'string' || fullname.trim().length === 0 || fullname.trim().length > 120) {
    return 'fullname phải có từ 1 đến 120 ký tự';
  }

  if (phone !== undefined && phone !== null
    && (typeof phone !== 'string' || phone.trim().length > 30)) {
    return 'phone không hợp lệ';
  }

  if (email !== undefined && email !== null && email !== '') {
    if (typeof email !== 'string'
      || email.length > 254
      || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      return 'email không hợp lệ';
    }
  }

  if (status !== undefined && !LEAD_STATUSES.has(status)) {
    return "status phải là 'new', 'consulting', 'converted' hoặc 'cancelled'";
  }

  if (assignedTo !== undefined && assignedTo !== null && !isPositiveInteger(assignedTo)) {
    return 'assignedTo phải là số nguyên dương';
  }

  return null;
}

async function createLead(req, res, next) {
  const body = req.body ?? {};
  const validationError = validateLead(body);

  if (validationError) {
    return res.status(400).json({ status: 'error', message: validationError });
  }

  try {
    const assignedTo = req.user.role === 'sales'
      ? req.user.id
      : body.assignedTo ?? null;

    const lead = await salesService.createLead({
      fullname: body.fullname.trim(),
      phone: body.phone?.trim() || null,
      email: body.email?.trim().toLowerCase() || null,
      status: body.status ?? 'new',
      assignedTo,
    });

    return res.status(201).json({
      status: 'success',
      message: 'Đã tạo khách hàng tiềm năng',
      data: { lead },
    });
  } catch (error) {
    return next(error);
  }
}

async function getMyLeadQueue(req, res, next) {
  try {
    const leads = await salesService.getLeadQueue(req.user.id);
    return res.status(200).json({
      status: 'success',
      data: { leads },
    });
  } catch (error) {
    return next(error);
  }
}

async function createContract(req, res, next) {
  const body = req.body ?? {};
  const { studentId, classId, totalAmount } = body;

  if (body.paymentStatus !== undefined) {
    return res.status(400).json({
      status: 'error',
      message: 'paymentStatus được cập nhật tự động khi ghi nhận hóa đơn',
    });
  }

  if (!isPositiveInteger(studentId) || !isPositiveInteger(classId)) {
    return res.status(400).json({
      status: 'error',
      message: 'studentId và classId phải là số nguyên dương',
    });
  }

  if (typeof totalAmount !== 'number'
    || !Number.isFinite(totalAmount)
    || totalAmount < 0
    || totalAmount > 9999999999.99
    || Math.abs(totalAmount * 100 - Math.round(totalAmount * 100))
      > Number.EPSILON * Math.max(1, totalAmount * 100)) {
    return res.status(400).json({
      status: 'error',
      message: 'totalAmount phải là số không âm, tối đa 2 chữ số thập phân',
    });
  }

  try {
    const contract = await salesService.createContract({
      studentId,
      classId,
      totalAmount,
    });

    return res.status(201).json({
      status: 'success',
      message: 'Đã tạo hợp đồng ghi danh',
      data: { contract },
    });
  } catch (error) {
    return next(error);
  }
}

module.exports = { createLead, getMyLeadQueue, createContract };
