const { pool } = require('../../config/db');

function createServiceError(message, statusCode) {
  const error = new Error(message);
  error.statusCode = statusCode;
  return error;
}

async function createRequest({ userId, type, description }) {
  const [result] = await pool.execute(
    `INSERT INTO customer_requests (user_id, type, description)
     VALUES (?, ?, ?)`,
    [userId, type, description],
  );

  return {
    id: result.insertId,
    userId,
    type,
    description,
    status: 'pending',
  };
}

async function getPendingRequests() {
  const [requests] = await pool.execute(
    `SELECT
       cr.id,
       cr.user_id,
       u.name AS requester_name,
       cr.type,
       cr.description,
       cr.status,
       cr.created_at
     FROM customer_requests AS cr
     INNER JOIN users AS u ON u.id = cr.user_id
     WHERE cr.status = 'pending'
     ORDER BY cr.created_at ASC, cr.id ASC`,
  );

  return requests;
}

async function updateRequestStatus(requestId, status) {
  await pool.execute(
    `UPDATE customer_requests
     SET status = ?
     WHERE id = ?`,
    [status, requestId],
  );

  const [requests] = await pool.execute(
    `SELECT id, user_id, type, description, status, created_at
     FROM customer_requests
     WHERE id = ?
     LIMIT 1`,
    [requestId],
  );

  if (requests.length === 0) {
    throw createServiceError('Không tìm thấy yêu cầu hỗ trợ', 404);
  }

  return requests[0];
}

module.exports = { createRequest, getPendingRequests, updateRequestStatus };
