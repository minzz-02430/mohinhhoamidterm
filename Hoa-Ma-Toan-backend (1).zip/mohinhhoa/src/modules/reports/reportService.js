const { pool } = require('../../config/db');

function createServiceError(message, statusCode) {
  const error = new Error(message);
  error.statusCode = statusCode;
  return error;
}

async function createSessionReport({
  tutorId,
  scheduleId,
  enrollmentId,
  lessonDate,
  attendanceStatus,
  tutorComment,
}) {
  const [matchingSessions] = await pool.execute(
    `SELECT s.id AS schedule_id, e.id AS enrollment_id
     FROM schedules AS s
     INNER JOIN classes AS c ON c.id = s.class_id
     INNER JOIN enrollments AS e
       ON e.class_id = c.id
       AND e.id = ?
       AND e.status = 'active'
     WHERE s.id = ?
       AND s.status = 'active'
       AND c.teacher_id = ?
       AND (s.starts_on IS NULL OR s.starts_on <= ?)
       AND (s.ends_on IS NULL OR s.ends_on >= ?)
       AND s.day_of_week = ELT(
         DAYOFWEEK(?),
         'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'
       )
     LIMIT 1`,
    [enrollmentId, scheduleId, tutorId, lessonDate, lessonDate, lessonDate],
  );

  if (matchingSessions.length === 0) {
    throw createServiceError(
      'Không tìm thấy buổi học hợp lệ do gia sư phụ trách hoặc học sinh không thuộc lớp này',
      404,
    );
  }

  try {
    const [result] = await pool.execute(
      `INSERT INTO attendance_reports
         (enrollment_id, schedule_id, lesson_date, attendance_status, note, reported_by)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [
        enrollmentId,
        scheduleId,
        lessonDate,
        attendanceStatus,
        tutorComment || null,
        tutorId,
      ],
    );

    return {
      id: result.insertId,
      enrollmentId,
      scheduleId,
      lessonDate,
      attendanceStatus,
      tutorComment: tutorComment || null,
    };
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      throw createServiceError('Báo cáo điểm danh cho học sinh trong ngày này đã tồn tại', 409);
    }

    throw error;
  }
}

async function getReportsForParent(parentId) {
  const [reports] = await pool.execute(
    `SELECT
       s.id AS student_id,
       s.name AS student_name,
       ar.id AS report_id,
       DATE_FORMAT(ar.lesson_date, '%Y-%m-%d') AS lesson_date,
       ar.attendance_status,
       ar.note AS tutor_comment,
       ar.created_at,
       sch.start_time,
       c.id AS class_id,
       c.name AS class_name,
       co.name AS subject
     FROM parent_student AS ps
     INNER JOIN students AS s ON s.id = ps.student_id
     INNER JOIN enrollments AS e ON e.student_id = s.id
     INNER JOIN attendance_reports AS ar ON ar.enrollment_id = e.id
     INNER JOIN classes AS c ON c.id = e.class_id
     INNER JOIN courses AS co ON co.id = c.course_id
     LEFT JOIN schedules AS sch ON sch.id = ar.schedule_id
     WHERE ps.parent_id = ?
     ORDER BY ar.lesson_date DESC, sch.start_time DESC, s.name ASC`,
    [parentId],
  );

  return reports;
}

async function getTutorClasses(tutorId) {
  const [classes] = await pool.execute(
    `SELECT
       c.id AS class_id,
       c.name AS class_name,
       c.description,
       c.status,
       co.name AS course_name,
       COUNT(DISTINCT CASE WHEN e.status = 'active' THEN e.student_id END) AS student_count
     FROM classes AS c
     INNER JOIN users AS u ON u.id = c.teacher_id AND u.role = 'tutor'
     INNER JOIN courses AS co ON co.id = c.course_id
     LEFT JOIN enrollments AS e ON e.class_id = c.id
     WHERE c.teacher_id = ?
     GROUP BY c.id, c.name, c.description, c.status, co.name
     ORDER BY c.name ASC`,
    [tutorId],
  );

  return classes;
}

async function getTutorSchedules(tutorId) {
  const [schedules] = await pool.execute(
    `SELECT
       sch.id AS schedule_id,
       c.id AS class_id,
       c.name AS class_name,
       co.name AS course_name,
       sch.day_of_week,
       sch.start_time,
       sch.end_time,
       sch.starts_on,
       sch.ends_on,
       sch.location,
       sch.status
     FROM schedules AS sch
     INNER JOIN classes AS c ON c.id = sch.class_id
     INNER JOIN users AS u ON u.id = c.teacher_id AND u.role = 'tutor'
     INNER JOIN courses AS co ON co.id = c.course_id
     WHERE c.teacher_id = ?
       AND sch.status = 'active'
     ORDER BY FIELD(
       sch.day_of_week,
       'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'
     ), sch.start_time ASC, c.name ASC`,
    [tutorId],
  );

  return schedules;
}

module.exports = {
  createSessionReport,
  getReportsForParent,
  getTutorClasses,
  getTutorSchedules,
};
