const { randomBytes } = require('node:crypto');
const { pool } = require('../../config/db');

function createServiceError(message, statusCode) {
  const error = new Error(message);
  error.statusCode = statusCode;
  return error;
}

function decimalToCents(value) {
  const amount = String(value);
  const match = amount.match(/^(0|[1-9]\d{0,9})(?:\.(\d{1,2}))?$/);
  if (!match) {
    throw createServiceError('Giá trị tiền trong hợp đồng không hợp lệ', 500);
  }

  return Number(match[1]) * 100 + Number((match[2] ?? '').padEnd(2, '0'));
}

function centsToDecimal(cents) {
  const whole = Math.floor(cents / 100);
  const fraction = String(cents % 100).padStart(2, '0');
  return `${whole}.${fraction}`;
}

function generateInvoiceNumber() {
  return `INV-${Date.now()}-${randomBytes(6).toString('hex').toUpperCase()}`;
}

async function createInvoice({ contractId, amountPaid, paymentMethod, cashierId }) {
  let connection;
  let transactionStarted = false;

  try {
    connection = await pool.getConnection();
    await connection.beginTransaction();
    transactionStarted = true;

    const [contracts] = await connection.execute(
      `SELECT id, total_amount, paid_amount
       FROM contracts
       WHERE id = ?
       FOR UPDATE`,
      [contractId],
    );

    const contract = contracts[0];
    if (!contract) {
      throw createServiceError('Không tìm thấy hợp đồng', 404);
    }

    const totalCents = decimalToCents(contract.total_amount);
    const paidCents = decimalToCents(contract.paid_amount);
    const paymentCents = decimalToCents(amountPaid);
    const newPaidCents = paidCents + paymentCents;

    if (newPaidCents > totalCents) {
      throw createServiceError('Khoản thu vượt quá số tiền còn lại của hợp đồng', 409);
    }

    const paymentStatus = newPaidCents === totalCents
      ? 'paid'
      : 'partially_paid';
    const newPaidAmount = centsToDecimal(newPaidCents);

    let invoiceId;
    let invoiceNumber;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      invoiceNumber = generateInvoiceNumber();

      try {
        const [result] = await connection.execute(
          `INSERT INTO invoices
             (contract_id, invoice_number, amount_paid, payment_method, cashier_id)
           VALUES (?, ?, ?, ?, ?)`,
          [contractId, invoiceNumber, amountPaid, paymentMethod, cashierId],
        );
        invoiceId = result.insertId;
        break;
      } catch (error) {
        if (error.code !== 'ER_DUP_ENTRY' || attempt === 2) {
          throw error;
        }
      }
    }

    const [updateResult] = await connection.execute(
      `UPDATE contracts
       SET paid_amount = ?, payment_status = ?
       WHERE id = ?`,
      [newPaidAmount, paymentStatus, contractId],
    );

    if (updateResult.affectedRows !== 1) {
      throw createServiceError('Không thể cập nhật trạng thái thanh toán hợp đồng', 409);
    }

    await connection.commit();
    transactionStarted = false;

    return {
      id: invoiceId,
      contractId,
      invoiceNumber,
      amountPaid,
      paymentMethod,
      cashierId,
      contractPaidAmount: newPaidAmount,
      contractPaymentStatus: paymentStatus,
    };
  } catch (error) {
    if (connection && transactionStarted) {
      try {
        await connection.rollback();
      } catch (rollbackError) {
        console.error('Failed to roll back invoice transaction:', rollbackError);
      }
    }

    throw error;
  } finally {
    if (connection) {
      connection.release();
    }
  }
}

async function getCurrentMonthRevenue() {
  const [rows] = await pool.execute(
    `SELECT
       DATE_FORMAT(created_at, '%Y-%m') AS month,
       COALESCE(SUM(amount_paid), 0.00) AS totalRevenue
     FROM invoices
     WHERE DATE_FORMAT(created_at, '%Y-%m') = DATE_FORMAT(NOW(), '%Y-%m')
     GROUP BY DATE_FORMAT(created_at, '%Y-%m')`,
  );

  if (rows.length === 0) {
    const [currentMonth] = await pool.execute(
      `SELECT DATE_FORMAT(CURRENT_DATE, '%Y-%m') AS month`,
    );

    return {
      month: currentMonth[0].month,
      totalRevenue: '0.00',
    };
  }

  return {
    month: rows[0].month,
    totalRevenue: String(rows[0].totalRevenue),
  };
}

async function getDashboardKpis() {
  const [rows] = await pool.execute(
    `SELECT
       (
         SELECT COUNT(*)
         FROM students AS s
         WHERE EXISTS (
           SELECT 1
           FROM enrollments AS e
           WHERE e.student_id = s.id
             AND e.status = 'active'
         )
       ) AS active_students,
       (
         SELECT COUNT(*)
         FROM classes AS c
         WHERE c.status = 'active'
       ) AS active_classes,
       (
         SELECT COALESCE(SUM(ct.total_amount), 0.00)
         FROM contracts AS ct
       ) AS total_contract_amount`,
  );

  const kpis = rows[0];
  return {
    activeStudents: Number(kpis.active_students),
    activeClasses: Number(kpis.active_classes),
    totalContractAmount: String(kpis.total_contract_amount),
  };
}

async function getDashboardActivities() {
  const [activities] = await pool.execute(
    `SELECT
       cr.id,
       cr.user_id,
       u.name AS requester_name,
       cr.type,
       cr.description,
       cr.status,
       cr.created_at
     FROM customer_requests AS cr
     INNER JOIN users AS u ON u.id = cr.user_id
     ORDER BY cr.created_at DESC, cr.id DESC
     LIMIT 5`,
  );

  return activities;
}

module.exports = {
  createInvoice,
  getCurrentMonthRevenue,
  getDashboardKpis,
  getDashboardActivities,
};
