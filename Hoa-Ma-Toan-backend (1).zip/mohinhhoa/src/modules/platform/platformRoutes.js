// Các endpoint bổ sung theo bản audit (Prompt 12): cấp tài khoản, thông báo, tin nhắn, giao việc, hóa đơn, xuất CSV.
// Nguyên tắc: không bao giờ tin role, branch hay amount gửi trong body; mọi giá trị đó lấy từ req.user hoặc từ DB.
const crypto = require('node:crypto');
const express = require('express');
const bcrypt = require('bcryptjs');
const { pool } = require('../../config/db');
const { authenticateToken, requireRole, scopeToBranch } = require('../../middlewares/authMiddleware');
const { SALT_ROUNDS, createServiceError } = require('../auth/authService');

const router = express.Router();
const STAFF_ROLES = ['admin', 'manager', 'tutor', 'accountant', 'sales', 'assistant'];
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const handle = (fn) => async (req, res, next) => {
  try {
    await fn(req, res);
  } catch (error) {
    next(error);
  }
};
const ok = (res, data, status = 200) => res.status(status).json({ status: 'success', data });
const fail = (message, status) => { throw createServiceError(message, status); };
const text = (value, max) => (typeof value === 'string' && value.trim().length > 0 && value.trim().length <= max ? value.trim() : null);
const idParam = (value) => (/^\d+$/.test(String(value)) ? Number(value) : fail('Mã không hợp lệ', 400));
const audit = (req, action) => pool.execute('INSERT INTO audit_log (user_id, action) VALUES (?, ?)', [req.user.id, action]);
const notify = (userId, type, title, body) => pool.execute(
  'INSERT INTO notifications (user_id, type, title, body) VALUES (?, ?, ?, ?)', [userId, type, title, body],
);

router.use(authenticateToken);

// ---- Quản trị tài khoản: chỉ Ban giám đốc ----
router.post('/admin/users', requireRole('admin'), handle(async (req, res) => {
  const name = text(req.body?.name, 120);
  const email = text(req.body?.email, 254)?.toLowerCase();
  const role = req.body?.role;
  const branch = role === 'admin' ? null : text(req.body?.branch, 80);
  if (!name || !email || !EMAIL.test(email)) fail('Họ tên hoặc email không hợp lệ', 400);
  if (!STAFF_ROLES.includes(role)) fail(`Vai trò phải là một trong: ${STAFF_ROLES.join(', ')}`, 400);
  if (role !== 'admin' && !branch) fail('Tài khoản nhân sự phải gắn với một cơ sở', 400);

  const [existing] = await pool.execute('SELECT id FROM users WHERE email = ? LIMIT 1', [email]);
  if (existing.length) fail('Email đã được sử dụng', 409);

  // Mật khẩu tạm chỉ trả về một lần; người dùng buộc phải đổi ở lần đăng nhập đầu.
  const tempPassword = `Hmt${crypto.randomBytes(5).toString('hex')}9`;
  const [result] = await pool.execute(
    'INSERT INTO users (role, name, email, phone, password_hash, branch, status, must_change_password) VALUES (?, ?, ?, ?, ?, ?, ?, 1)',
    [role, name, email, text(req.body?.phone, 30), await bcrypt.hash(tempPassword, SALT_ROUNDS), branch, 'active'],
  );
  await audit(req, `Tạo tài khoản ${email} (${role})`);
  ok(res, { user: { id: result.insertId, name, email, role, branch }, tempPassword }, 201);
}));

router.patch('/admin/users/:id/status', requireRole('admin'), handle(async (req, res) => {
  const id = idParam(req.params.id);
  const status = req.body?.status;
  if (!['active', 'locked'].includes(status)) fail('Trạng thái phải là active hoặc locked', 400);
  if (id === Number(req.user.id)) fail('Không thể tự khóa tài khoản của chính mình', 400);

  // Khóa tài khoản thì tăng token_version để mọi phiên đang mở bị ngắt ngay.
  const [result] = await pool.execute(
    'UPDATE users SET status = ?, token_version = token_version + ? WHERE id = ?', [status, status === 'locked' ? 1 : 0, id],
  );
  if (!result.affectedRows) fail('Không tìm thấy tài khoản', 404);
  await audit(req, `${status === 'locked' ? 'Khóa' : 'Mở khóa'} tài khoản #${id}`);
  ok(res, { id, status });
}));

router.get('/admin/audit', requireRole('admin'), handle(async (req, res) => {
  const [rows] = await pool.execute(
    'SELECT a.id, a.action, a.created_at, u.name, u.role FROM audit_log a JOIN users u ON u.id = a.user_id ORDER BY a.id DESC LIMIT 200',
  );
  ok(res, { logs: rows });
}));

// ---- Thông báo: mỗi người chỉ thấy và chỉ đánh dấu được thông báo của mình ----
router.get('/notifications', handle(async (req, res) => {
  const [rows] = await pool.execute(
    'SELECT id, type, title, body, is_read, created_at FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 100', [req.user.id],
  );
  ok(res, { notifications: rows });
}));

router.post('/notifications', requireRole('admin', 'manager', 'accountant', 'tutor'), handle(async (req, res) => {
  const title = text(req.body?.title, 160);
  if (!title) fail('Thiếu tiêu đề thông báo', 400);
  const [users] = await pool.execute('SELECT id, branch FROM users WHERE id = ? LIMIT 1', [idParam(req.body?.userId)]);
  if (!users[0]) fail('Không tìm thấy người nhận', 404);
  if (req.user.role !== 'admin' && users[0].branch !== req.user.branch) fail('Chỉ gửi được thông báo trong cơ sở của bạn', 403);
  const [result] = await notify(users[0].id, text(req.body?.type, 40) || 'general', title, text(req.body?.body, 2000));
  ok(res, { id: result.insertId }, 201);
}));

router.patch('/notifications/:id/read', handle(async (req, res) => {
  const [result] = await pool.execute(
    'UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?', [idParam(req.params.id), req.user.id],
  );
  if (!result.affectedRows) fail('Không tìm thấy thông báo', 404);
  ok(res, { id: Number(req.params.id), is_read: true });
}));

// ---- Tin nhắn: chỉ thành viên hội thoại đọc và gửi được ----
async function requireMember(threadId, userId) {
  const [rows] = await pool.execute('SELECT thread_id FROM thread_members WHERE thread_id = ? AND user_id = ? LIMIT 1', [threadId, userId]);
  if (!rows[0]) fail('Không tìm thấy hội thoại', 404);
}

router.get('/threads', handle(async (req, res) => {
  const [rows] = await pool.execute(
    'SELECT t.id, t.title, t.updated_at FROM threads t JOIN thread_members m ON m.thread_id = t.id WHERE m.user_id = ? ORDER BY t.updated_at DESC', [req.user.id],
  );
  ok(res, { threads: rows });
}));

router.post('/threads', handle(async (req, res) => {
  const ids = [...new Set((Array.isArray(req.body?.participantIds) ? req.body.participantIds : []).map(Number))]
    .filter((id) => Number.isInteger(id) && id > 0 && id !== Number(req.user.id));
  const title = text(req.body?.title, 160);
  if (!ids.length || ids.length > 20 || !title) fail('Cần tiêu đề và 1–20 người tham gia', 400);

  const [users] = await pool.execute(`SELECT id, branch FROM users WHERE id IN (${ids.map(() => '?').join(', ')})`, ids);
  if (users.length !== ids.length) fail('Có người tham gia không tồn tại', 400);
  if (req.user.role !== 'admin' && users.some((user) => user.branch !== req.user.branch)) {
    fail('Chỉ nhắn tin được với người cùng cơ sở', 403);
  }

  const [result] = await pool.execute('INSERT INTO threads (title, created_by) VALUES (?, ?)', [title, req.user.id]);
  for (const userId of [Number(req.user.id), ...ids]) {
    await pool.execute('INSERT INTO thread_members (thread_id, user_id) VALUES (?, ?)', [result.insertId, userId]);
  }
  ok(res, { id: result.insertId, title }, 201);
}));

router.get('/threads/:id/messages', handle(async (req, res) => {
  const threadId = idParam(req.params.id);
  await requireMember(threadId, req.user.id);
  const [rows] = await pool.execute(
    'SELECT id, sender_id, body, created_at FROM messages WHERE thread_id = ? ORDER BY id ASC LIMIT 500', [threadId],
  );
  ok(res, { messages: rows });
}));

router.post('/threads/:id/messages', handle(async (req, res) => {
  const threadId = idParam(req.params.id);
  const body = text(req.body?.body, 4000);
  if (!body) fail('Nội dung tin nhắn không hợp lệ', 400);
  await requireMember(threadId, req.user.id);
  const [result] = await pool.execute('INSERT INTO messages (thread_id, sender_id, body) VALUES (?, ?, ?)', [threadId, req.user.id, body]);
  await pool.execute('UPDATE threads SET updated_at = CURRENT_TIMESTAMP WHERE id = ?', [threadId]);
  const [members] = await pool.execute('SELECT user_id FROM thread_members WHERE thread_id = ? AND user_id <> ?', [threadId, req.user.id]);
  for (const member of members) await notify(member.user_id, 'message', 'Tin nhắn mới', body.slice(0, 120));
  ok(res, { id: result.insertId }, 201);
}));

// ---- Giao việc: admin giao cho quản lý; quản lý giao cho nhân sự cùng cơ sở ----
router.get('/tasks', handle(async (req, res) => {
  const [rows] = await pool.execute(
    'SELECT id, title, description, due_date, status, priority, assigned_to, assigned_by FROM tasks WHERE assigned_to = ? OR assigned_by = ? ORDER BY id DESC',
    [req.user.id, req.user.id],
  );
  ok(res, { tasks: rows });
}));

router.post('/tasks', requireRole('admin', 'manager'), handle(async (req, res) => {
  const title = text(req.body?.title, 160);
  const priority = ['low', 'normal', 'high'].includes(req.body?.priority) ? req.body.priority : 'normal';
  const due = req.body?.dueDate ? new Date(req.body.dueDate) : null;
  if (!title || (due && Number.isNaN(due.getTime()))) fail('Tiêu đề hoặc hạn hoàn thành không hợp lệ', 400);

  const [users] = await pool.execute('SELECT id, role, branch FROM users WHERE id = ? LIMIT 1', [idParam(req.body?.assigneeId)]);
  const assignee = users[0];
  if (!assignee) fail('Không tìm thấy người nhận việc', 404);
  const allowed = req.user.role === 'admin'
    ? assignee.role === 'manager'
    : assignee.branch === req.user.branch && !['admin', 'manager', 'parent', 'student'].includes(assignee.role);
  if (!allowed) fail('Bạn không được giao việc cho người này', 403);

  const [result] = await pool.execute(
    'INSERT INTO tasks (title, description, due_date, priority, assigned_to, assigned_by) VALUES (?, ?, ?, ?, ?, ?)',
    [title, text(req.body?.description, 4000), due, priority, assignee.id, req.user.id],
  );
  await notify(assignee.id, 'task', 'Bạn được giao việc mới', title);
  ok(res, { id: result.insertId, title, priority }, 201);
}));

router.patch('/tasks/:id', handle(async (req, res) => {
  const status = req.body?.status;
  if (!['pending', 'doing', 'completed', 'rejected'].includes(status)) fail('Trạng thái không hợp lệ', 400);
  // Điều kiện sở hữu nằm ngay trong câu UPDATE: người ngoài nhận 404, không biết việc đó có tồn tại hay không.
  const [result] = await pool.execute(
    'UPDATE tasks SET status = ? WHERE id = ? AND (assigned_to = ? OR assigned_by = ?)',
    [status, idParam(req.params.id), req.user.id, req.user.id],
  );
  if (!result.affectedRows) fail('Không tìm thấy công việc', 404);
  ok(res, { id: Number(req.params.id), status });
}));

// ---- Hóa đơn: phụ huynh chỉ thấy con mình, quản lý/kế toán chỉ thấy cơ sở mình ----
const INVOICE_SQL = `SELECT i.id, i.invoice_number, i.amount_paid, i.status, i.created_at, s.id AS student_id, s.name AS student_name, s.branch
  FROM invoices i JOIN contracts c ON c.id = i.contract_id JOIN students s ON s.id = c.student_id`;

function invoiceScope(req) {
  if (req.user.role === 'parent') {
    return { where: 'EXISTS (SELECT 1 FROM parent_student ps WHERE ps.student_id = s.id AND ps.parent_id = ?)', params: [req.user.id] };
  }
  return req.branchScope ? { where: 's.branch = ?', params: [req.branchScope] } : { where: '1 = 1', params: [] };
}

const invoiceRoles = requireRole('admin', 'manager', 'accountant', 'parent');

router.get('/invoices', invoiceRoles, scopeToBranch, handle(async (req, res) => {
  const scope = invoiceScope(req);
  const [rows] = await pool.execute(`${INVOICE_SQL} WHERE ${scope.where} ORDER BY i.id DESC LIMIT 500`, scope.params);
  ok(res, { invoices: rows });
}));

router.get('/invoices/:id', invoiceRoles, scopeToBranch, handle(async (req, res) => {
  const scope = invoiceScope(req);
  const [rows] = await pool.execute(`${INVOICE_SQL} WHERE i.id = ? AND ${scope.where} LIMIT 1`, [idParam(req.params.id), ...scope.params]);
  if (!rows[0]) fail('Không tìm thấy hóa đơn', 404);
  ok(res, { invoice: rows[0] });
}));

router.post('/invoices/:id/confirm-payment', requireRole('admin', 'manager', 'accountant'), scopeToBranch, handle(async (req, res) => {
  const [rows] = await pool.execute(`${INVOICE_SQL} WHERE i.id = ? LIMIT 1`, [idParam(req.params.id)]);
  const invoice = rows[0];
  if (!invoice) fail('Không tìm thấy hóa đơn', 404);
  if (req.user.role !== 'admin' && invoice.branch !== req.user.branch) fail('Bạn không có quyền xác nhận hóa đơn của cơ sở khác', 403);
  if (invoice.status === 'paid') fail('Hóa đơn đã được xác nhận trước đó', 409);

  // Số tiền lấy từ hóa đơn trong DB; body không có trường nào được dùng.
  await pool.execute("UPDATE invoices SET status = 'paid', cashier_id = ? WHERE id = ?", [req.user.id, invoice.id]);
  await audit(req, `Xác nhận thanh toán hóa đơn ${invoice.invoice_number}`);
  const [parents] = await pool.execute('SELECT parent_id FROM parent_student WHERE student_id = ?', [invoice.student_id]);
  for (const parent of parents) await notify(parent.parent_id, 'payment', 'Đã xác nhận thanh toán', `Hóa đơn ${invoice.invoice_number}`);
  ok(res, { id: invoice.id, status: 'paid', amount: invoice.amount_paid });
}));

// ---- Xuất CSV (có BOM để Excel đọc đúng tiếng Việt), lọc theo cơ sở của người xuất ----
const EXPORTS = {
  students: { roles: ['admin', 'manager'], sql: 'SELECT s.id, s.name, s.grade, s.branch FROM students s', branch: 's.branch' },
  leads: { roles: ['admin', 'manager', 'sales'], sql: 'SELECT l.id, l.fullname, l.phone, l.email, l.status, l.branch FROM leads l', branch: 'l.branch' },
  invoices: { roles: ['admin', 'manager', 'accountant'], sql: INVOICE_SQL, branch: 's.branch' },
};
const csvCell = (value) => {
  const cell = value instanceof Date ? value.toISOString() : String(value ?? '');
  return /[",\n]/.test(cell) ? `"${cell.replaceAll('"', '""')}"` : cell;
};

router.get('/export/:resource.csv', scopeToBranch, handle(async (req, res) => {
  const config = EXPORTS[req.params.resource];
  if (!config) fail('Không hỗ trợ xuất loại dữ liệu này', 404);
  if (!config.roles.includes(req.user.role)) fail('Bạn không có quyền truy cập tính năng này', 403);

  const [rows] = await pool.execute(
    `${config.sql}${req.branchScope ? ` WHERE ${config.branch} = ?` : ''} ORDER BY 1 DESC LIMIT 5000`, req.branchScope ? [req.branchScope] : [],
  );
  const header = rows[0] ? Object.keys(rows[0]) : [];
  const csv = [header, ...rows.map((row) => header.map((key) => row[key]))].map((line) => line.map(csvCell).join(',')).join('\r\n');
  await audit(req, `Xuất CSV ${req.params.resource} (${rows.length} dòng)`);
  res.status(200).set({
    'Content-Type': 'text/csv; charset=utf-8',
    'Content-Disposition': `attachment; filename="hoa-ma-toan_${req.params.resource}_${new Date().toISOString().slice(0, 10)}.csv"`,
  }).send(`﻿${csv}`);
}));

module.exports = router;
