USE hoa_ma_toan_crm;

-- Legacy-only migration: use only when contracts and invoices already exist
-- and contracts.paid_amount does not. Do not run after upgrade_crm.sql or
-- database_production.sql; both already define paid_amount.
-- Adds a contract-level paid total while preserving the invoice history.
ALTER TABLE contracts
  ADD COLUMN paid_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER total_amount;

-- Initialize the new total and payment status from existing invoice records.
UPDATE contracts AS c
LEFT JOIN (
  SELECT contract_id, SUM(amount_paid) AS total_paid
  FROM invoices
  GROUP BY contract_id
) AS i ON i.contract_id = c.id
SET c.paid_amount = COALESCE(i.total_paid, 0.00),
    c.payment_status = CASE
      WHEN COALESCE(i.total_paid, 0.00) >= c.total_amount THEN 'paid'
      WHEN COALESCE(i.total_paid, 0.00) > 0.00 THEN 'partially_paid'
      ELSE 'unpaid'
    END;
