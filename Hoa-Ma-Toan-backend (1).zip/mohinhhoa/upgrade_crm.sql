USE hoa_ma_toan_crm;

-- Upgrade for the legacy database containing the core users, students, and classes tables.
-- This migration only creates CRM tables; it does not alter users, classes, or schedules.
-- Run once against a database where these CRM table names do not already exist.

-- Prospective customers and the user responsible for following up with each lead.
CREATE TABLE IF NOT EXISTS leads (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  fullname VARCHAR(120) NOT NULL,
  phone VARCHAR(30) NULL,
  email VARCHAR(254) NULL,
  status ENUM('new', 'consulting', 'converted', 'cancelled')
    NOT NULL DEFAULT 'new',
  assigned_to INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_leads_assigned_to (assigned_to),
  KEY idx_leads_status (status),
  CONSTRAINT fk_leads_assigned_to
    FOREIGN KEY (assigned_to) REFERENCES users (id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci
  COMMENT='CRM prospective customers and sales follow-up';

-- Student enrollment contracts; retain contract history if a linked record is removed.
CREATE TABLE IF NOT EXISTS contracts (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  student_id INT UNSIGNED NOT NULL,
  class_id INT UNSIGNED NOT NULL,
  contract_code VARCHAR(80) NOT NULL,
  total_amount DECIMAL(12,2) NOT NULL,
  paid_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  payment_status ENUM('unpaid', 'partially_paid', 'paid')
    NOT NULL DEFAULT 'unpaid',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_contracts_contract_code (contract_code),
  KEY idx_contracts_student_id (student_id),
  KEY idx_contracts_class_id (class_id),
  KEY idx_contracts_payment_status (payment_status),
  CONSTRAINT chk_contracts_total_amount_nonnegative CHECK (total_amount >= 0),
  CONSTRAINT fk_contracts_student
    FOREIGN KEY (student_id) REFERENCES students (id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_contracts_class
    FOREIGN KEY (class_id) REFERENCES classes (id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci
  COMMENT='Student class contracts and payment status';

-- Invoice/payment records for contracts and the cashier who recorded them.
CREATE TABLE IF NOT EXISTS invoices (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  contract_id INT UNSIGNED NOT NULL,
  invoice_number VARCHAR(80) NOT NULL,
  amount_paid DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  payment_method ENUM('cash', 'bank_transfer', 'vietqr', 'other') NOT NULL,
  cashier_id INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_invoices_invoice_number (invoice_number),
  KEY idx_invoices_contract_id (contract_id),
  KEY idx_invoices_cashier_id (cashier_id),
  CONSTRAINT chk_invoices_amount_paid_nonnegative CHECK (amount_paid >= 0),
  CONSTRAINT fk_invoices_contract
    FOREIGN KEY (contract_id) REFERENCES contracts (id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_invoices_cashier
    FOREIGN KEY (cashier_id) REFERENCES users (id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci
  COMMENT='Contract payment records and cashier details';

-- CRM and operations tasks assigned to an internal user.
CREATE TABLE IF NOT EXISTS tasks (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(160) NOT NULL,
  description TEXT NULL,
  due_date DATETIME NULL,
  status ENUM('pending', 'completed') NOT NULL DEFAULT 'pending',
  assigned_to INT UNSIGNED NULL,
  PRIMARY KEY (id),
  KEY idx_tasks_assigned_to (assigned_to),
  KEY idx_tasks_status_due_date (status, due_date),
  CONSTRAINT fk_tasks_assigned_to
    FOREIGN KEY (assigned_to) REFERENCES users (id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci
  COMMENT='Assigned CRM and operations tasks';

-- Requests submitted by users for leave, class changes, or complaints.
CREATE TABLE IF NOT EXISTS customer_requests (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  type ENUM('leave_request', 'class_change', 'complaint') NOT NULL,
  description TEXT NOT NULL,
  status ENUM('pending', 'processing', 'resolved') NOT NULL DEFAULT 'pending',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_customer_requests_user_id (user_id),
  KEY idx_customer_requests_status_created_at (status, created_at),
  CONSTRAINT fk_customer_requests_user
    FOREIGN KEY (user_id) REFERENCES users (id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci
  COMMENT='User requests and customer service workflow';
