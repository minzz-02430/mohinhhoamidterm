require('dotenv').config();
process.env.NODE_ENV = 'test';

const assert = require('node:assert/strict');
const http = require('node:http');
const { randomBytes, randomUUID } = require('node:crypto');
const test = require('node:test');
const bcrypt = require('bcryptjs');

const integrationEnabled = process.env.RUN_DB_INTEGRATION_TESTS === '1';
const { pool } = require('../src/config/db');
const app = require('../app');

function request(server, method, path, body, token) {
  const { port } = server.address();
  const bodyText = body === undefined ? null : JSON.stringify(body);

  return new Promise((resolve, reject) => {
    const headers = {};
    if (bodyText !== null) {
      headers['Content-Type'] = 'application/json';
      headers['Content-Length'] = Buffer.byteLength(bodyText);
    }
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }

    const req = http.request(
      { hostname: '127.0.0.1', port, path, method, headers },
      (res) => {
        let responseBody = '';
        res.setEncoding('utf8');
        res.on('data', chunk => { responseBody += chunk; });
        res.on('end', () => {
          try {
            resolve({
              status: res.statusCode,
              body: responseBody ? JSON.parse(responseBody) : null,
            });
          } catch (error) {
            reject(error);
          }
        });
      },
    );

    req.on('error', reject);
    if (bodyText !== null) {
      req.write(bodyText);
    }
    req.end();
  });
}

test('real MySQL: admin login, contract creation, and invoice payment', {
  skip: integrationEnabled ? false : 'Set RUN_DB_INTEGRATION_TESTS=1 to enable real-DB integration tests.',
}, async (t) => {
  const testDatabase = process.env.INTEGRATION_TEST_DB_NAME;
  assert.match(
    testDatabase || '',
    /^[a-zA-Z0-9_]+_test$/,
    'INTEGRATION_TEST_DB_NAME must name an isolated database ending in _test.',
  );
  assert.equal(
    process.env.DB_NAME,
    testDatabase,
    'DB_NAME must exactly match INTEGRATION_TEST_DB_NAME; refusing to write to another schema.',
  );
  assert.ok(process.env.JWT_SECRET, 'Set JWT_SECRET before running the integration test.');

  let server;
  let userId;
  let accountantId;
  let courseId;
  let studentId;
  let classId;
  let contractId;

  t.after(async () => {
    const cleanupErrors = [];

    if (server) {
      try {
        await new Promise((resolve, reject) => {
          server.close(error => (error ? reject(error) : resolve()));
        });
      } catch (error) {
        cleanupErrors.push(error);
      }
    }

    const cleanupQueries = [
      contractId && ['DELETE FROM invoices WHERE contract_id = ?', [contractId]],
      contractId && ['DELETE FROM contracts WHERE id = ?', [contractId]],
      classId && ['DELETE FROM classes WHERE id = ?', [classId]],
      courseId && ['DELETE FROM courses WHERE id = ?', [courseId]],
      studentId && ['DELETE FROM students WHERE id = ?', [studentId]],
      accountantId && ['DELETE FROM users WHERE id = ?', [accountantId]],
      userId && ['DELETE FROM users WHERE id = ?', [userId]],
    ].filter(Boolean);

    for (const [sql, params] of cleanupQueries) {
      try {
        await pool.execute(sql, params);
      } catch (error) {
        cleanupErrors.push(error);
      }
    }

    try {
      await pool.end();
    } catch (error) {
      cleanupErrors.push(error);
    }

    if (cleanupErrors.length > 0) {
      throw new AggregateError(cleanupErrors, 'Failed to clean up integration-test fixtures.');
    }
  });

  const [databaseRows] = await pool.execute('SELECT DATABASE() AS database_name');
  assert.equal(databaseRows[0]?.database_name, testDatabase);

  const adminEmail = `integration-admin-${randomUUID()}@example.test`;
  const accountantEmail = `integration-accountant-${randomUUID()}@example.test`;
  const adminPassword = `Integration-${randomBytes(12).toString('hex')}`;
  const accountantPassword = `Integration-${randomBytes(12).toString('hex')}`;

  // Public registration disallows privileged roles. Seed disposable role fixtures
  // directly in the isolated test DB, then exercise login and business APIs over HTTP.
  const [userResult] = await pool.execute(
    `INSERT INTO users (role, name, email, password_hash)
     VALUES ('admin', ?, ?, ?)`,
    ['Integration Test Admin', adminEmail, await bcrypt.hash(adminPassword, 10)],
  );
  userId = userResult.insertId;

  const [accountantResult] = await pool.execute(
    `INSERT INTO users (role, name, email, password_hash)
     VALUES ('accountant', ?, ?, ?)`,
    ['Integration Test Accountant', accountantEmail, await bcrypt.hash(accountantPassword, 10)],
  );
  accountantId = accountantResult.insertId;

  const [courseResult] = await pool.execute(
    'INSERT INTO courses (name, description, fee) VALUES (?, ?, ?)',
    [`Integration course ${randomUUID()}`, 'Temporary integration-test fixture', 250.00],
  );
  courseId = courseResult.insertId;

  const [studentResult] = await pool.execute(
    'INSERT INTO students (name, grade) VALUES (?, ?)',
    [`Integration student ${randomUUID()}`, 'Test'],
  );
  studentId = studentResult.insertId;

  const [classResult] = await pool.execute(
    `INSERT INTO classes (course_id, teacher_id, name, status)
     VALUES (?, ?, ?, 'active')`,
    [courseId, userId, `Integration class ${randomUUID()}`],
  );
  classId = classResult.insertId;

  server = await new Promise((resolve, reject) => {
    const httpServer = app.listen(0, '127.0.0.1');
    httpServer.once('error', reject);
    httpServer.once('listening', () => resolve(httpServer));
  });

  const adminLogin = await request(
    server,
    'POST',
    '/api/v1/auth/login',
    { email: adminEmail, password: adminPassword },
  );
  assert.equal(adminLogin.status, 200, JSON.stringify(adminLogin.body));
  const adminToken = adminLogin.body?.data?.token;
  assert.equal(typeof adminToken, 'string');

  const contractResponse = await request(
    server,
    'POST',
    '/api/v1/sales/contracts',
    { studentId, classId, totalAmount: 250.00 },
    adminToken,
  );
  assert.equal(contractResponse.status, 201, JSON.stringify(contractResponse.body));
  contractId = contractResponse.body?.data?.contract?.id;
  assert.ok(contractId, 'Contract response should include its database ID.');
  assert.equal(contractResponse.body.data.contract.paymentStatus, 'unpaid');
  assert.equal(Number(contractResponse.body.data.contract.paidAmount), 0);

  const [initialContracts] = await pool.execute(
    'SELECT total_amount, paid_amount, payment_status FROM contracts WHERE id = ?',
    [contractId],
  );
  assert.equal(initialContracts.length, 1);
  assert.equal(Number(initialContracts[0].total_amount), 250);
  assert.equal(Number(initialContracts[0].paid_amount), 0);
  assert.equal(initialContracts[0].payment_status, 'unpaid');

  const accountantLogin = await request(
    server,
    'POST',
    '/api/v1/auth/login',
    { email: accountantEmail, password: accountantPassword },
  );
  assert.equal(accountantLogin.status, 200, JSON.stringify(accountantLogin.body));
  const accountantToken = accountantLogin.body?.data?.token;
  assert.equal(typeof accountantToken, 'string');

  const invoiceResponse = await request(
    server,
    'POST',
    '/api/v1/finance/invoices',
    { contractId, amountPaid: '250.00', paymentMethod: 'bank_transfer' },
    accountantToken,
  );
  assert.equal(invoiceResponse.status, 201, JSON.stringify(invoiceResponse.body));

  const [updatedContracts] = await pool.execute(
    'SELECT total_amount, paid_amount, payment_status FROM contracts WHERE id = ?',
    [contractId],
  );
  assert.equal(updatedContracts.length, 1);
  assert.equal(Number(updatedContracts[0].total_amount), 250);
  assert.equal(Number(updatedContracts[0].paid_amount), 250);
  assert.equal(updatedContracts[0].payment_status, 'paid');

  const [invoices] = await pool.execute(
    `SELECT amount_paid, payment_method
     FROM invoices
     WHERE contract_id = ?`,
    [contractId],
  );
  assert.equal(invoices.length, 1);
  assert.equal(Number(invoices[0].amount_paid), 250);
  assert.equal(invoices[0].payment_method, 'bank_transfer');
});
