const assert = require('node:assert/strict');
const http = require('node:http');
const test = require('node:test');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

process.env.JWT_SECRET = 'automated-test-secret';
process.env.NODE_ENV = 'test';

const { pool } = require('../src/config/db');

let registeredUser;
let createdReport;
let createdLead;
let createdContract;
let financeContract = { id: 71, total_amount: '100.00', paid_amount: '0.00' };
let financeTransactionState = null;
let financeTransactionEvents = [];
let failFinanceContractUpdate = false;
let supportRequest;
const leadQueue = [];

pool.execute = async (sql, params) => {
  if (sql.includes('SELECT id, email, role, branch, status, token_version FROM users WHERE id = ?')) {
    const testUsers = {
      1: { id: 1, email: 'admin@example.com', role: 'admin' },
      5: { id: 5, email: 'tutor@example.com', role: 'tutor' },
      6: { id: 6, email: 'sales@example.com', role: 'sales' },
      9: { id: 9, email: 'accountant@example.com', role: 'accountant' },
      10: { id: 10, email: 'manager@example.com', role: 'manager' },
    };
    const user = registeredUser?.id === Number(params[0])
      ? registeredUser
      : testUsers[params[0]];
    return [[user ? { id: user.id, email: user.email, role: user.role } : undefined]
      .filter(Boolean)];
  }

  if (sql.includes('SELECT id FROM users WHERE id = ? AND role')) {
    return [[{ id: params[0] }]];
  }

  if (sql.includes('SELECT id FROM users WHERE email')) {
    return [[...(registeredUser?.email === params[0] ? [{ id: registeredUser.id }] : [])]];
  }

  if (sql.includes('INSERT INTO users')) {
    registeredUser = {
      id: 21,
      role: params[0],
      name: params[1],
      email: params[2],
      phone: params[3],
      password_hash: params[4],
    };
    return [{ insertId: registeredUser.id }];
  }

  if (sql.includes('SELECT id, name, email, phone, role, password_hash')) {
    return [[...(registeredUser?.email === params[0] ? [registeredUser] : [])]];
  }

  if (sql.includes('INSERT INTO attendance_reports')) {
    createdReport = params;
    return [{ insertId: 41 }];
  }

  if (sql.includes('FROM parent_student AS ps')) {
    return [[{
      student_id: 7,
      student_name: 'Student',
      report_id: 41,
      lesson_date: '2026-11-09',
      attendance_status: 'present',
      tutor_comment: 'Good work',
      start_time: '10:00:00',
      subject: 'Mathematics',
    }]];
  }

  if (sql.includes('FROM classes AS c')) {
    assert.deepEqual(params, [5]);
    return [[{
      class_id: 12,
      class_name: 'Tutor class',
      course_name: 'Mathematics',
      student_count: 3,
      status: 'active',
    }]];
  }

  if (sql.includes('FROM schedules AS sch')) {
    assert.deepEqual(params, [5]);
    return [[{
      schedule_id: 13,
      class_id: 12,
      class_name: 'Tutor class',
      day_of_week: 'monday',
      start_time: '10:00:00',
      end_time: '11:30:00',
      location: 'Room 1',
      status: 'active',
    }]];
  }

  if (sql.includes('FROM schedules AS s')) {
    return [[{ schedule_id: params[1], enrollment_id: params[0] }]];
  }

  if (sql.includes('INSERT INTO leads')) {
    createdLead = params;
    return [{ insertId: 51 }];
  }

  if (sql.includes('FROM leads') && sql.includes('WHERE assigned_to = ?')) {
    assert.deepEqual(params, [6]);
    return [leadQueue];
  }

  if (sql.includes('FROM students AS s') && sql.includes('CROSS JOIN classes')) {
    return [[{ student_id: params[0], class_id: params[1] }]];
  }

  if (sql.includes('INSERT INTO contracts')) {
    createdContract = params;
    return [{ insertId: 61 }];
  }

  if (sql.includes('INSERT INTO customer_requests')) {
    supportRequest = {
      id: 91,
      user_id: params[0],
      type: params[1],
      description: params[2],
      status: 'pending',
      created_at: '2026-11-08 18:00:00',
    };
    return [{ insertId: supportRequest.id }];
  }

  if (sql.includes('FROM customer_requests AS cr')) {
    return [[supportRequest?.status === 'pending'
      ? { ...supportRequest, requester_name: 'Parent' }
      : undefined].filter(Boolean)];
  }

  if (sql.includes('UPDATE customer_requests')) {
    if (supportRequest && supportRequest.id === params[1]) {
      supportRequest.status = params[0];
    }
    return [{ affectedRows: supportRequest?.id === params[1] ? 1 : 0 }];
  }

  if (sql.includes('FROM customer_requests') && sql.includes('WHERE id = ?')) {
    return [[...(supportRequest?.id === params[0] ? [supportRequest] : [])]];
  }

  throw new Error(`Unexpected SQL in test: ${sql}`);
};

pool.getConnection = async () => ({
  async beginTransaction() {
    financeTransactionState = { ...financeContract };
    financeTransactionEvents.push('begin');
  },
  async execute(sql, params) {
    if (sql.includes('FROM contracts') && sql.includes('FOR UPDATE')) {
      return [[financeContract.id === params[0] ? { ...financeContract } : undefined].filter(Boolean)];
    }

    if (sql.includes('INSERT INTO invoices')) {
      return [{ insertId: 81 }];
    }

    if (sql.includes('UPDATE contracts')) {
      if (failFinanceContractUpdate) {
        throw new Error('Simulated contract update failure');
      }

      financeContract = {
        ...financeContract,
        paid_amount: params[0],
        payment_status: params[1],
      };
      return [{ affectedRows: 1 }];
    }

    throw new Error(`Unexpected transaction SQL in test: ${sql}`);
  },
  async commit() {
    financeTransactionEvents.push('commit');
    financeTransactionState = null;
  },
  async rollback() {
    financeTransactionEvents.push('rollback');
    if (financeTransactionState) {
      financeContract = financeTransactionState;
      financeTransactionState = null;
    }
  },
  release() {
    financeTransactionEvents.push('release');
  },
});

const originalPoolExecute = pool.execute;
pool.execute = async (sql, params) => {
  if (sql.includes('DATE_FORMAT(created_at')) {
    return [[{ month: '2026-11', totalRevenue: '250.00' }]];
  }

  if (sql.includes('AS active_students') && sql.includes('AS total_contract_amount')) {
    return [[{
      active_students: 12,
      active_classes: 4,
      total_contract_amount: '125000.00',
    }]];
  }

  if (sql.includes('FROM customer_requests AS cr')
    && sql.includes('ORDER BY cr.created_at DESC')) {
    return [[{
      id: 91,
      user_id: 21,
      requester_name: 'Parent',
      type: 'complaint',
      description: 'Need assistance',
      status: 'pending',
      created_at: '2026-11-11 10:00:00',
    }]];
  }

  return originalPoolExecute(sql, params);
};

const app = require('../app');
let server;
let port;

function request(method, path, body, token) {
  return new Promise((resolve, reject) => {
    const bodyText = body === undefined ? null : JSON.stringify(body);
    const headers = {};

    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }

    if (bodyText !== null) {
      headers['Content-Type'] = 'application/json';
      headers['Content-Length'] = Buffer.byteLength(bodyText);
    }

    const req = http.request(
      { hostname: '127.0.0.1', port, path, method, headers },
      (res) => {
        let responseBody = '';
        res.setEncoding('utf8');
        res.on('data', (chunk) => { responseBody += chunk; });
        res.on('end', () => {
          resolve({
            status: res.statusCode,
            body: responseBody
              ? res.headers['content-type']?.includes('application/json')
                ? JSON.parse(responseBody)
                : responseBody
              : null,
            headers: res.headers,
          });
        });
      },
    );

    req.on('error', reject);
    if (bodyText !== null) {
      req.write(bodyText);
    }
    req.end();
  });
}

test('backend health, authentication, and report APIs', async (t) => {
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', resolve);
  });
  port = server.address().port;

  t.after(async () => {
    await new Promise((resolve, reject) => {
      server.close((error) => (error ? reject(error) : resolve()));
    });
    await pool.end();
  });

  const health = await request('GET', '/api/v1/health');
  assert.equal(health.status, 200);
  assert.deepEqual(health.body, {
    status: 'OK',
    message: 'Backend is running flawlessly',
  });

  const apiIndex = await request('GET', '/api/v1');
  assert.equal(apiIndex.status, 200);
  assert.equal(apiIndex.body.status, 'OK');
  assert.equal(apiIndex.body.endpoints.auth, '/api/v1/auth');

  const demoLandingPage = await request('GET', '/');
  assert.equal(demoLandingPage.status, 302);
  assert.equal(demoLandingPage.headers.location, '/test.html');

  const demoPage = await request('GET', '/test.html');
  assert.equal(demoPage.status, 200);
  assert.match(demoPage.body, /HÒA MA TOÁN/);

  const invalidRegistration = await request('POST', '/api/v1/auth/register', {
    email: 'not-an-email',
    password: 'strongpass123',
    name: 'Student',
    role: 'parent',
  });
  assert.equal(invalidRegistration.status, 400);

  const registration = await request('POST', '/api/v1/auth/register', {
    email: ' Parent@Example.com ',
    password: 'strongpass123',
    name: 'Parent',
    phone: '0123456789',
    role: 'parent',
  });
  assert.equal(registration.status, 201);
  assert.equal(registration.body.data.user.email, 'parent@example.com');
  assert.equal(await bcrypt.compare('strongpass123', registeredUser.password_hash), true);

  const login = await request('POST', '/api/v1/auth/login', {
    email: 'PARENT@example.com',
    password: 'strongpass123',
  });
  assert.equal(login.status, 200);
  assert.equal(jwt.verify(login.body.data.token, process.env.JWT_SECRET).role, 'parent');

  const tutorToken = jwt.sign(
    { id: 5, email: 'tutor@example.com', role: 'tutor' },
    process.env.JWT_SECRET,
  );
  const parentToken = login.body.data.token;

  const unauthenticatedReport = await request(
    'POST',
    '/api/v1/reports/session',
    {},
  );
  assert.equal(unauthenticatedReport.status, 401);

  const reportPayload = {
    scheduleId: 13,
    enrollmentId: 91,
    lessonDate: '2026-11-09',
    attendanceStatus: 'present',
    tutorComment: 'Good work',
  };
  const report = await request(
    'POST',
    '/api/v1/reports/session',
    reportPayload,
    tutorToken,
  );
  assert.equal(report.status, 201);
  assert.deepEqual(createdReport, [
    91, 13, '2026-11-09', 'present', 'Good work', 5,
  ]);

  const childrenReports = await request(
    'GET',
    '/api/v1/reports/my-children',
    undefined,
    parentToken,
  );
  assert.equal(childrenReports.status, 200);
  assert.equal(childrenReports.body.data.reports[0].subject, 'Mathematics');

  const tutorClasses = await request(
    'GET',
    '/api/v1/reports/tutor/classes',
    undefined,
    tutorToken,
  );
  assert.equal(tutorClasses.status, 200);
  assert.equal(tutorClasses.body.status, 'success');
  assert.deepEqual(tutorClasses.body.data, [{
    class_id: 12,
    class_name: 'Tutor class',
    course_name: 'Mathematics',
    student_count: 3,
    status: 'active',
  }]);

  const tutorSchedules = await request(
    'GET',
    '/api/v1/reports/tutor/schedules',
    undefined,
    tutorToken,
  );
  assert.equal(tutorSchedules.status, 200);
  assert.equal(tutorSchedules.body.status, 'success');
  assert.deepEqual(tutorSchedules.body.data, [{
    schedule_id: 13,
    class_id: 12,
    class_name: 'Tutor class',
    day_of_week: 'monday',
    start_time: '10:00:00',
    end_time: '11:30:00',
    location: 'Room 1',
    status: 'active',
  }]);

  assert.equal((await request(
    'GET',
    '/api/v1/reports/tutor/classes',
    undefined,
    parentToken,
  )).status, 403);
  assert.equal((await request(
    'GET',
    '/api/v1/reports/tutor/schedules',
    undefined,
    parentToken,
  )).status, 403);

  const forbidden = await request(
    'GET',
    '/api/v1/reports/my-children',
    undefined,
    tutorToken,
  );
  assert.equal(forbidden.status, 403);

  const staleRoleToken = jwt.sign(
    { id: 5, email: 'tutor@example.com', role: 'parent' },
    process.env.JWT_SECRET,
  );
  const staleRoleAccess = await request(
    'GET',
    '/api/v1/reports/my-children',
    undefined,
    staleRoleToken,
  );
  assert.equal(staleRoleAccess.status, 403);

  const salesToken = jwt.sign(
    { id: 6, email: 'sales@example.com', role: 'sales' },
    process.env.JWT_SECRET,
  );
  const adminToken = jwt.sign(
    { id: 1, email: 'admin@example.com', role: 'admin' },
    process.env.JWT_SECRET,
  );
  const managerToken = jwt.sign(
    { id: 10, email: 'manager@example.com', role: 'manager' },
    process.env.JWT_SECRET,
  );

  const lead = await request('POST', '/api/v1/sales/leads', {
    fullname: 'Prospective Student',
    phone: '0123456789',
    email: 'lead@example.com',
  }, salesToken);
  assert.equal(lead.status, 201);
  assert.deepEqual(createdLead, [
    'Prospective Student',
    '0123456789',
    'lead@example.com',
    'new',
    6,
  ]);
  assert.equal((await request('POST', '/api/v1/sales/leads', {
    fullname: '',
  }, salesToken)).status, 400);
  assert.equal((await request('POST', '/api/v1/sales/leads', {
    fullname: 'Unauthorized',
  }, parentToken)).status, 403);

  const queue = await request('GET', '/api/v1/sales/leads/my-queue', undefined, salesToken);
  assert.equal(queue.status, 200);
  assert.deepEqual(queue.body.data.leads, []);
  assert.equal((await request(
    'GET',
    '/api/v1/sales/leads/my-queue',
    undefined,
    adminToken,
  )).status, 403);

  const contract = await request('POST', '/api/v1/sales/contracts', {
    studentId: 7,
    classId: 8,
    totalAmount: 1250.5,
  }, adminToken);
  assert.equal(contract.status, 201);
  assert.match(contract.body.data.contract.contractCode, /^CTR-[A-Z0-9]+-[A-F0-9]{12}$/);
  assert.deepEqual(createdContract.slice(0, 2), [7, 8]);
  assert.equal(createdContract[3], 1250.5);
  assert.equal(createdContract[4], 0);
  assert.equal(createdContract[5], 'unpaid');
  assert.equal(contract.body.data.contract.paidAmount, 0);
  assert.equal(contract.body.data.contract.paymentStatus, 'unpaid');
  const forgedAmountContract = await request('POST', '/api/v1/sales/contracts', {
    studentId: 7,
    classId: 8,
    totalAmount: 1250.5,
    paidAmount: 9999,
  }, adminToken);
  assert.equal(forgedAmountContract.status, 201);
  assert.equal(forgedAmountContract.body.data.contract.paidAmount, 0);
  assert.deepEqual(createdContract.slice(4), [0, 'unpaid']);
  assert.equal((await request('POST', '/api/v1/sales/contracts', {
    studentId: 7,
    classId: 8,
    totalAmount: 1250.5,
    paymentStatus: 'paid',
  }, adminToken)).status, 400);
  assert.equal((await request('POST', '/api/v1/sales/contracts', {
    studentId: 7,
    classId: 8,
    totalAmount: -1,
  }, salesToken)).status, 400);

  const accountantToken = jwt.sign(
    { id: 9, email: 'accountant@example.com', role: 'accountant' },
    process.env.JWT_SECRET,
  );
  const invoice = await request('POST', '/api/v1/finance/invoices', {
    contractId: 71,
    amountPaid: 40,
    paymentMethod: 'bank_transfer',
  }, accountantToken);
  assert.equal(invoice.status, 201);
  assert.equal(financeContract.paid_amount, '40.00');
  assert.equal(financeContract.payment_status, 'partially_paid');
  assert.equal(financeTransactionEvents.slice(-2).join(','), 'commit,release');
  assert.match(invoice.body.data.invoice.invoiceNumber, /^INV-\d+-[A-F0-9]{12}$/);

  const finalInvoice = await request('POST', '/api/v1/finance/invoices', {
    contractId: 71,
    amountPaid: '60.00',
    paymentMethod: 'cash',
  }, accountantToken);
  assert.equal(finalInvoice.status, 201);
  assert.equal(financeContract.paid_amount, '100.00');
  assert.equal(financeContract.payment_status, 'paid');

  const previousPaymentStatus = financeContract.payment_status;
  const overpayment = await request('POST', '/api/v1/finance/invoices', {
    contractId: 71,
    amountPaid: 1,
    paymentMethod: 'cash',
  }, accountantToken);
  assert.equal(overpayment.status, 409);
  assert.equal(financeContract.payment_status, previousPaymentStatus);
  assert.equal(financeTransactionEvents.slice(-2).join(','), 'rollback,release');

  financeContract = { id: 71, total_amount: '200.00', paid_amount: '100.00' };
  failFinanceContractUpdate = true;
  const failedTransaction = await request('POST', '/api/v1/finance/invoices', {
    contractId: 71,
    amountPaid: 1,
    paymentMethod: 'cash',
  }, accountantToken);
  failFinanceContractUpdate = false;
  assert.equal(failedTransaction.status, 500);
  assert.equal(financeContract.paid_amount, '100.00');
  assert.equal(financeContract.total_amount, '200.00');
  assert.equal(financeTransactionEvents.slice(-2).join(','), 'rollback,release');

  assert.equal((await request('POST', '/api/v1/finance/invoices', {
    contractId: 71,
    amountPaid: 10,
    paymentMethod: 'cash',
  }, salesToken)).status, 403);

  const revenue = await request('GET', '/api/v1/finance/dashboard/revenue', undefined, adminToken);
  assert.equal(revenue.status, 200);
  assert.deepEqual(revenue.body, {
    status: 'success',
    totalRevenue: '250.00',
    month: '2026-11',
  });
  const managerRevenue = await request(
    'GET',
    '/api/v1/finance/dashboard/revenue',
    undefined,
    managerToken,
  );
  assert.equal(managerRevenue.status, 200);
  assert.equal((await request(
    'GET',
    '/api/v1/finance/dashboard/revenue',
    undefined,
    accountantToken,
  )).status, 403);

  const kpis = await request(
    'GET',
    '/api/v1/finance/dashboard/kpis',
    undefined,
    adminToken,
  );
  assert.equal(kpis.status, 200);
  assert.equal(kpis.body.status, 'success');
  assert.deepEqual(kpis.body.data, {
    activeStudents: 12,
    activeClasses: 4,
    totalContractAmount: '125000.00',
  });
  assert.equal((await request(
    'GET',
    '/api/v1/finance/dashboard/kpis',
    undefined,
    managerToken,
  )).status, 200);
  assert.equal((await request(
    'GET',
    '/api/v1/finance/dashboard/kpis',
    undefined,
    accountantToken,
  )).status, 403);

  const activities = await request(
    'GET',
    '/api/v1/finance/dashboard/activities',
    undefined,
    adminToken,
  );
  assert.equal(activities.status, 200);
  assert.equal(activities.body.status, 'success');
  assert.equal(activities.body.data.length, 1);
  assert.equal(activities.body.data[0].requester_name, 'Parent');
  assert.equal((await request(
    'GET',
    '/api/v1/finance/dashboard/activities',
    undefined,
    managerToken,
  )).status, 403);

  const supportRequestResponse = await request('POST', '/api/v1/support/requests', {
    type: 'leave_request',
    description: 'Xin nghỉ buổi học ngày mai',
    userId: 999,
  }, parentToken);
  assert.equal(supportRequestResponse.status, 201);
  assert.equal(supportRequestResponse.body.data.request.userId, 21);
  assert.equal(supportRequestResponse.body.data.request.status, 'pending');
  assert.equal((await request('POST', '/api/v1/support/requests', {
    type: 'invalid',
    description: 'Request',
  }, parentToken)).status, 400);
  assert.equal((await request('POST', '/api/v1/support/requests', {
    type: 'complaint',
    description: 'Unauthorized',
  }, tutorToken)).status, 403);

  const pendingRequests = await request(
    'GET',
    '/api/v1/support/requests/pending',
    undefined,
    managerToken,
  );
  assert.equal(pendingRequests.status, 200);
  assert.equal(pendingRequests.body.data.requests[0].id, 91);
  assert.equal((await request(
    'GET',
    '/api/v1/support/requests/pending',
    undefined,
    parentToken,
  )).status, 403);

  const updatedRequest = await request(
    'PATCH',
    '/api/v1/support/requests/91/status',
    { status: 'processing' },
    managerToken,
  );
  assert.equal(updatedRequest.status, 200);
  assert.equal(updatedRequest.body.data.request.status, 'processing');
  assert.equal((await request(
    'PATCH',
    '/api/v1/support/requests/91/status',
    { status: 'pending' },
    managerToken,
  )).status, 400);
  assert.equal((await request(
    'PATCH',
    '/api/v1/support/requests/999/status',
    { status: 'resolved' },
    managerToken,
  )).status, 404);
});
